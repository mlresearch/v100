1. Installations:
    1.1 create an anaconda env using the 367_corl2019_env.yaml file in Anaconda_Env folder;
    1.2 activate the created env;
    1.3 install my code lib via command "pip install -e ." under CoRL_code folder;

2. How to run experiments:
    2.1 Capture Target Domain
        2.1.1 Primitive Action Scenario
            2.1.1.1 Decentralized Learning (Fig.4a)
                a). go to src/rlmamr/MA_hddrqn/model.py file, in class DDRQN, set MLP layer with 32
                    neurons;
                b). run following commands with seed=0-40 and run_id=0-40, one example for 0 shown below:
                    
                    ma_hddrqn.py --grid_dim 4 4 --env_name=CT --env_terminate_step=60 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ct_4_4 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2
                    
                    ma_hddrqn.py --grid_dim 5 5 --env_name=CT --env_terminate_step=60 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ct_5_5 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

                    ma_hddrqn.py --grid_dim 6 6 --env_name=CT --env_terminate_step=60 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ct_6_6 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

                    ma_hddrqn.py --grid_dim 7 7 --env_name=CT --env_terminate_step=60 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ct_7_7 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

                    ma_hddrqn.py --grid_dim 8 8 --env_name=CT --env_terminate_step=60 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ct_8_8 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

                    ma_hddrqn.py --grid_dim 9 9 --env_name=CT --env_terminate_step=60 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ct_9_9 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

                    ma_hddrqn.py --grid_dim 10 10 --env_name=CT --env_terminate_step=60 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ct_10_10 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

                    ma_hddrqn.py --grid_dim 20 20 --env_name=CT --env_terminate_step=120 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ct_20_20 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

                    ma_hddrqn.py --grid_dim 30 30 --env_name=CT --env_terminate_step=120 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ct_30_30 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

        2.1.2 Macro-Actions Scenario:
            2.1.2.1 Decentralized Learning (Fig.4a)
                a). run following commands with seed=0-40 and run_id=0-40, one example for 0 shown below:

                    ma_hddrqn.py --grid_dim 4 4 --env_name=CT_MA_v1 --env_terminate_step=60 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ctma_4_4 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2
                    
                    ma_hddrqn.py --grid_dim 5 5 --env_name=CT_MA_v1 --env_terminate_step=60 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ctma_5_5 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

                    ma_hddrqn.py --grid_dim 6 6 --env_name=CT_MA_v1 --env_terminate_step=60 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ctma_6_6 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

                    ma_hddrqn.py --grid_dim 7 7 --env_name=CT_MA_v1 --env_terminate_step=60 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ctma_7_7 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

                    ma_hddrqn.py --grid_dim 8 8 --env_name=CT_MA_v1 --env_terminate_step=60 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ctma_8_8 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2
                    
                    ma_hddrqn.py --grid_dim 9 9 --env_name=CT_MA_v1 --env_terminate_step=60 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ctma_9_9 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

                    ma_hddrqn.py --grid_dim 10 10 --env_name=CT_MA_v1 --env_terminate_step=60 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ctma_10_10 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

                    ma_hddrqn.py --grid_dim 20 20 --env_name=CT_MA_v1 --env_terminate_step=120 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ctma_20_20 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

                    ma_hddrqn.py --grid_dim 30 30 --env_name=CT_MA_v1 --env_terminate_step=120 --batch_size=32 --trace_len=4 --rnn_h_size=64 --train_freq=5 --total_epi=20000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=ctma_20_20 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.95 --start_train=2

    2.2 Box Pushing Domain 
        2.2.1 Primitive Actions Scenario
            2.2.1.2 Decentralized Learning (Fig.4b)
                a). run following commands with seed=0-40 and run_id=0-40, one example for 0 shown below:

                    ma_hddrqn.py --grid_dim 4 4 --env_name=BP --env_terminate_step=100 --batch_size=16 --rnn_h_size=32 --train_freq=10 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=bp_4_4 --replay_buffer_size=1000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.0006 --discount=0.98 --start_train=2 --sample_epi --h_explore

                    ma_hddrqn.py --grid_dim 6 6 --env_name=BP --env_terminate_step=100 --batch_size=16 --rnn_h_size=32 --train_freq=10 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=bp_6_6 --replay_buffer_size=1000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.0006 --discount=0.98 --start_train=2 --sample_epi --h_explore

                    ma_hddrqn.py --grid_dim 8 8 --env_name=BP --env_terminate_step=100 --batch_size=16 --rnn_h_size=32 --train_freq=10 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=bp_8_8 --replay_buffer_size=1000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.0006 --discount=0.98 --start_train=2 --sample_epi --h_explore

                    ma_hddrqn.py --grid_dim 10 10 --env_name=BP --env_terminate_step=100 --batch_size=16 --rnn_h_size=32 --train_freq=10 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=bp_10_10 --replay_buffer_size=1000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.0006 --discount=0.98 --start_train=2 --sample_epi --h_explore

                    ma_hddrqn.py --grid_dim 20 20 --env_name=BP --env_terminate_step=200 --batch_size=16 --rnn_h_size=32 --train_freq=35 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=bp_20_20 --replay_buffer_size=1000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.0006 --discount=0.98 --start_train=2 --sample_epi --h_explore

                    ma_hddrqn.py --grid_dim 30 30 --env_name=BP --env_terminate_step=200 --batch_size=16 --rnn_h_size=32 --train_freq=45 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=bp_30_30 --replay_buffer_size=1000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.0006 --discount=0.98 --start_train=2 --sample_epi --h_explore

        2.2.2 Macro-Actions Scenario
            2.2.2.1 Decentralized Learning (Fig.4b)
                a). run following commands with seed=0-40 and run_id=0-40, one example for 0 shown below:

                    ma_hddrqn.py --grid_dim 4 4 --env_name=BP_MA --env_terminate_step=100 --batch_size=128 --rnn_h_size=32 --train_freq=10 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=bpma_4_4 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=10

                    ma_hddrqn.py --grid_dim 6 6 --env_name=BP_MA --env_terminate_step=100 --batch_size=128 --rnn_h_size=32 --train_freq=10 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=bpma_6_6 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=10

                    ma_hddrqn.py --grid_dim 8 8 --env_name=BP_MA --env_terminate_step=100 --batch_size=128 --rnn_h_size=32 --train_freq=10 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=bpma_8_8 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=10

                    ma_hddrqn.py --grid_dim 10 10 --env_name=BP_MA --env_terminate_step=100 --batch_size=128 --rnn_h_size=32 --train_freq=14 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=bpma_10_10 --replay_buffer_size=50000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=14

                    ma_hddrqn.py --grid_dim 20 20 --env_name=BP_MA --env_terminate_step=200 --batch_size=128 --rnn_h_size=32 --train_freq=35 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=bpma_20_20 --replay_buffer_size=100000 --h_stable_at=6000 --eps_l_d_steps=6000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=35

                    ma_hddrqn.py --grid_dim 30 30 --env_name=BP_MA --env_terminate_step=200 --batch_size=128 --rnn_h_size=32 --train_freq=45 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=bpma_20_20 --replay_buffer_size=100000 --h_stable_at=6000 --eps_l_d_steps=6000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=45

            2.2.2.2 Centralized Learning via Condition Prediction (Fig.5)
                a). go to src/rlmamr/MA_cen_condi_ddrqn/model_cen_condi.py, in class DDRQN, set MLP layer with 32 neurons for grid world size smaller than 10x10, otherwise 64 neurons.   
                b). run following commands with seed=0-40 and run_id=0-40, one example for 0 shown below:

                    ma_cen_condi_ddrqn.py --grid_dim 4 4 --env_name=BP_MA --env_terminate_step=100 --batch_size=128 --rnn_h_size=64 --train_freq=5 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=cen_condi_bpma_4_4 --replay_buffer_size=100000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=5

                    ma_cen_condi_ddrqn.py --grid_dim 6 6 --env_name=BP_MA --env_terminate_step=100 --batch_size=128 --rnn_h_size=64 --train_freq=5 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=cen_condi_bpma_6_6 --replay_buffer_size=100000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=5

                    ma_cen_condi_ddrqn.py --grid_dim 8 8 --env_name=BP_MA --env_terminate_step=100 --batch_size=128 --rnn_h_size=64 --train_freq=12 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=cen_condi_bpma_8_8 --replay_buffer_size=100000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=12

                    ma_cen_condi_ddrqn.py --grid_dim 10 10 --env_name=BP_MA --env_terminate_step=100 --batch_size=128 --rnn_h_size=64 --train_freq=15 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=cen_condi_bpma_10_10 --replay_buffer_size=100000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=15

                    ma_cen_condi_ddrqn.py --grid_dim 20 20 --env_name=BP_MA --env_terminate_step=200 --batch_size=128 --rnn_h_size=64 --train_freq=35 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=cen_condi_bpma_20_20 --replay_buffer_size=100000 --h_stable_at=6000 --eps_l_d_steps=6000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=35

                    ma_cen_condi_ddrqn.py --grid_dim 30 30 --env_name=BP_MA --env_terminate_step=200 --batch_size=128 --rnn_h_size=64 --train_freq=45 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=cen_condi_bpma_30_30 --replay_buffer_size=100000 --h_stable_at=6000 --eps_l_d_steps=6000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=45

            2.2.2.3 Centralized Learning via Uncondition Prediction (Fig.5)
                a) go to /src/rlmamr/MA_cen_ddrqn/model_cen.py, in class DDRQN, set MLP layer with 32 neurons for grid world size smaller than 10x10, otherwise 64 neurons.   
                b) run following commands with seed=0-40 and run_id=0-40, one example for 0 shown below
                    
                    ma_cen_ddrqn.py --grid_dim 4 4 --env_name=BP_MA --env_terminate_step=100 --batch_size=128 --rnn_h_size=64 --train_freq=5 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=cen_condi_bpma_4_4 --replay_buffer_size=100000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=5

                    ma_cen_ddrqn.py --grid_dim 6 6 --env_name=BP_MA --env_terminate_step=100 --batch_size=128 --rnn_h_size=64 --train_freq=5 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=cen_condi_bpma_6_6 --replay_buffer_size=100000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=5

                    ma_cen_ddrqn.py --grid_dim 8 8 --env_name=BP_MA --env_terminate_step=100 --batch_size=128 --rnn_h_size=64 --train_freq=12 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=cen_condi_bpma_8_8 --replay_buffer_size=100000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=12

                    ma_cen_ddrqn.py --grid_dim 10 10 --env_name=BP_MA --env_terminate_step=100 --batch_size=128 --rnn_h_size=64 --train_freq=15 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=cen_condi_bpma_10_10 --replay_buffer_size=100000 --h_stable_at=4000 --eps_l_d_steps=4000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=15

                    ma_cen_ddrqn.py --grid_dim 20 20 --env_name=BP_MA --env_terminate_step=200 --batch_size=128 --rnn_h_size=64 --train_freq=35 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=cen_condi_bpma_20_20 --replay_buffer_size=100000 --h_stable_at=6000 --eps_l_d_steps=6000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=35

                    ma_cen_ddrqn.py --grid_dim 30 30 --env_name=BP_MA --env_terminate_step=200 --batch_size=128 --rnn_h_size=64 --train_freq=45 --total_epi=15000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=cen_condi_bpma_30_30 --replay_buffer_size=100000 --h_stable_at=6000 --eps_l_d_steps=6000 --l_rate=0.001 --discount=0.98 --start_train=2 --trace_len=45

    2.3 Warehouse Tool Delivery Domain
        
        2.3.1 Centralized Learning (Fig.6)
            a) go to /src/rlmamr/MA_cen_condi_ddrqn/model_cen_condi.py, in class DDRQN, set MLP layer with 64 neurons.   
            b) run following commands with seed=0-40 and run_id=0-40, one example for 0 shown below

                ma_cen_condi_ddrqn.py --env_name=OSD_S_4 --env_terminate_step=150 --batch_size=16 --rnn_h_size=128 --train_freq=30 --total_epi=40000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=osd_single_v4 --replay_buffer_size=1000 --h_stable_at=6000 --eps_l_d_steps=6000 --l_rate=0.0006 --discount=1.0 --start_train=2 --sample_epi --h_explore


        2.3.2 Decentralized Learning (Fig.6)
            a) go to /src/rlmamr/MA_hddrqn/model.py, in class DDRQN, set MLP layer with 32 neurons.   
            b) run following commands with seed=0-40 and run_id=0-40, one example for 0 shown below

                ma_hddrqn.py --env_name=OSD_S_4 --env_terminate_step=150 --batch_size=16 --rnn_h_size=64 --train_freq=30 --total_epi=40000 --seed=0 --run_id=0 --eps_l_d --dynamic_h --rnn --save_dir=osd_single_v4_dec --replay_buffer_size=1000 --h_stable_at=6000 --eps_l_d_steps=6000 --l_rate=0.0006 --discount=1.0 --start_train=2 --sample_epi --h_explore

        2.3.3 Trained Centralized Policy Visualization
            2.3.3.1 Behaviors in Fig.7
        	a) go to test/ folder, and run "python test_osd_s_policy.py --p_id=2"
                b) press c and enter, the robots will run the policy one step. Keep doing this, you would see the cooperation behaviors.

            2.3.3.2 Behaviors in Fig.8
                a) go to /src/rlmamr/my_env/core_single_room.py, set the moving spped for turtlebot as 0.8 at line 319;
        	b) go to /test/ folder, and run "python test_osd_s_policy.py --p_id=2"
                c) press c and enter, the robots will run the policy one step. Keep doing this you will see the new optimal behaviors.


Note: all the trianning results will be saved to the "performance" folder, and all the trained policies will be saved to the "policy_nns" folder.


