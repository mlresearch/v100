#!/usr/bin/python

from gym.envs.registration import register






