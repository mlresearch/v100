import numpy as np
import IPython
import matplotlib.pyplot as plt
import torch
import pickle
import math
import copy
import random

from torch.optim import Adam, RMSprop
from itertools import chain

from .model import DDQN, DDRQN, DDRQN_compare, Cen_DDRQN, Shared_RNN
from .utils.Agent import Agent
from .utils.utils import Linear_Decay, save_check_point
from .envs_runner import EnvsRunner

from IPython.core.debugger import set_trace

# parameters for e-greedy policy
EPS_START = 1.0
EPS_END = 0.1
EPS_DECAY = 2000
EPS_DECAY_LINEAR_RATE = 0.9999

OPTIMIZERS = {'Adam': Adam,
              'RMSprop': RMSprop}

class Team:
    
    def __init__(self, env, memory, n_agent, h_stable_at, dynamic_h=False, hysteretic=None, discount=0.99,
                 epsilon_linear_decay=False, epsilon_linear_decay_steps=0):
        self.env = env
        self.n_agent = n_agent
        self.memory = memory

        self.step_count = 0.0
        self.episode_count = 0.0
        self.episode_rewards = 0.0
 
        # hysteretic settings
        self.dynamic_h = dynamic_h
        (self.init_hysteretic, self.end_hysteretic) = hysteretic
        self.hysteretic = self.init_hysteretic
        self.discount = discount

        # epsilon for e-greedy
        self.epsilon = EPS_START
        self.epsilon_linear_decay = epsilon_linear_decay
        self.eps_l_d = Linear_Decay(epsilon_linear_decay_steps, EPS_START, EPS_END)
        
        self.HYSTERESIS_STABLE_AT = h_stable_at

    def create_agents(self):
        raise NotImplementedError

    def step(self):
        raise NotImplementedError

    def get_next_actions(self):
        raise NotImplementedError

    def update_target_net(self):
        for agent in self.agents:
            agent.target_net.load_state_dict(agent.policy_net.state_dict())

    def train(self):
        raise NotImplementedError

    def update_epsilon(self, step):
        # update epsilon:
        if self.epsilon_linear_decay:
            #self.epsilon = max(self.epsilon*EPS_DECAY_LINEAR_RATE, EPS_END)
            self.epsilon = self.eps_l_d._get_value(step)
        else:
            self.epsilon = EPS_END + (EPS_START - EPS_END) * math.exp(-1. * (step//8)  / EPS_DECAY)
    
    def update_hysteretic(self, step):
        if self.dynamic_h:
            self.hysteretic = min(self.end_hysteretic,
                                  ((self.end_hysteretic - self.init_hysteretic) / self.HYSTERESIS_STABLE_AT) * step + self.init_hysteretic)
        else:
            self.hysteretic = 1 - self.epsilon
    
    def get_init_inputs(self):
        raise NotImplementedError

    def sep_joint_exps(self, joint_exps):
        raise NotImplementedError

    def evaluate(self):
        raise NotImplementedError

    def load_check_point(self, idx_run):
        for idx, agent in enumerate(self.agents):
            PATH = "./performance/" + self.save_dir + "/check_point/" + str(idx_run) + "_agent_" + str(idx) + "1.tar"
            ckpt = torch.load(PATH)
            agent.policy_net.load_state_dict(ckpt['policy_net_state_dict'])
            agent.target_net.load_state_dict(ckpt['target_net_state_dict'])
            agent.optimizer.load_state_dict(ckpt['optimizer_state_dict'])

        self.hysteretic = ckpt['cur_hysteretic']
        self.epsilon = ckpt['cur_eps']
        self.episode_count = ckpt['n_epi']
        self.step_count = ckpt['cur_step']
        self.TEST_PERFORM = ckpt['TEST_PERFORM']
        self.memory.buf = ckpt['mem_buf']
        random.setstate(ckpt['random_state'])
        np.random.set_state(ckpt['np_random_state'])
        torch.set_rng_state(ckpt['torch_random_state'])

class Team_RNN(Team):

    def __init__(self, env, n_env, memory, n_agent, training_method, h_stable_at, discount=0.99, centralized_training=False, sample_epi=False, 
                 dynamic_h=False, hysteretic=None, h_explore=False, epsilon_linear_decay=False, epsilon_linear_decay_steps=0, 
                 epsilon_exp_decay=False, optimizer='Adam', learning_rate=0.001, device='cpu', save_dir=None, 
                 nn_model_params={}, **hyper_params):

        super(Team_RNN, self).__init__(env, memory, n_agent, h_stable_at, dynamic_h, hysteretic, discount,
                                       epsilon_linear_decay, epsilon_linear_decay_steps)

        # create multiprocessor for multiple envs running parallel
        self.envs_runner = EnvsRunner(self.env, self.memory, n_env, h_explore, self.get_next_actions)
        self.envs_runner.reset()
        self.n_env = n_env

        # sample the whole episode for training
        self.sample_epi = sample_epi
        
        # training method
        self.cen_train = centralized_training
        self.training_method = training_method
        self.nn_model_params = nn_model_params
        self.hyper_params = hyper_params
        self.optimizer = optimizer
        self.lr = learning_rate
        
        # save model
        self.save_dir = save_dir
        self.device = device

        # statistic of training and testing
        self.TRAIN_PERFORM = []
        self.TEST_PERFORM = []

        # create agents
        self.create_agents()

    def create_agents(self):
        self.agents=[]
        if self.cen_train:
            self.shared_RNN = Shared_RNN(**nn_model_params)
            for i in range(self.n_agent):
                agent = Agent()
                agent.idx = i
                agent.policy_net = Cen_DDRQN(self.env.obs_size[i], self.env.n_action[i], shared_RNN=self.shared_RNN, **self.nn_model_params).to(self.device)
                agent.target_net = Cen_DDRQN(self.env.obs_size[i], self.env.n_action[i], shared_RNN=self.shared_RNN, **self.nn_model_params).to(self.device)
                agent.target_net.load_state_dict(agent.policy_net.state_dict())
                agent.optimizer = OPTIMIZERS[self.optimizer](agent.policy_net.parameters(), lr=self.lr)
                self.agents.append(agent)
        else:
            for i in range(self.n_agent):
                agent = Agent()
                agent.idx = i
                agent.policy_net = DDRQN(self.env.obs_size[i], self.env.n_action[i], **self.nn_model_params).to(self.device)
                agent.policy_net.is_policy_net = True
                agent.target_net = DDRQN(self.env.obs_size[i], self.env.n_action[i], **self.nn_model_params).to(self.device)
                agent.target_net.load_state_dict(agent.policy_net.state_dict())
                agent.target_net.is_policy_net = False
                agent.optimizer = OPTIMIZERS[self.optimizer](agent.policy_net.parameters(), lr=self.lr)
                self.agents.append(agent)

    def step(self, idx_run):
        if self.step_count == 0:
            self.evaluate()
            with open("./performance/" + self.save_dir + "/test/test_perform" + str(idx_run) + ".pickle", 'wb') as handle:
                pickle.dump(self.TEST_PERFORM, handle)

        self.step_count += 1.0

        n_episode_done = self.envs_runner.step()
        self.episode_count += n_episode_done

        if n_episode_done > 0 and not self.episode_count % 10:
            self.evaluate()

            #save_check_point(self.agents, self.step_count, self.episode_count, self.hysteretic, self.epsilon, self.save_dir, self.memory, idx_run, self.TEST_PERFORM) 

            with open("./performance/" + self.save_dir + "/test/test_perform" + str(idx_run) + ".pickle", 'wb') as handle:
                pickle.dump(self.TEST_PERFORM, handle)

            for agent in self.agents:
                 PATH = "./policy_nns/" + self.save_dir + "/agent_" + str(agent.idx) + ".pt"
                 torch.save(agent.policy_net, PATH)

    def get_next_actions(self, joint_obs, joint_h_states, last_valid, eval=False):
        with torch.no_grad():
            actions = []
            h_states = []
            for agent in self.agents:
                if last_valid[agent.idx]:
                    Q, h = agent.policy_net(joint_obs[agent.idx].view(1,1,self.env.obs_size[agent.idx]), joint_h_states[agent.idx])
                    a = Q.squeeze(1).max(1)[1].item()
                    actions.append(a)
                    h_states.append(h)
                else:
                    actions.append(-1)
                    h_states.append(joint_h_states[agent.idx])

        if not eval:
            actions = [a if np.random.random() > self.epsilon else self.env.action_space_sample(i) for i, a in enumerate(actions)]
        return actions, h_states

    def train(self):
        if self.sample_epi:
            batch, trace_len = self.memory.sample()
            batch = self.sep_joint_exps(batch)
            self.hyper_params['trace_len'] = trace_len
        else:
            batch = self.sep_joint_exps(self.memory.sample())
        self.training_method(self.agents, batch, self.hysteretic, self.discount, **self.hyper_params)

    def get_init_inputs(self):
        return [torch.from_numpy(i).float() for i in self.env.reset()], [None]*self.n_agent

    def sep_joint_exps(self, joint_exps):
        # seperate the joint experience for individual agents
        exps = [[] for _ in range(self.n_agent)]
        for o, a, r, o_n, t, v in chain(*joint_exps):
            for i in range(self.n_agent):
                exps[i].append([o[i], a[i], r[i], o_n[i], t, v[i]])
        return exps

    def evaluate(self, n_episode=1):

        R, L = 0, 0

        for _ in range(n_episode):
            t = 0
            step = 0
            last_obs, h_states = self.get_init_inputs()
            last_valid = [1.0] * self.n_agent
            while not t:
                a, h_states = self.get_next_actions(last_obs, h_states, last_valid, eval=True)
                a, last_obs, r, t, v = self.env.step(a)
                last_obs = [torch.from_numpy(o).float() for o in last_obs]
                last_valid = v
                R += self.discount**step * r
                step += 1
                #R += r

        self.TEST_PERFORM.append(R/n_episode)


class Team_NN(Team):

    def __init__(self, env, memory, n_agent, training_method, centralized_training=False, 
                 dynamic_h=False, hysteretic=None, epsilon_linear_decay=False, epsilon_linear_decay_steps=0,
                 epsilon_exp_decay=False, optimizer='Adam', learning_rate=0.001,device='cpu', save_dir=None, 
                 nn_model_params={}, **hyper_params):

        super(Team_NN, self).__init__(env, memory, n_agent, dynamic_h, hysteretic, 
                                       epsilon_linear_decay, epsilon_linear_decay_steps)

        # training method
        self.training_method = training_method
        self.nn_model_params = nn_model_params
        self.hyper_params = hyper_params
        self.optimizer = optimizer
        self.lr = learning_rate

        # executing
        self.last_obs = self.get_init_inputs()
        
        # init rewards for MA
        self.accu_rewards_per_step = [0.0] * n_agent

        # init agent's MA is done or not
        self.last_valid = [1.0] * n_agent

        # save model
        self.save_dir = save_dir
        self.device = device

        # statistic of training and testing
        self.TRAIN_PERFORM = []
        self.TEST_PERFORM = []

        # create agents
        self.create_agents()

    def create_agents(self):
        # create agents
        self.agents=[]
        for i in range(self.n_agent):
            agent = Agent()
            agent.idx = i
            agent.policy_net = DDQN(self.env.obs_size[i], self.env.n_action[i], **self.nn_model_params).to(self.device)
            agent.target_net = DDQN(self.env.obs_size[i], self.env.n_action[i], **self.nn_model_params).to(self.device)
            agent.target_net.load_state_dict(agent.policy_net.state_dict())
            agent.optimizer = OPTIMIZERS[self.optimizer](agent.policy_net.parameters(), lr=self.lr)
            self.agents.append(agent)

    def step(self, idx_run):
        self.step_count += 1.0
        #if self.episode_count % 5:
        actions = self.get_next_actions(self.last_obs)
        #else:
            #actions = self.get_actions_push_bigbox(self.last_obs)
        actions, obs, reward, terminate, valid = self.env.step(actions)
        
        # accumulate rewards for each agent depends on the valid 
        for idx, v in enumerate(valid):
            self.accu_rewards_per_step[idx] = self.accu_rewards_per_step[idx] + reward if not self.last_valid[idx] else reward
        self.last_valid = valid

        # change the type of the date to be torch tensor
        a = [torch.tensor(a).view(1,-1) for a in actions]
        obs = [torch.from_numpy(o).float() for o in obs]
        r = [torch.tensor(r).float().view(1,-1) for r in self.accu_rewards_per_step]
        t = torch.tensor(terminate).float().view(1,-1)
        v = [torch.tensor(v, dtype=torch.uint8).view(1,-1) for v in valid]
        
        self.memory.append((self.last_obs, a, r, obs, t, v))
        self.last_obs = obs
        self.episode_rewards += reward

        if t.item():
            self.episode_count += 1
            #create all the possible trace according to the specified trace_len
            self.memory.flush_scenario_cache()
            
            if not self.episode_count % 10:
                self.evaluate()
                with open("./performance/" + self.save_dir + "/test/test_perform" + str(idx_run) + ".pickle", 'wb') as handle:
                    pickle.dump(self.TEST_PERFORM, handle)

            self.last_obs = self.get_init_inputs()

            # collect train performance
            self.TRAIN_PERFORM.append(self.episode_rewards)

            # reset rewards counter for next episode
            self.episode_rewards = 0.0

            # reset last valid
            self.last_valid = [1.0] * self.n_agent
            
            # save the trained policy nn
            for agent in self.agents:
                PATH = "./policy_nns/" + self.save_dir + "/agent_" + str(agent.idx) + ".pt"
                torch.save(agent.policy_net, PATH)

            with open("./performance/" + self.save_dir + "/train/train_perform" + str(idx_run) + ".pickle", 'wb') as handle:
                pickle.dump(self.TRAIN_PERFORM, handle)

    def get_next_actions(self, joint_obs, eval=False):
        with torch.no_grad():
            actions = []
            for agent in self.agents:
                if self.last_valid[agent.idx]:
                    Q = agent.policy_net(joint_obs[agent.idx].view(1,1,self.env.obs_size[agent.idx]))
                        #print(joint_obs[agent.idx])
                        #print('GOTO-SM:{} GOTO-BG{} PUSH{} TL{} TR{} STAY{}'.format(*Q[0]))
                    a = Q.squeeze(1).max(1)[1].item()
                    actions.append(a)
                else:
                    actions.append(self.env.agents[agent.idx].cur_action.idx)

        if not eval:
            actions = [a if np.random.random() > self.epsilon else self.env.action_space_sample(i) for i, a in enumerate(actions)]
        return actions

    def get_actions_push_bigbox(self, joint_obs):
        if joint_obs[0][2] == 1.0:
            return [1, 1]
        if joint_obs[0][1] == 1.0:
            return [2, 2]

    def train(self):
        self.update_hysteretic()
        batches = self.sep_joint_exps(self.memory.sample())
        self.training_method(self.agents, batches, self.hysteretic, rnn=False, **self.hyper_params)

    def get_init_inputs(self):
        return [torch.from_numpy(i).float() for i in self.env.reset()]

    def sep_joint_exps(self, joint_exps):
        # seperate the joint experience for individual agents
        exps = [[] for _ in range(self.n_agent)]
        for o, a, r, o_n, t, v in chain(*joint_exps):
            for i in range(self.n_agent):
                exps[i].append([o[i], a[i], r[i], o_n[i], t, v[i]])
        return exps

    def evaluate(self, n_episode=10):
        R, L = 0, 0

        for _ in range(n_episode):
            t = 0
            last_obs = self.get_init_inputs()
            self.last_valid = [1.0] * self.n_agent
            while not t:
                a = self.get_next_actions(last_obs, eval=True)
                a, last_obs, r, t, v = self.env.step(a)
                last_obs = [torch.from_numpy(o).float() for o in last_obs]
                self.last_valid = v
                R += r

        self.TEST_PERFORM.append(R/n_episode)
