from setuptools import setup

setup(name='slippy',
      version='0.2',
      description='SLIPpy',
      url='anonymous',
      author='anonymous',
      author_email='anonymous',
      license='MIT',
      packages=['models', 'measure', 'viability'],
      zip_safe=False)