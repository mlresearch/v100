drex-atari contains supplemental code and scripts for running the Atari experiments.
drex-mujoco contains supplemental code and scripts for running the Mujoco experiments.

We also have a complete and up-to-date code repository along with supplemental videos available on our project website: 
https://dsbrown1331.github.io/CoRL2019-DREX/
