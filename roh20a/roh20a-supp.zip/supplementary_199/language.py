import collections
from itertools import product
from typing import List, Dict


def generate_sentence_list_from_templates(
        expressions: List[str],
        prefixes: List[str],
        suffixes: List[str],
        keyword: str = ''):
    sentences = []
    if keyword:
        expressions = [expression.format(keyword=keyword) for expression in expressions]
    if prefixes:
        for prefix, suffix, expression in product(prefixes, suffixes, expressions):
            prefix_words = set(prefix.split(' '))
            suffix_words = set(suffix.split(' '))
            valid = all(list(map(lambda w: w not in prefix_words and w not in suffix_words, expression.split(' '))))
            if valid:
                sentences.append(' '.join([prefix, expression, suffix]).strip())
    else:
        for suffix, expression in product(suffixes, expressions):
            suffix_words = set(suffix.split(' '))
            valid = all(list(map(lambda w: w not in suffix_words, expression.split(' '))))
            if valid:
                sentences.append(' '.join([expression, suffix]).strip())
    sentences = list(map(lambda x: x.replace("'", ' '), sentences))
    return sorted(sentences)


STRAIGHT_PREFIXES = ['', 'you can', "you're going to", "you'll", 'you want to', 'continue to', 'just']
STRAIGHT_SUFFIXES = ['', 'further', 'furthermore', 'for a while', 'ahead', 'for a bit']
STRAIGHT_SUFFIXES_FIRST = ['for one block', 'for a block', 'at the first intersection']
STRAIGHT_SUFFIXES_END = ['until you meet the end', 'until the end of this road',
                         'to the end of this road', 'till the end of the street']
STRAIGHT_SUFFIXES_TWO = ['for two blocks']
STRAIGHT_EXPRESSIONS = [
    'straight', 'forward',
    'go straight', 'go a little bit straight',
    'go forward', 'go a little bit forward',
    'go further', 'go a little bit further',
    'go straight down',
    'keep going straight', 'keep going forward',
    'continue going straight', 'continue going forward'
]
TURN_SUFFIXES = ['', 'here', 'up here', 'there', 'ahead', 'at the intersection']  # removed 'at the end'
TURN_SUFFIXES_FIRST = ['', 'here', 'up here', 'there', 'ahead', 'at the intersection', 'at this intersection']
TURN_SUFFIXES_SECOND = ['', 'at the second intersection']
TURN_SUFFIXES_END = ['', 'at the end of this road', 'at the end', 'at the end of the street']
TURN_EXPRESSIONS = [
    '{keyword}', 'a {keyword}', 'turn {keyword}', 'go {keyword}', 'go {keyword} turn',
    'go make a {keyword}', 'go make a {keyword} turn', 'it will be a {keyword}',
    'it will be a {keyword} turn',
    'make a {keyword}', 'make a {keyword} turn', "you're going to make a {keyword}",
    "you're going to make a {keyword} turn", "you'll make a {keyword}",
    "you'll make a {keyword} turn",
    'take a {keyword}', 'take a {keyword} turn',
    'take your {keyword}', 'take your {keyword} turn',
    "you're going to take a {keyword}", "you're going to take a {keyword} turn",
    "you're going to take your {keyword}", "you're going to take your {keyword} turn",
    "you'll take a {keyword}", "you'll take a {keyword} turn"]
CONJUNCTIONS = ['and', 'and then', 'then']
SECOND_SUFFIX = ['', 'again']


def generate_templated_sentence(keyword: str) -> List[str]:
    if keyword == 'straight':
        return generate_sentence_list_from_templates(STRAIGHT_EXPRESSIONS, STRAIGHT_PREFIXES, STRAIGHT_SUFFIXES, '')
    elif keyword in ['left', 'right', 'first left', 'first right',
                     'second left', 'second right', 'another left', 'another right']:
        return generate_sentence_list_from_templates(TURN_EXPRESSIONS, [], TURN_SUFFIXES, keyword)
    else:
        raise ValueError('invalid keyword was given {}'.format(keyword))


def generate_templated_sentence_dict() -> Dict[str, List[List[str]]]:
    sentence_dict = collections.defaultdict(list)
    sentence_group_dict = collections.defaultdict(list)
    for keyword in ['left', 'right', 'straight', 'first left', 'first right',
                    'second left', 'second right', 'another left', 'another right']:
        sentence_dict[keyword] += generate_templated_sentence(keyword)

    sentence_dict['first straight'] += generate_sentence_list_from_templates(
        STRAIGHT_EXPRESSIONS, STRAIGHT_PREFIXES, STRAIGHT_SUFFIXES_FIRST)
    sentence_dict['straight end'] += generate_sentence_list_from_templates(
        STRAIGHT_EXPRESSIONS, STRAIGHT_PREFIXES, STRAIGHT_SUFFIXES_END)
    sentence_dict['left end'] += generate_sentence_list_from_templates(TURN_EXPRESSIONS, [], TURN_SUFFIXES_END, 'left')
    sentence_dict['right end'] += generate_sentence_list_from_templates(TURN_EXPRESSIONS, [], TURN_SUFFIXES_END, 'right')

    def combine_templates(first_word, second_word, second_suffixes: List[str] = ['']):
        sentences = []
        for first, conjunction, second, second_suffix in \
                product(sentence_dict[first_word], CONJUNCTIONS, sentence_dict[second_word], second_suffixes):
            if not second_suffix and first == second:
                continue
            sentences.append(' '.join([first, conjunction, second, second_suffix]).strip())
        return sentences

    # compositional
    sentence_group_dict['left,left'].append(combine_templates('left', 'left', SECOND_SUFFIX))
    sentence_group_dict['right,right'].append(combine_templates('right', 'right', SECOND_SUFFIX))
    sentence_group_dict['left,left'].append(combine_templates('left', 'another left', SECOND_SUFFIX))
    sentence_group_dict['right,right'].append(combine_templates('right', 'another right', SECOND_SUFFIX))
    sentence_group_dict['left,right'].append(combine_templates('left', 'right'))
    sentence_group_dict['left,right'].append(combine_templates('left', 'another right'))
    sentence_group_dict['right,left'].append(combine_templates('right', 'left'))
    sentence_group_dict['right,left'].append(combine_templates('right', 'another left'))
    sentence_group_dict['left,straight'].append(combine_templates('left', 'straight'))
    sentence_group_dict['right,straight'].append(combine_templates('right', 'straight'))
    sentence_group_dict['left,straight'].append(combine_templates('first left', 'straight'))
    sentence_group_dict['right,straight'].append(combine_templates('first right', 'straight'))

    # only used for extraleft/right
    sentence_group_dict['straight,left'].append(combine_templates('straight', 'left'))
    sentence_group_dict['straight,right'].append(combine_templates('straight', 'right'))

    # special
    sentence_group_dict['second left'].append(combine_templates('first straight', 'left'))
    sentence_group_dict['second right'].append(combine_templates('first straight', 'right'))
    sentence_group_dict['first left'].append(combine_templates('straight end', 'left end'))
    sentence_group_dict['first right'].append(combine_templates('straight end', 'right end'))
    sentence_group_dict['straight,straight'].append(generate_sentence_list_from_templates(
        STRAIGHT_EXPRESSIONS, STRAIGHT_PREFIXES, STRAIGHT_SUFFIXES_TWO))

    for key in sentence_dict.keys():
        sentence_group_dict[key].append(sentence_dict[key])

    for key in ['first left', 'second left', 'first right', 'second right']:
        new_key = key.replace(' ', '')
        sentence_group_dict[new_key] = sentence_group_dict[key]

    return sentence_group_dict

