import json
import random
import shutil
from argparse import ArgumentParser
from collections import defaultdict
from functools import partial
from itertools import product, chain
from math import sqrt, pi, acos, atan2
from multiprocessing.pool import ThreadPool
from operator import attrgetter, itemgetter
from pathlib import Path
from typing import Tuple, List, Any, Dict

import cv2
import matplotlib.pyplot as plt
import msgpack
import numpy as np
import torch
from torchvision.transforms import ToTensor, Compose

from custom_carla.agents.navigation.local_planner import RoadOption
from data.manager import read_meta, read_data, read_segment
from data.storage import DataStorage, InfoStorage
from data.dataset import generate_templated_sentence, generate_templated_sentence_dict
from data.types import DriveDataFrame
from model import prepare_deeplab_model
from util.common import get_logger, add_carla_module, unique_with_islices
from util.directory import ExperimentDirectory, fetch_evaluation_setting_dir, fetch_dataset_dir, \
    mkdir_if_not_exists, frame_str, fetch_raw_data_dir
from util.image import video_from_files
from util.road_option import ROAD_OPTION_LIST
from util.serialize import raw_segments_from_dict_list, dict_list_from_raw_segments, RawSegment

logger = get_logger(__name__)
add_carla_module()


# todo: get some statistics of the dataset
# todo: train a model with variable length dataset
# todo: think about better implementation of the dataset (it is really slow now)


def visualize_waypoint(timestamp: int):
    exp_dir = ExperimentDirectory(timestamp)
    meta_dict = read_meta(exp_dir.experiment_meta_path)
    route = meta_dict['route']
    waypoints, road_options = zip(*route)
    CANVAS_SIZE = 1000, 1000
    xs = list(map(lambda p: p.transform.location.x, waypoints))
    ys = list(map(lambda p: p.transform.location.y, waypoints))
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    xs = list(map(lambda x: x - min_x, xs))
    ys = list(map(lambda y: y - min_y, ys))
    max_x -= min_x
    max_y -= min_y
    scale = min(CANVAS_SIZE[0] / max_x, CANVAS_SIZE[1] / max_y)
    xs = list(map(lambda x: int(round(scale * x)), xs))
    ys = list(map(lambda x: int(round(scale * x)), ys))
    pixels = list(zip(xs, ys))
    plt.plot(xs, ys, 'kx')

    def compute_angle(pixels):
        p1, p2, p3 = pixels
        dx1, dy1 = p1[0] - p2[0], p1[1] - p2[1]
        dx2, dy2 = p3[0] - p2[0], p3[1] - p2[1]
        dl1 = sqrt(dx1 ** 2 + dy1 ** 2)
        dl2 = sqrt(dx2 ** 2 + dy2 ** 2)
        dot = dx1 * dx2 + dy1 * dy2
        if dl1 == 0.0 or dl2 == 0.0:
            return None
        v = min(1.0, max(-1.0, dot / dl1 / dl2))
        return acos(v) / pi * 180

    for i in range(len(pixels) - 2):
        deg = compute_angle(pixels[i:i + 3])
        if deg is None:
            continue
        if deg < 90:
            print(i, deg, pixels[i:i + 3])
            plt.plot((pixels[i][0], pixels[i + 1][0], pixels[i + 2][0]),
                     (pixels[i][1], pixels[i + 1][1], pixels[i + 2][1]), 'b-')

    for i in range(len(pixels) - 1):
        p1, p2, option = pixels[i], pixels[i + 1], road_options[i]
        dx, dy = p1[0] - p2[0], p1[1] - p2[1]
        dist = sqrt(dx ** 2 + dy ** 2)
        if dist > 20 and option not in [RoadOption.CHANGELANELEFT, RoadOption.CHANGELANERIGHT]:
            print(i, dist, road_options[i])
            plt.plot((p1[0], p2[0]), (p1[1], p2[1]), 'r-')

    # for i, pixel_pair in enumerate(zip(pixels[:-1], pixels[1:])):
    #     p1, p2 = pixel_pair
    #     dx, dy = p1[0] - p2[0], p1[1] - p2[1]
    #     dist = sqrt(dx ** 2 + dy ** 2)
    #     if dist > 20:
    #         print(i, dist, road_options[i])
    #         plt.plot((p1[0], p2[0]), (p1[1], p2[1]), 'r-')

    plt.show()


def video_from_dataset(timestamp: int, evaluation: bool):
    directory = ExperimentDirectory(timestamp)
    image_paths = sorted(directory.experiment_image_dir.glob('*.png'))
    video_path = directory.experiment_root_dir / 'video.mp4'
    video_from_files(image_paths, video_path)


def spawn_actors():
    argparser = ArgumentParser(
        description=__doc__)
    argparser.add_argument(
        '--host',
        metavar='H',
        default='127.0.0.1',
        help='IP of the host server (default: 127.0.0.1)')
    argparser.add_argument(
        '-p', '--port',
        metavar='P',
        default=2000,
        type=int,
        help='TCP port to listen to (default: 2000)')
    argparser.add_argument(
        '-n', '--number-of-vehicles',
        metavar='N',
        default=10,
        type=int,
        help='number of vehicles (default: 10)')
    argparser.add_argument(
        '-d', '--delay',
        metavar='D',
        default=2.0,
        type=float,
        help='delay in seconds between spawns (default: 2.0)')
    argparser.add_argument(
        '--safe',
        action='store_true',
        help='avoid spawning vehicles prone to accidents')
    argparser.add_argument(
        '--filter',
        metavar='PATTERN',
        default='vehicle.*',
        help='actor filter (default: "vehicle.*")')
    args = argparser.parse_args()

    actor_list = []

    import carla
    client = carla.Client(args.host, args.port)
    client.set_timeout(2.0)

    try:
        world = client.get_world()
        blueprints = world.get_blueprint_library().filter(args.filter)

        if args.safe:
            blueprints = [x for x in blueprints if int(x.get_attribute('number_of_wheels')) == 4]
            blueprints = [x for x in blueprints if not x.id.endswith('isetta')]
            blueprints = [x for x in blueprints if not x.id.endswith('carlacola')]

        spawn_points = world.get_map().get_spawn_points()
        number_of_spawn_points = len(spawn_points)

        if args.number_of_vehicles < number_of_spawn_points:
            random.shuffle(spawn_points)
        elif args.number_of_vehicles > number_of_spawn_points:
            msg = 'requested %d vehicles, but could only find %d spawn points'
            logger.warning(msg, args.number_of_vehicles, number_of_spawn_points)
            args.number_of_vehicles = number_of_spawn_points

        # @todo cannot import these directly.
        SpawnActor = carla.command.SpawnActor
        SetAutopilot = carla.command.SetAutopilot
        FutureActor = carla.command.FutureActor

        batch = []
        for n, transform in enumerate(spawn_points):
            if n >= args.number_of_vehicles:
                break
            blueprint = random.choice(blueprints)
            if blueprint.has_attribute('color'):
                color = random.choice(blueprint.get_attribute('color').recommended_values)
                blueprint.set_attribute('color', color)
            blueprint.set_attribute('role_name', 'autopilot')
            batch.append(SpawnActor(blueprint, transform).then(SetAutopilot(FutureActor, True)))

        for response in client.apply_batch_sync(batch):
            if response.error:
                logger.error(response.error)
            else:
                actor_list.append(response.actor_id)

        print('spawned %d vehicles, press Ctrl+C to exit.' % len(actor_list))

        while True:
            world.wait_for_tick()

    finally:
        print('\ndestroying %d actors' % len(actor_list))
        client.apply_batch([carla.command.DestroyActor(x) for x in actor_list])


def compute_mean_and_variance():
    timestamps = [1557098561514628, 1557125063453736, 1557125334291912]
    pool = ThreadPool(len(timestamps))

    def tensor_from_numpy_image(image: np.ndarray) -> torch.Tensor:
        transforms = [ToTensor()]
        return Compose(transforms)(image)

    def compute_mean_from_timestamp(timestamp: int) -> Tuple[torch.Tensor, int]:
        directory = ExperimentDirectory(timestamp)
        image_paths = sorted(directory.experiment_image_dir.glob('*.png'))
        images = [cv2.imread(str(image_path), cv2.IMREAD_UNCHANGED) for image_path in image_paths]
        tensors = [tensor_from_numpy_image(image) for image in images]
        tensor = torch.stack(tensors)
        num_images = len(image_paths)
        tensor = tensor.view(tensor.size(0), tensor.size(1), -1)
        mean = torch.mean(torch.mean(tensor, -1), 0)
        return mean, num_images

    mean_count_list = pool.map(compute_mean_from_timestamp, timestamps)
    for mean_count, timestamp in zip(mean_count_list, timestamps):
        mean, count = mean_count
        print(timestamp, mean, count)

    return mean_count_list


def generate_video():
    root_dir = Path('/home/junha/.carla/evaluations/exp30/ga-cv64-enonehot16-defc256-wnone-len1-bal-town3/step012500')
    image_dir = root_dir / 'images'
    json_path = root_dir / 'left.json'
    with open(str(json_path), 'r') as file:
        data = json.load(file)
    frame_range_list = list(map(lambda x: x['frame_range'], data))
    for i, frame_range in enumerate(frame_range_list):
        output_path = root_dir / 'traj{:02d}.mp4'.format(i)
        image_paths = [image_dir / '{:08d}.png'.format(j) for j in range(*frame_range)]
        video_from_files(image_paths, output_path, 50)


def generate_videos_from_evaluation_dataset(timestamp: int, data_keyword: str):
    eval_path = fetch_evaluation_setting_dir() / '{:08d}.json'.format(timestamp)
    root_dir = mkdir_if_not_exists(fetch_evaluation_setting_dir() / '{:08d}'.format(timestamp) / data_keyword)
    with open(str(eval_path), 'r') as file:
        data = json.load(file)
    image_dir = fetch_dataset_dir() / '{:08d}/images'.format(timestamp)
    frame_ranges = list(map(lambda x: x['frame_range'], data['data_frames'][data_keyword]))
    for i, frame_range in enumerate(frame_ranges):
        output_path = root_dir / 'traj{:02d}.mp4'.format(i)
        image_paths = [image_dir / '{:08d}.png'.format(j) for j in range(*frame_range)]
        video_from_files(image_paths, output_path, 50)


def update_segment(timestamp: int):
    root_dir = Path.home() / '.carla/dataset/{}'.format(timestamp)
    data_path = root_dir / 'data.txt'
    segment_path = root_dir / 'segment.json'

    data_dict = read_data(data_path)
    with open(str(segment_path), 'r') as file:
        segment_dict = json.load(file)
    raw_segment_list = raw_segments_from_dict_list(segment_dict['high_level_segments'])
    complete_segments = []
    for segment in raw_segment_list:
        if all([frame_key in data_dict for frame_key in map(frame_str, segment.range)]):
            complete_segments.append(segment)
    segment_dict['meta']['index_range'] = complete_segments[0].index_range[0], complete_segments[-1].index_range[1]
    segment_dict['high_level_segments'] = dict_list_from_raw_segments(complete_segments)
    with open(str(segment_path), 'w') as file:
        json.dump(segment_dict, file, indent=2)


def visualize_segment_images(timestamp: int):
    directory = ExperimentDirectory(timestamp)
    visualization_dir = directory.experiment_root_dir / 'visualization'
    vis_files = sorted(visualization_dir.glob('*.png'))
    map_image = cv2.imread(str(directory.experiment_root_dir / 'map_image.png')).astype(dtype=np.float32)
    dimage = np.zeros(map_image.shape, dtype=np.float32)
    for f in vis_files:
        dimage += abs(cv2.imread(str(f)).astype(dtype=np.float32) - map_image)
    dimage[dimage > 255] = 255
    image = 0.5 * map_image + 0.5 * dimage
    cv2.imshow('new_image', image.astype(dtype=np.uint8))
    cv2.waitKey()
    cv2.imwrite(str(directory.experiment_root_dir / 'avg.png'), image)


def analyze_trajectories(timestamp: int):
    def angle_diff(a1, a2):
        a = a2 - a1
        da = -360 if a > 180 else (360 if a < -180 else 0)
        return a + da

    directory = ExperimentDirectory(timestamp)
    data_dict = read_data(directory.experiment_data_path)
    segment_dict = read_segment(directory.segment_path)
    segment_list = segment_dict['high_level_segments']
    for i, s in enumerate(segment_list):
        if s.road_option == RoadOption.LANEFOLLOW:
            continue
        i1, i2 = s.index_range[0], s.index_range[-1] - 1
        k1, k2 = frame_str(i1), frame_str(i2)
        d1, d2 = data_dict[k1], data_dict[k2]
        y1, y2 = d1.state.transform.rotation.yaw, d2.state.transform.rotation.yaw
        dy = angle_diff(y1, y2)
        road_name = s.road_option.name.lower()
        is_straight = abs(dy) < 5
        is_right = dy >= 5
        is_left = dy <= -5
        # is_left = abs(dy + 90) < 5
        # is_right = abs(dy - 90) < 5

        if road_name == 'left' and is_left or road_name == 'right' and is_right or road_name == 'straight' and is_straight:
            continue
        state_str = '{:3d}, {:8s}, {:+8.2f}, left {}, right {}, straight {}'.format(
            i, road_name, dy, is_left, is_right, is_straight)
        print(state_str)


def angle_test():
    def sa1(a1, a2):
        da = a2 - a1
        da = (da + 180) % 360 - 180

        angle_threshold = 5

        str_new = None
        if abs(da) < angle_threshold:
            str_new = 'straight'
            # return RoadOption.STRAIGHT
        elif da < 0.0:
            str_new = 'left'
            # return RoadOption.LEFT
        else:
            str_new = 'right'
            # return RoadOption.RIGHT
        return da, str_new

    # def sa2(a1, a2):
    #     a = a2 - a1
    #     return a + (-360 if a > 180 else (360 if a < -180 else 0))
    def sa3(a1, a2):
        t = (a2 - a1) % 180.0
        str_old = None
        if t < 1.0:
            str_old = 'straight'
        elif t > 90.0:
            str_old = 'left'
        else:
            str_old = 'right'
        return t, str_old

    s = [tuple(v) for v in list(np.random.uniform(0, 360, (1000, 2)))]
    for a1, a2 in s:
        v1 = sa1(a1, a2)
        v3 = sa3(a1, a2)
        print(v1, v3)


def fetch_invalid_images(timestamp: int):
    directory = ExperimentDirectory(timestamp)
    image_dir = directory.experiment_image_dir
    image_paths = sorted(image_dir.glob('*.png'))
    for image_path in image_paths:
        im = cv2.imread(str(image_path))
        if im is None:
            logger.error('invalid image (None): {}'.format(image_path))
        elif im.size == 0:
            logger.error('invalid image (Empty): {}'.format(image_path))


def extract_drive_data(timestamp: int, frame_index: int):
    directory = ExperimentDirectory(timestamp)
    data_dict = read_data(directory.experiment_data_path)
    frame_key = directory.frame_str(frame_index)
    return data_dict[frame_key]


def find_duplicated_trajectories(timestamp: int) -> List[int]:
    directory = ExperimentDirectory(timestamp)
    data_dict = read_data(directory.experiment_data_path)
    segment_dict = read_segment(directory.segment_path)
    low_level_segments = segment_dict['low_level_segments']
    num_segment = len(low_level_segments)
    xya_list = []
    for s, segment in enumerate(low_level_segments):
        locations = [data_dict[frame_str(f)].state.transform.location for f in segment.range]
        xs, ys = list(map(attrgetter('x'), locations)), list(map(attrgetter('y'), locations))
        mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
        a1 = atan2(my - ys[0], mx - xs[0]) * 180 / pi
        a2 = atan2(ys[-1] - my, xs[-1] - mx) * 180 / pi
        xya_list.append((mx, my, a1, a2))

    def compute_dist(v1, v2):
        return sqrt(sum([(v1[i] - v2[i]) ** 2 for i in range(len(v1))]))

    dist_threshold = 10.0
    indices = set(range(num_segment))
    edge_dict = defaultdict(list)
    for i, v1 in enumerate(xya_list):
        ivl = sorted([(j, compute_dist(v1, xya_list[j])) for j in range(i + 1, len(xya_list))], key=lambda x: x[1])
        edge_dict[i] = list(map(itemgetter(0), filter(lambda x: x[1] < dist_threshold, ivl)))
        print(i, *v1, edge_dict[i])

    visited = [False for _ in range(num_segment)]
    unique_indices = []
    for i in range(num_segment):
        if visited[i]:
            continue
        visited[i] = True
        for n in edge_dict[i]:
            visited[n] = True
        unique_indices.append(i)

    print(len(unique_indices))
    road_options = list(map(lambda i: low_level_segments[i].road_option, unique_indices))
    print(list(zip(unique_indices, road_options)))
    for opt in ROAD_OPTION_LIST:
        print(opt, len(list(filter(lambda x: x == opt, road_options))))
    return unique_indices


def race_file_reader():
    a = 'abcd\refg\rhig'
    a = {
        'abcd': 'efg',
        '123': 4,
        5: '789'
    }
    b = msgpack.packb(a)
    print(b)

    # c = bytes('\xa3', 'ascii')
    # d = c.decode('ascii')
    # print(c, d)

    # filename = 'race.miami-lights.miami-sunset.1554654433641'
    # filename = 'race.miami-lights.miami-sunset.1558211896897'
    # filename = 'race.miami-lights.miami-sunset.1552759407176'
    filename = 'race.miami-lights.miami-sunset.1553035574214'
    filepath = Path.home() / 'Downloads/{}.race'.format(filename)
    with open(str(filepath), 'rb') as f:
        data = f.read()

    # aa = [chr(v) for v in data[565:4636]]
    # print(aa)

    rindices = list(map(itemgetter(0), filter(lambda x: x[1] == ord('\r'), enumerate(data))))
    rindices = [0] + rindices + [len(data)]
    for i1, i2 in zip(rindices[:-1], rindices[1:]):
        print(i1 + 1, i2 - 1, data[i1 + 1:i2], ''.join([chr(v) for v in data[i1 + 1:i2]]))

    # for i in range(len(data)):
    #     if data[i] == ord('\r'):
    #         print(i, data[i])

    # for c in data:
    #     print(c)
    # print(len(data), data)


def generate_videos_from_dataset_snippet(timestamp: int):
    root_dir = fetch_raw_data_dir() / '{:08d}'.format(timestamp)
    image_dir = root_dir / 'images'
    video_dir = mkdir_if_not_exists(root_dir / 'videos')
    image_paths = sorted(image_dir.glob('*c.png'))[1800:3600]
    # print(image_paths[0], image_paths[-1])
    # segment_path = root_dir / 'segment.json'
    # segments = read_segment(segment_path)
    # high_level_segments = segments['high_level_segments']

    output_path = video_dir / 'snippet2.mp4'
    video_from_files(image_paths, output_path, framerate=30)


def generate_video_from_figures(figure_dir: Path, out_path: Path):
    figure_filepaths = sorted(figure_dir.glob('*.png'))[:300]
    video_from_files(figure_filepaths, out_path, framerate=8, revert=False)


def parse_transcript(filter_label: int):
    transcript_path = Path.home() / 'Downloads/transcript.txt'
    with open(str(transcript_path), 'r') as file:
        lines = file.read().splitlines()
    lines = list(filter(lambda x: x, lines))
    words = list(map(lambda x: x.split(','), lines))
    words = list(filter(lambda x: len(x) == 4, words))
    sentence_label_list = list(map(lambda x: (x[2], int(x[3])), words))
    # sentence_label_list = list(filter(lambda x: x[1] == filter_label, sentence_label_list))
    sentences = list(map(itemgetter(0), sentence_label_list))

    def remove_clutter(sentence: str):
        clutters = ['and', 'then', 'oh', 'okay', 'uh', 'um', 'well', 'now', 'yeah']
        words = sentence.split(' ')
        words = list(filter(lambda x: x not in clutters, words))
        return ' '.join(words)

    sentences = list(map(remove_clutter, sentences))
    unique_sentences = list(set(sentences))

    def has_words(target_sentence: str, query_words: List[str]):
        words = target_sentence.split(' ')
        for query in query_words:
            if query in words:
                return True
        return False

    def has_next(target_sentence: str):
        query_words = ['next', 'again', 'another']
        return has_words(target_sentence, query_words)

    sentences_with_next = list(filter(has_next, unique_sentences))
    sentences_without_next = list(filter(lambda x: not has_next(x), unique_sentences))
    for i, sentence in enumerate(sentences_with_next):
        print(i, sentence)
    for i, sentence in enumerate(sentences_without_next):
        print(i, sentence)


def read_segment_info(segment_path: Path):
    with open(str(segment_path), 'r') as file:
        data = json.load(file)
    index_range = data['meta']['index_range']
    low_level_segments = data['low_level_segments']
    high_level_segments = data['high_level_segments']
    print(index_range, len(low_level_segments), len(high_level_segments))
    print(low_level_segments[0], low_level_segments[-1])
    print(high_level_segments[1], high_level_segments[-1])


def read_and_draw_locations(indices: List[int], suffix: str):
    root_dir = Path.home() / '.tmp/high-level'

    with open(str(root_dir / 'training.json'), 'r') as file:
        training_locations = json.load(file)

    with open(str(root_dir / 'info.json'), 'r') as file:
        all_locations = json.load(file)

    eval_locations = []
    directories = sorted(filter(lambda x: x.is_dir(), root_dir.glob('*')))
    for d in directories:
        with open(str(d / 'data.json'), 'r') as file:
            eval_locations.append(list(map(lambda x: x['location'], json.load(file))))

    def select_value_from_indices(values, indices):
        return [values[i] for i in indices]
    select = partial(select_value_from_indices, indices=indices)

    training_locations = list(map(select, training_locations))
    eval_locations = list(map(select, eval_locations))

    training_locations = chain.from_iterable(training_locations)
    eval_locations = chain.from_iterable(eval_locations)
    ax, ay = zip(*all_locations)
    tx, ty = zip(*training_locations)
    ex, ey = zip(*eval_locations)

    plt.plot(ax, ay, 'C1-', label='all')
    plt.plot(tx, ty, 'C2x', label='training')
    plt.plot(ex, ey, 'C3x', label='evaluation')
    plt.legend()
    plt.axes().set_aspect('equal', 'datalim')
    plt.savefig(str(root_dir / 'fig-{}.png'.format(suffix)))
    plt.cla()


def test_eval_dataset():
    segment_path = Path.home() / '.carla/dataset/info/test1/segment.json'
    image_dir = Path.home() / '.carla/rawdata/1560214428354222/images'
    with open(str(segment_path), 'r') as file:
        data = json.load(file)['low_level_segments']
    index_range_list = list(map(lambda x: x['indices'], data))
    keywords = ['l', 'c', 'r']
    indices = list(chain.from_iterable([list(range(*i)) for i in index_range_list]))
    index_keyword_list = product(indices, keywords)

    storage = DataStorage(False, Path.home() / '.carla/dataset/data/test1', True)
    image_path_list = [image_dir / '{:08d}{}.png'.format(index, keyword) for index, keyword in index_keyword_list]
    storage.put_images_from_paths(image_path_list)

    experiment_dir = ExperimentDirectory(1560214428354222)
    drive_dict = read_data(experiment_dir.experiment_data_path)
    for index in indices:
        frame_number = '{:08d}'.format(index)
        drive = drive_dict[frame_number]
        storage.put_drive(index, drive)


def annotation_helper(data_name: str, info_name: str):
    root_data_dir = Path.home() / '.carla/dataset/data/{}'.format(data_name)
    root_info_dir = Path.home() / '.carla/dataset/info/{}'.format(info_name)
    if not root_info_dir.exists():
        raise ValueError('invalid info name {}'.format(info_name))
    segment_path = root_info_dir / 'segment.json'
    image_dir = root_info_dir / 'high_level_figures'
    storage = DataStorage(True, root_data_dir, True)
    with open(str(segment_path), 'r') as file:
        data = json.load(file)['high_level_segments']

    sentences = [d['sentence'].lower().split(',') for d in data]
    sequences = [d['sequence'] for d in data]
    logger.info('found {} sentences, {} sequences'.format(len(sentences), len(sequences)))
    second_lefts, second_rights = [], []
    for i, sentence in enumerate(sentences):
        if len(sentence) == 1:
            continue
        if sentence[0] in ['straight', 'extraleft', 'extraright']:
            if sentence[1] == 'left':
                second_lefts.append(i)
            elif sentence[1] == 'right':
                second_rights.append(i)
    logger.info('found {}, {} second lefts and rights'.format(len(second_lefts), len(second_rights)))
    logger.info('lefts ... {}'.format(second_lefts[-5:]))
    logger.info('rights ... {}'.format(second_rights[-5:]))

    def fetch_location(drive_frame: DriveDataFrame):
        return drive_frame.state.transform.location.x, drive_frame.state.transform.location.y

    def fetch_mean_location(drive_frames: List[DriveDataFrame]):
        xs, ys = zip(*list(map(fetch_location, drive_frames)))
        return sum(xs) / len(xs), sum(ys) / len(ys)

    def compute_average_dist(l1, l2):
        dist = 0.0
        for (x1, y1), (x2, y2) in zip(l1, l2):
            dist += (x2 - x1) ** 2 + (y2 - y1) ** 2
        return sqrt(dist)

    def compute_clusters(segment_indices: List[int]) -> List[List[int]]:
        indices = [0, 2, 4]
        locations = []
        for i in segment_indices:
            sequence = [sequences[i][j] for j in indices]
            drives = list(map(lambda x: storage.get_drives(list(range(x[0], x[1]))), sequence))
            locations.append(list(map(fetch_mean_location, drives)))

        cluster_index_dict = dict()
        cluster_index_list_dict = defaultdict(list)
        cluster_index = 0
        dist_threshold = 10.0
        for i, l1 in zip(range(len(segment_indices)), locations):
            valid = True
            for j, k in cluster_index_dict.items():
                dist = compute_average_dist(l1, locations[k])
                if dist < dist_threshold:
                    valid = False
                    cluster_index_list_dict[j].append(i)
                    break
            if valid:
                cluster_index_dict[cluster_index] = i
                cluster_index_list_dict[cluster_index].append(i)
                cluster_index += 1

        cluster_indices = []
        for indices in cluster_index_list_dict.values():
            cluster_indices.append([segment_indices[i] for i in indices])
        return cluster_indices

    def copy_images_from_cluster_indices(cluster_indices, dst_image_dir):
        for i in range(len(cluster_indices)):
            curr_image_dir = mkdir_if_not_exists(dst_image_dir / '{:02d}'.format(i))
            indices = cluster_indices[i]
            for j in indices:
                filename = 'segment{:05d}.png'.format(j)
                src = image_dir / filename
                dst = curr_image_dir / filename
                if src.exists():
                    shutil.copy(str(src), str(dst))
            dst = dst_image_dir / '{:03d}.png'.format(i)
            if src.exists():
                shutil.copy(str(src), str(dst))

    target_image_dir = Path.home() / '.tmp/annotation'
    left_image_dir = mkdir_if_not_exists(target_image_dir / 'second_lefts')
    right_image_dir = mkdir_if_not_exists(target_image_dir / 'second_rights')
    left_cluster_indices = compute_clusters(second_lefts)
    right_cluster_indices = compute_clusters(second_rights)
    logger.info('found {} left clusters {}'.format(len(left_cluster_indices), left_cluster_indices))
    logger.info('found {} right clusters {}'.format(len(right_cluster_indices), right_cluster_indices))
    copy_images_from_cluster_indices(left_cluster_indices, left_image_dir)
    copy_images_from_cluster_indices(right_cluster_indices, right_image_dir)

    valid_second_lefts = [0, 1, 2, 3, 4, 6, 9, 10]
    invalid_second_lefts = [5, 7, 8]
    valid_second_rights = [0, 1, 2, 3, 5, 6, 8, 9]
    invalid_second_rights = [4, 7]

    sl1, sl2 = set(valid_second_lefts), set(invalid_second_lefts)
    sr1, sr2 = set(valid_second_rights), set(invalid_second_rights)
    assert all([i not in sl2 for i in sl1])
    assert all([i not in sr2 for i in sr1])
    assert len(valid_second_lefts + invalid_second_lefts) == len(left_cluster_indices)
    assert len(valid_second_rights + invalid_second_rights) == len(right_cluster_indices)

    valid_second_lefts = list(chain.from_iterable([left_cluster_indices[i] for i in valid_second_lefts]))
    invalid_second_lefts = list(chain.from_iterable([left_cluster_indices[i] for i in invalid_second_lefts]))
    valid_second_rights = list(chain.from_iterable([right_cluster_indices[i] for i in valid_second_rights]))
    invalid_second_rights = list(chain.from_iterable([right_cluster_indices[i] for i in invalid_second_rights]))

    logger.info((' left,   valid', valid_second_lefts))
    logger.info((' left, invalid', invalid_second_lefts))
    logger.info(('right,   valid', valid_second_rights))
    logger.info(('right, invalid', invalid_second_rights))

    second_turn_dict = {
        'firstleft': invalid_second_lefts,
        'secondleft': valid_second_lefts,
        'firstright': invalid_second_rights,
        'secondright': valid_second_rights
    }
    with open(str(root_info_dir / 'second_turn.json'), 'w') as file:
        json.dump(second_turn_dict, file, indent=2)


def fetch_trajectory_info_from_test2():
    data_storage = DataStorage(True, Path.home() / '.carla/dataset/data/test2', True)
    info_storage = InfoStorage(data_storage, False, True, Path.home() / '.carla/dataset/info/test2')
    trajectories: List[RawSegment] = info_storage.get_trajectories()
    sequences = info_storage.get_sequences()

    for i, t in enumerate(trajectories):
        logger.info((i, t.index_range))
    for i, s in enumerate(sequences):
        logger.info((i, s))


def show_segmentation_image():
    image_path = Path.home() / '.carla/rawdata/1560997763936855/segments/00001926c.png'
    image = cv2.imread(str(image_path))[:, :, 2]
    w = (image == 7).astype(dtype=np.uint8) * 255
    cv2.imshow('image', w)
    cv2.waitKey()


def count_images():
    data_db_path = Path.home() / '.carla/dataset/data/semantic2'
    data_storage = DataStorage(read_only=True, db_path=data_db_path, use_multi_cam=True)
    print(data_storage.num_image_frames)


def unique_trajectories(data_name: str, info_name: str):
    root_data_dir = Path.home() / '.carla/dataset/data/{}'.format(data_name)
    root_info_dir = Path.home() / '.carla/dataset/info/{}'.format(info_name)
    if not root_info_dir.exists():
        raise ValueError('invalid info name {}'.format(info_name))
    segment_path = root_info_dir / 'segment.json'
    image_dir = root_info_dir / 'high_level_figures'
    storage = DataStorage(True, root_data_dir, True)
    with open(str(segment_path), 'r') as file:
        data = json.load(file)['high_level_segments']

    sentence_dict = defaultdict(list)
    for i, d in enumerate(data):
        if 'extra' in d['sentence'].lower():
            sentence_dict[d['sentence'].lower()].append(i)

    sentences = [d['sentence'].lower().split(',') for d in data]
    sequences = [d['sequence'] for d in data]

    count = 0
    for s in sequences:
        count += len(s)
    print(count)

    def cut_sequence_with_extra_straight(sequences: List[Tuple[int, int, str]]):
        index = -1
        for i, item in enumerate(sequences):
            if item[-1].lower() == 'extrastraight':
                index = i
                break
        if index >= 0:
            return sequences[:index + 1]
        else:
            return sequences

    sequences = list(map(cut_sequence_with_extra_straight, sequences))

    count = 0
    for s in sequences:
        count += len(s)
    print(count)

    def fetch_location(drive_frame: DriveDataFrame):
        return drive_frame.state.transform.location.x, drive_frame.state.transform.location.y

    def fetch_mean_location(drive_frames: List[DriveDataFrame]):
        xs, ys = zip(*list(map(fetch_location, drive_frames)))
        return sum(xs) / len(xs), sum(ys) / len(ys)

    def compute_average_dist(l1, l2):
        dist = 0.0
        for (x1, y1), (x2, y2) in zip(l1, l2):
            dist += (x2 - x1) ** 2 + (y2 - y1) ** 2
        return sqrt(dist)

    def compute_clusters(segment_indices: List[int]) -> List[List[int]]:
        # indices = [0, 2, 4] if len(segment_indices) == 5 else [0, 2]
        locations = []
        for i in segment_indices:
            indices = list(map(itemgetter(0),
                               filter(lambda x: x[1][-1].lower() == 'lanefollow', enumerate(sequences[i]))))
            sequence = [sequences[i][j] for j in indices]
            drives = list(map(lambda x: storage.get_drives(list(range(x[0], x[1]))), sequence))
            locations.append(list(map(fetch_mean_location, drives)))

        cluster_index_dict = dict()
        cluster_index_list_dict = defaultdict(list)
        cluster_index = 0
        dist_threshold = 10.0
        for i, l1 in zip(range(len(segment_indices)), locations):
            valid = True
            for j, k in cluster_index_dict.items():
                dist = compute_average_dist(l1, locations[k])
                if dist < dist_threshold:
                    valid = False
                    cluster_index_list_dict[j].append(i)
                    break
            if valid:
                cluster_index_dict[cluster_index] = i
                cluster_index_list_dict[cluster_index].append(i)
                cluster_index += 1

        cluster_indices = []
        for indices in cluster_index_list_dict.values():
            cluster_indices.append([segment_indices[i] for i in indices])
        return cluster_indices

    def copy_images_from_cluster_indices(cluster_indices, dst_image_dir):
        for i in range(len(cluster_indices)):
            curr_image_dir = mkdir_if_not_exists(dst_image_dir / '{:02d}'.format(i))
            indices = cluster_indices[i]
            for j in indices:
                filename = 'segment{:05d}.png'.format(j)
                src = image_dir / filename
                dst = curr_image_dir / filename
                if src.exists():
                    shutil.copy(str(src), str(dst))
            dst = dst_image_dir / '{:03d}.png'.format(i)
            if src.exists():
                shutil.copy(str(src), str(dst))

    def save_figures(root_dir: Path, index: int, sentence: str, sequences: List[Tuple[int, int, str]]):
        import matplotlib.pyplot as plt

        def fetch_color_code(intersection: bool, option: str) -> str:
            option_code = {
                'left': 'g',
                'right': 'r',
                'straight': 'b',
                'extraleft': 'b',
                'extraright': 'b',
                'extrastraight': 'b',
                'extrastraightleft': 'g',
                'extrastraightright': 'r',
                'lanefollow': 'k',
                'stop': 'y'}
            inter_code = {True: 'o', False: '-'}
            return '{}{}'.format(option_code[option], inter_code[intersection])

        def draw_segment_(intersection: bool, option: str, index_range: Tuple[int, int]):
            drives: List[DriveDataFrame] = storage.get_drives(list(range(*index_range)))
            xs, ys = zip(*[(d.state.transform.location.x, -d.state.transform.location.y) for d in drives])
            cc = fetch_color_code(intersection, option.lower())
            plt.plot(xs, ys, cc, label='{}:{}'.format(option, str(intersection)))

        def draw_text(text: str, index_range: Tuple[int, int]):
            index = index_range[0] + (index_range[1] - index_range[0]) // 2
            drive = storage.get_drive(index)
            x, y = drive.state.transform.location.x, drive.state.transform.location.y
            plt.text(x + 2, -y, text)

        def draw_segment(segment: Tuple[int, int, str]):
            i1, i2, option = segment
            intersection = False if option == 'LANEFOLLOW' else True
            draw_segment_(intersection, option, (i1, i2))

        def draw_high_level_segment(sentence: str, sequences: List[Tuple[int, int, str]]):
            sequence = list(filter(lambda x: x[0] < x[1], sequences))
            for i1, i2, opt in sequence:
                intersection = False if opt == 'LANEFOLLOW' else True
                draw_segment_(intersection, opt, (i1, i2))

        try:
            draw_high_level_segment(sentence, sequences)
            draw_text(str(index), sequences[0][:2])
            plt.legend()
            plt.axes().set_aspect('equal', 'datalim')
            plt.savefig(str(root_dir / 'fig{:02d}.png'.format(index)))
        finally:
            plt.cla()

    cluster_dict = defaultdict(list)
    for key, value in sentence_dict.items():
        cluster_dict[key] = compute_clusters(value)

    for key, value in cluster_dict.items():
        print('found {} clusters from {}'.format(len(value), key))

    root_dir = Path.home() / '.tmp/annotation'
    for key, cluster_indices in cluster_dict.items():
        turn_dir = mkdir_if_not_exists(root_dir / key)
        for i, cluster_index in enumerate(cluster_indices):
            save_figures(turn_dir, i, key, sequences[cluster_index[0]])


    #
    # target_image_dir = Path.home() / '.tmp/annotation'
    # left_image_dir = mkdir_if_not_exists(target_image_dir / 'second_lefts')
    # right_image_dir = mkdir_if_not_exists(target_image_dir / 'second_rights')
    # left_cluster_indices = compute_clusters(second_lefts)
    # right_cluster_indices = compute_clusters(second_rights)
    # logger.info('found {} left clusters {}'.format(len(left_cluster_indices), left_cluster_indices))
    # logger.info('found {} right clusters {}'.format(len(right_cluster_indices), right_cluster_indices))
    # copy_images_from_cluster_indices(left_cluster_indices, left_image_dir)
    # copy_images_from_cluster_indices(right_cluster_indices, right_image_dir)
    #
    # valid_second_lefts = [0, 1, 2, 3, 4, 6, 9, 10]
    # invalid_second_lefts = [5, 7, 8]
    # valid_second_rights = [0, 1, 2, 3, 5, 6, 8, 9]
    # invalid_second_rights = [4, 7]
    #
    # sl1, sl2 = set(valid_second_lefts), set(invalid_second_lefts)
    # sr1, sr2 = set(valid_second_rights), set(invalid_second_rights)
    # assert all([i not in sl2 for i in sl1])
    # assert all([i not in sr2 for i in sr1])
    # assert len(valid_second_lefts + invalid_second_lefts) == len(left_cluster_indices)
    # assert len(valid_second_rights + invalid_second_rights) == len(right_cluster_indices)
    #
    # valid_second_lefts = list(chain.from_iterable([left_cluster_indices[i] for i in valid_second_lefts]))
    # invalid_second_lefts = list(chain.from_iterable([left_cluster_indices[i] for i in invalid_second_lefts]))
    # valid_second_rights = list(chain.from_iterable([right_cluster_indices[i] for i in valid_second_rights]))
    # invalid_second_rights = list(chain.from_iterable([right_cluster_indices[i] for i in invalid_second_rights]))
    #
    # logger.info((' left,   valid', valid_second_lefts))
    # logger.info((' left, invalid', invalid_second_lefts))
    # logger.info(('right,   valid', valid_second_rights))
    # logger.info(('right, invalid', invalid_second_rights))
    #
    # second_turn_dict = {
    #     'firstleft': invalid_second_lefts,
    #     'secondleft': valid_second_lefts,
    #     'firstright': invalid_second_rights,
    #     'secondright': valid_second_rights
    # }
    # with open(str(root_info_dir / 'second_turn.json'), 'w') as file:
    #     json.dump(second_turn_dict, file, indent=2)


def test_sentence_dict():
    sentence_dict = generate_templated_sentence_dict()
    keywords = [
        'left', 'right', 'straight',
        'left,left', 'left,right', 'left,straight',
        'right,left', 'right,right', 'right,straight', 'straight,straight',
        'first left', 'first right', 'second left', 'second right']

    example_dict = dict()
    for key, sentence_groups in sentence_dict.items():
        if key not in keywords:
            continue
        examples = []
        for i, sentence_group in enumerate(sentence_groups):
            random.shuffle(sentence_group)
            examples.append(sentence_group[:10])
        example_dict[key] = examples

    with open(str(Path.home() / '.tmp/example_sentences.json'), 'w') as file:
        json.dump(example_dict, file, indent=4)


def generate_video_with_sentences(index: int):
    root_dir = Path.home() / '.carla/evaluations/exp37/gs1-town1-new1/step100000/online'
    image_dir = Path.home() / '.carla/rawdata/1562370389472834/images'
    state_path = root_dir / 'states/traj{:02d}.json'.format(index)
    video_path = root_dir / 'traj{:02d}.mp4'.format(index)
    with open(str(state_path), 'r') as file:
        data = json.load(file)
    index_range = data['frame_range']
    image_paths = [image_dir / '{:08d}e.png'.format(f) for f in range(*index_range)]
    # image_paths = [root_dir / 'images/{:08d}c.png'.format(f) for f in range(*index_range)]
    subtasks = list(map(itemgetter(1), data['stop_frames']))
    sentences = data['sentences']
    texts = ['sentence: {}\nsubtask: {}'.format(s, t) for t, s in zip(subtasks, sentences)]
    logger.info((len(image_paths), len(subtasks), len(sentences), len(texts)))
    image_paths = image_paths[:len(texts)]
    video_from_files(image_paths, video_path, texts=texts, framerate=30, revert=True)


    def save_figures(self, infos: List[FrameInfo]):
        if not self.verbose:
            return

        import matplotlib.pyplot as plt
        info_dict = self.segment_dict['info_dict']



        def draw_segment_(intersection: bool, option: str, index_range: Tuple[int, int]):
            indices = [info_dict[i] for i in range(index_range[0], index_range[1], 5)]
            xs, ys = zip(*[(infos[i].x, -infos[i].y) for i in indices])
            cc = fetch_color_code(intersection, option.lower())
            plt.plot(xs, ys, cc, label='{}:{}'.format(option, str(intersection)))

        def draw_text(text: str, index_range: Tuple[int, int]):
            i1, i2 = info_dict[index_range[0]], info_dict[index_range[1]]
            index = i1 + (i2 - i1) // 2
            plt.text(infos[index].x + 2, -infos[index].y, text)

        def draw_segment(segment: Dict[str, Any]):
            option, index_range = segment['option'], segment['indices']
            intersection = False if option == 'LANEFOLLOW' else True
            draw_segment_(intersection, option, index_range)

        def draw_high_level_segment(segment: Dict[str, Any]):
            sentence, sequence = segment['sentence'], segment['sequence']
            sequence = list(filter(lambda x: x[0] < x[1], sequence))
            for i1, i2, opt in sequence:
                intersection = False if opt == 'LANEFOLLOW' else True
                draw_segment_(intersection, opt, (i1, i2))

        ixs, iys = list(map(lambda x: x.x, infos))[:10000], list(map(lambda x: -x.y, infos))[:10000]

        logger.info('saving {} high-level segments'.format(len(self.high_level_segments)))

        if not self.unique:
            for i, segment in enumerate(self.high_level_segments):
                # logger.info('drawing {}, {}'.format(i, segment))
                try:
                    plt.plot(ixs, iys, 'C1-')
                    draw_high_level_segment(segment)
                    draw_text(str(i), segment['sequence'][0][:2])
                    plt.legend()
                    plt.axes().set_aspect('equal', 'datalim')
                    plt.savefig(str(self.dataset_high_level_figure_path(i)))
                finally:
                    plt.cla()
        for i, segment in enumerate(self.low_level_segments):
            plt.plot(ixs, iys, 'C1-')
            draw_segment(segment)
            draw_text(str(i), segment['indices'])
            plt.legend()
            plt.axes().set_aspect('equal', 'datalim')
            plt.savefig(str(self.dataset_low_level_figure_path(i)))
            plt.cla()


def draw_trajectory(map_index: int):

    def fetch_color_code(option: str) -> str:
        option_code = {
            'left': 'C0',
            'right': 'C3',
            'straight': 'C1',
            'newfollow': 'C2',
            'extraleft': 'C2',
            'extraright': 'C2',
            'extrastraight': 'b',
            'extrastraightleft': 'g',
            'extrastraightright': 'r',
            'lanefollow': 'k',
            'stop': 'y'}
        # inter_code = {True: 'o', False: 'o'}
        intersection = option in ['left', 'right', 'straight']
        return option_code[option]
        #return '{}{}'.format(option_code[option], inter_code)

    def fetch_default_trajectory(map_index: int, num_traj: int):
        rawdata = '1561065444962896' if map_index == 1 else '1560998639947491'
        data_path = Path.home() / '.carla/rawdata/{}/data.txt'.format(rawdata)
        with open(str(data_path), 'r') as file:
            lines = file.read().splitlines()[:num_traj]
        lines = list(map(lambda x: x.split(':')[1], lines))
        xs = list(map(lambda x: float(x.split(',')[0]), lines))
        ys = list(map(lambda x: -float(x.split(',')[1]), lines))
        return xs, ys

    def fetch_sequences(map_index: int):
        data_path = Path.home() / '.carla/dataset/info/semantic{}-v37/segment.json'.format(map_index)
        with open(str(data_path), 'r') as file:
            data = json.load(file)
        return data['low_level_segments']

    dxs, dys = fetch_default_trajectory(map_index, 50000)
    ds = DataStorage(True, Path.home() / '.carla/dataset/data/semantic{}'.format(map_index), True)
    lls = fetch_sequences(map_index)

    for i in range(0, 800, 20):
        sequence = lls[i:i+20]
        traj_dir = mkdir_if_not_exists(Path.home() / '.tmp/drawing')
        traj_path = traj_dir / 'map{}-{:03d}.png'.format(map_index, i)
        plt.plot(dxs, dys, fetch_color_code('lanefollow'), linewidth=4)
        sequence = sequence[::-1]
        for s in sequence:
            opt, (i1, i2) = s['option'], s['indices']
            if opt == 'LANEFOLLOW':
                opt = 'NEWFOLLOW'
            data_frames = ds.get_drives(list(range(i1, i2)))
            color_code = fetch_color_code(opt.lower())
            xs = list(map(lambda x: x.state.transform.location.x, data_frames))
            ys = list(map(lambda x: -x.state.transform.location.y, data_frames))
            plt.plot(xs, ys, color=color_code, linewidth=8)
            plt.plot(xs[-1], ys[-1], color=color_code, marker='o', markersize=12)
        plt.axes().set_aspect('equal', 'datalim')
        plt.axis('off')
        fig = plt.gcf()
        fig.set_size_inches(18.5, 10.5)
        plt.savefig(traj_path, bbox_inches='tight', dpi=100)
        plt.cla()


    # root_dir = Path.home() / '.carla/evaluations/exp37/gs1-town1-new1/step100000/left,right'
    # state_path = root_dir / 'states/traj{:02d}.json'.format(index)
    # video_path = root_dir / 'traj{:02d}.mp4'.format(index)
    # with open(str(state_path), 'r') as file:
    #     data = json.load(file)
    # data_frames = data['data_frames']
    # data_frames = [f.split(',') for f in data_frames]
    # stop_frames = list(map(itemgetter(1), data['stop_frames']))
    # xs = list(map(lambda x: float(x[0]), data_frames))
    # ys = list(map(lambda x: float(x[1]), data_frames))
    # for opt, (i1, i2) in sorted(unique_with_islices(stop_frames)):
    #     plt.plot(xs[i1:i2], ys[i1:i2], fetch_color_code(opt))
    # plt.axes().set_aspect('equal', 'datalim')
    # plt.axis('off')
    # fig = plt.gcf()
    # fig.set_size_inches(18.5, 10.5)
    # plt.savefig(str(root_dir / 'traj{:02d}.png'.format(index)), bbox_inches='tight', dpi=100)
    # plt.cla()

    # draw_default_trajectory(1, 50000)
    # root_dir = Path.home() / '.carla/evaluations/exp37/gs1-town1-new1/step100000/left,right'
    # state_path = root_dir / 'states/traj{:02d}.json'.format(index)
    # video_path = root_dir / 'traj{:02d}.mp4'.format(index)
    # with open(str(state_path), 'r') as file:
    #     data = json.load(file)
    # data_frames = data['data_frames']
    # data_frames = [f.split(',') for f in data_frames]
    # stop_frames = list(map(itemgetter(1), data['stop_frames']))
    # xs = list(map(lambda x: float(x[0]), data_frames))
    # ys = list(map(lambda x: float(x[1]), data_frames))
    # for opt, (i1, i2) in sorted(unique_with_islices(stop_frames)):
    #     plt.plot(xs[i1:i2], ys[i1:i2], fetch_color_code(opt))
    # plt.axes().set_aspect('equal', 'datalim')
    # plt.axis('off')
    # fig = plt.gcf()
    # fig.set_size_inches(18.5, 10.5)
    # plt.savefig(str(root_dir / 'traj{:02d}.png'.format(index)), bbox_inches='tight', dpi=100)
    # plt.cla()

    # index_range = data['frame_range']
    # image_paths = [root_dir / 'images/{:08d}c.png'.format(f) for f in range(*index_range)]
    # subtasks = list(map(itemgetter(1), data['stop_frames']))
    # sentences = data['sentences']
    # texts = ['sentence: {}\nsubtask: {}'.format(s, t) for t, s in zip(subtasks, sentences)]
    # logger.info((len(image_paths), len(subtasks), len(sentences), len(texts)))
    # video_from_files(image_paths, video_path, texts=texts, framerate=30, revert=True)


def segment_images(root_dir: Path):
    in_dir = root_dir / 'images'
    out_dir = mkdir_if_not_exists(root_dir / 'customs')
    in_image_filepaths = in_dir.glob('*.png')
    deeplab_model = prepare_deeplab_model()
    for in_path in in_image_filepaths:
        in_image = cv2.imread(str(in_path))
        out_seg = deeplab_model.run(in_image)
        cv2.imwrite(str(out_dir / '{}.png'.format(in_path.stem)), out_seg)


def draw_trajectory_online():
    map_index = 1
    seq_path = Path.home() / '.carla/evaluations/exp37/gs1-town1-new1/step100000/online/states/traj01.json'

    def fetch_color_code(option: str) -> str:
        option_code = {
            'left': 'C0',
            'right': 'C3',
            'straight': 'C1',
            'newfollow': 'C2',
            'extraleft': 'C2',
            'extraright': 'C2',
            'extrastraight': 'b',
            'extrastraightleft': 'g',
            'extrastraightright': 'r',
            'lanefollow': 'k',
            'stop': 'y'}
        intersection = option in ['left', 'right', 'straight']
        return option_code[option]

    def fetch_default_trajectory(map_index: int, num_traj: int):
        rawdata = '1561065444962896' if map_index == 1 else '1560998639947491'
        data_path = Path.home() / '.carla/rawdata/{}/data.txt'.format(rawdata)
        with open(str(data_path), 'r') as file:
            lines = file.read().splitlines()[:num_traj]
        lines = list(map(lambda x: x.split(':')[1], lines))
        xs = list(map(lambda x: float(x.split(',')[0]), lines))
        ys = list(map(lambda x: -float(x.split(',')[1]), lines))
        return xs, ys

    def fetch_sequences(map_index: int):
        data_path = Path.home() / '.carla/dataset/info/semantic{}-v37/segment.json'.format(map_index)
        with open(str(data_path), 'r') as file:
            data = json.load(file)
        return data['low_level_segments']

    def fetch_sequences_online(seq_path: Path):
        with open(str(seq_path), 'r') as file:
            data = json.load(file)
        xs, ys = zip(*list(map(lambda x: tuple([float(v) for v in x.split(',')[:2]]), data['data_frames'])))
        frame_range = data['frame_range']
        sentences = data['sentences']
        subgoals = list(map(itemgetter(1), data['stop_frames']))
        return xs, ys, frame_range, sentences, subgoals

    ds = DataStorage(True, Path.home() / '.carla/dataset/data/semantic{}'.format(map_index), True)
    dxs, dys = fetch_default_trajectory(map_index, 50000)
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.plot(dxs, dys, fetch_color_code('lanefollow'), linewidth=4)

    xs, ys, frame_range, sentences, subgoals = fetch_sequences_online(seq_path)
    ys = [-v for v in ys]
    traj_dir = mkdir_if_not_exists(Path.home() / '.tmp/traj_online')
    traj_path = traj_dir / 'map{}-{}.png'.format(map_index, seq_path.stem)

    sentence_index_list = unique_with_islices(sentences)
    print(sentence_index_list)
    for i, (sentence, (i1, i2)) in enumerate(sentence_index_list):
        words = sentence.split(' ')
        if len(words) > 7:
            sentence = ' '.join(words[:len(words) // 2 + 1]) + '\n' + ' '.join(words[len(words) // 2 + 1:])
        color_code = 'C{}'.format(i)
        ax.plot(xs[i2-1], ys[i2-1], color=color_code, marker='o', markersize=12)
        ax.plot(xs[i1:i2], ys[i1:i2], color=color_code, linewidth=8)
        ax.plot(xs[i1], ys[i1], color=color_code, marker='o', markersize=12)
        mx, my = xs[(2 * i1 + i2) // 3] - 10, ys[(2 * i1 + i2) // 3] + 10
        # ax.text(mx, my, sentence, fontsize=15)
    plt.axes().set_aspect('equal', 'datalim')
    plt.axis('off')
    fig = plt.gcf()
    fig.set_size_inches(14, 12)
    plt.savefig(traj_path, bbox_inches='tight', dpi=100)
    plt.cla()


if __name__ == '__main__':
    draw_trajectory_online()
    # draw_trajectory(1)
    # draw_trajectory(2)
    # segment_images(Path.home() / '.carla/evaluations/exp37/gs1-town1-new1/step100000/secondleft')
    # generate_video_with_sentences(7)
    # test_sentence_dict()
    # unique_trajectories('semantic1', 'semantic1-v38')
    # annotation_helper('semantic2', 'semantic2-v38')
    # sentence_dict = generate_templated_sentence_dict()
    # for key, value in sentence_dict.items():
    #     logger.info((key, len(value)))
    # test_eval_dataset()
    # print(find_duplicated_trajectories(1559339742803712))
    # read_and_draw_locations([0, 2], 'lanefollow')
    # read_and_draw_locations([1], 'left')
    # read_and_draw_locations([3], 'stop')
    # read_and_draw_locations([0, 1, 2, 3], 'all')
    # read_segment_info(Path.home() / '.carla/dataset/backup-dataset/multicam03/segment.json.bak4')
    # read_segment_info(Path.home() / '.carla/dataset/info/multicam03-v25/segment.json.374821b')  #.5126afa')
    # generate_videos_from_dataset_snippet(1559339742803712)
