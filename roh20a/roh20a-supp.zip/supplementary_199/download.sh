wget -N http://54.201.45.51:5000/exp40/gs-town1e.mp4
wget -N http://54.201.45.51:5000/exp40/gs-town1-segment.mp4
mv gs-town1e.mp4 gs-town1
mv gs-town1-segment.mp4 gs-town1

wget -N http://54.201.45.51:5000/exp40/gs-town2e.mp4
mv gs-town2e.mp4 gs-town2

wget -N http://54.201.45.51:5000/exp40/ls-town2e.mp4
wget -N http://54.201.45.51:5000/exp40/ls-town2-segment.mp4
mv ls-town2e.mp4 ls-town2
mv ls-town2-segment.mp4 ls-town2

wget -N http://54.201.45.51:5000/exp40/bgr-town2e.mp4
mv bgr-town2e.mp4 bgr-town2