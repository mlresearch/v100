rm -r ./.carla/carla
rm -r ./.carla/checkpoints
rm -r ./.carla/rawdata
rm -r ./.carla/evaluations
rm -r ./resources
