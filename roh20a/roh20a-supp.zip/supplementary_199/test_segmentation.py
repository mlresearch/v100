from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from model import prepare_deeplab_model


def segment_from_path(model, image_path: Path):
    if not image_path.exists():
        raise FileNotFoundError('image was not found {}'.format(image_path))
    img = cv2.imread(str(image_path))
    img_ = Image.fromarray(img[:, :, ::-1])
    _, seg = model.run(img_)
    seg = (cv2.resize(seg, (200, 88), interpolation=cv2.INTER_NEAREST) == 0).astype(dtype=np.uint8) * 255
    return img, seg * 255


def segment_from_image(model, img: np.ndarray):
    img_ = Image.fromarray(img[:, :, ::-1])
    _, seg = model.run(img_)
    seg = (cv2.resize(seg, (200, 88), interpolation=cv2.INTER_NEAREST) == 0).astype(dtype=np.uint8)
    return img, seg * 255


def main():
    model = prepare_deeplab_model()
    img = cv2.imread(str(Path.home() / 'Downloads/00077000c.png'))
    seg = model.run(img)
    cv2.imshow('img', img)
    cv2.imshow('seg', seg)
    cv2.waitKey()


if __name__ == '__main__':
    main()
