#!/usr/bin/env python

# Copyright (c) 2019 Computer Vision Center (CVC) at the Universitat Autonoma de
# Barcelona (UAB).
#
# This work is licensed under the terms of the MIT license.
# For a copy, see <https://opensource.org/licenses/MIT>.
import argparse
import json
import random
import shutil
from collections import defaultdict
from functools import partial
from math import sqrt
from operator import attrgetter, itemgetter
from pathlib import Path
from subprocess import run, DEVNULL
from time import sleep
from typing import Tuple, List, Dict, Any

import cv2

from custom_carla.agents.navigation.local_planner import RoadOption
from data.types import DriveDataFrame, LengthComputer
from environment import set_world_asynchronous, set_world_synchronous, FrameCounter, should_quit, GameEnvironment, \
    keyboard_control, get_font
from util.common import add_carla_module, get_logger
from util.directory import EvaluationDirectory, mkdir_if_not_exists

add_carla_module()
logger = get_logger(__name__)
import carla

import numpy as np
import pygame
import torch

from config import IMAGE_WIDTH, IMAGE_HEIGHT, EVAL_FRAMERATE_SCALE, DATASET_FRAMERATE, IP_FILESERVER, ROOT_FILESERVER
from data.dataset import fetch_dataset, fetch_dataset_pair, generate_templated_sentence, load_index_from_word, \
    generate_templated_sentence_dict, HighLevelDataset
from util.road_option import fetch_road_option_from_str, fetch_onehot_vector_dim, fetch_onehot_vector_from_index, \
    fetch_road_option_from_index, fetch_num_sentence_commands, fetch_onehot_vector_from_sentence_command, \
    fetch_onehot_index_from_high_level_str, fetch_high_level_command_from_index
from util.image import tensor_from_numpy_image, video_from_files, put_text
from model import init_hidden_states
from parameter import Parameter
from trainer import CheckpointBase


def canonicalize(src: str):
    return str(src).replace('\\', '/').replace('//', '/')


class RemoteCommander(EvaluationDirectory):
    def __init__(self,
                 exp_name: str,
                 exp_index: int,
                 step: int,
                 remote_root: str,
                 server: str,
                 keyword: str = '',
                 options: List[str] = [],
                 prepared: bool = True):
        EvaluationDirectory.__init__(self, exp_index, exp_name, step, keyword)

        self.host_root_dir = Path.home()
        self.remote_root_dir = remote_root
        self.host_eval_dir = self.root_dir
        self.remote_eval_dir = canonicalize('{}/{}'.format(self.remote_root_dir, self.root_subdir))

        self.server = server
        self.options = options
        if not self.host_root_dir.exists():
            raise FileNotFoundError('host root directory was not found {}'.format(self.host_root_dir))

        if prepared:
            self.mkdir(self.root_subdir)

    @property
    def dst_full_path(self):
        return '{}:{}'.format(self.server, self.remote_eval_dir)

    def run(self, remote_cmd: str) -> int:
        cmds = ['ssh'] + self.options + [self.server, '{}'.format(remote_cmd)]
        return run(cmds, stdout=DEVNULL, stderr=DEVNULL).returncode

    def mkdir(self, sub_dir: str):
        sub_dir = canonicalize(sub_dir)
        remote_dir = '/'.join([self.remote_root_dir, sub_dir])
        remote_cmd = 'mkdir -p {}'.format(remote_dir)
        self.run(remote_cmd)

    def send_file(self, filename: str, src_subdir: str = ''):
        src_path = self.host_eval_dir / '{}/{}'.format(src_subdir, filename)
        if not src_path:
            raise FileNotFoundError('no source file found {}'.format(src_path))
        cmds = ['scp', str(src_path), self.dst_full_path]
        return run(cmds, stdout=DEVNULL, stderr=DEVNULL).returncode

    def send_dir(self, src_subdir: str):
        src_dir = self.host_eval_dir / '{}'.format(src_subdir)
        if not src_dir:
            raise FileNotFoundError('no source directory found {}'.format(src_dir))
        src_files = sorted(list(src_dir.glob('*')))
        for src_file in src_files:
            filename = src_file.name
            self.send_file(filename, src_subdir)

    def send_dirs(self, src_subdirs: List[str]):
        for subdir in src_subdirs:
            self.send_dir(subdir)


def onehot_from_index(cmd: int, use_low_level_segment: bool) -> torch.Tensor:
    onehot_dim = fetch_onehot_vector_dim(use_low_level_segment)
    return fetch_onehot_vector_from_index(cmd, use_low_level_segment).view(1, onehot_dim)


class DataGenerator(GameEnvironment):
    def __init__(self, args):
        GameEnvironment.__init__(self, args=args, agent_type='roaming', transform_index=args.position_index)

    def run(self):
        if self.world is None:
            raise ValueError('world was not initialized')
        if self.agent is None:
            raise ValueError('agent was not initialized')

        try:
            frame = None
            count = 0
            clock = pygame.time.Clock() if self.show_image else FrameCounter()

            set_world_asynchronous(self.world)
            sleep(0.5)
            set_world_synchronous(self.world)

            waypoint_dict = dict()
            road_option_dict = dict()

            while count < 200000:
                if self.show_image and should_quit():
                    break

                if frame is not None and self.agent.collision_sensor.has_collided(frame):
                    logger.info('collision was detected at frame #{}'.format(frame))
                    set_world_asynchronous(self.world)
                    self.transform_index += 1
                    self.agent.move_vehicle(self.transforms[self.transform_index])
                    sleep(0.5)
                    self.agent.agent.reset_planner()
                    set_world_synchronous(self.world)

                clock.tick()
                self.world.tick()
                ts = self.world.wait_for_tick()
                if frame is not None:
                    if ts.frame_count != frame + 1:
                        logger.info('frame skip!')
                frame = ts.frame_count
                # self.injector.step()

                if len(self.agent.data_frame_buffer) > 100:
                    self.agent.export_data()
                    if not self.show_image:
                        print(str(clock))

                if self.agent.image_frame is None:
                    continue

                waypoint, road_option, _ = self.agent.step_from_pilot(
                    frame, update=True, apply=True, inject=0.0)  #self.injector.inject)
                waypoint_dict[frame] = waypoint
                road_option_dict[frame] = road_option
                if self.show_image:
                    image = self.agent.image_frame
                    image_frame_number = self.agent.image_frame_number
                    image_road_option = road_option_dict[image_frame_number] if image_frame_number in road_option_dict else None
                    image_waypoint = waypoint_dict[image_frame_number] if image_frame_number in waypoint_dict else None
                    self.show(image, clock, image_road_option, image_waypoint.is_intersection if image_waypoint is not None else None)

                count += 1
            self.agent.export_data()

        finally:
            set_world_asynchronous(self.world)
            if self.agent is not None:
                self.agent.destroy()


def main():
    # Parse arguments
    argparser = argparse.ArgumentParser(description='Evaluation of trained models')
    argparser.add_argument('--host', metavar='H', default='10.158.54.63', help='host server IP (default: 10.158.54.63')
    argparser.add_argument('-p', '--port', metavar='P', default=2000, type=int, help='TCP port (default: 2000)')
    argparser.add_argument('--res', metavar='WIDTHxHEIGHT', default='200x88', help='resolution (default: 1280x720)')
    argparser.add_argument('--filter', metavar='PATTERN', default='vehicle.*', help='actor filter (default: "vehicle.*")')
    argparser.add_argument('--map', metavar='TOWN', default=None, help='start a new episode at the given TOWN')
    argparser.add_argument('--speed', metavar='S', default=20, type=int, help='Maximum speed in PID controller')
    argparser.add_argument('--no-rendering', action='store_true', help='switch off server rendering')
    argparser.add_argument('--safe', action='store_true', help='avoid spawning vehicles prone to accidents')
    argparser.add_argument('--show-game', action='store_true', help='show game display')
    argparser.add_argument('--random-seed', type=int, default=0)
    argparser.add_argument('--position-index', type=int, default=0)
    argparser.add_argument('--camera-keywords', type=str, nargs='*', default=['left', 'center', 'right'])

    args = argparser.parse_args()
    args.description = argparser.description
    args.width, args.height = [int(x) for x in args.res.split('x')]
    logger.info('listening to server {}:{}'.format(args.host, args.port))
    env = DataGenerator(args=args)
    env.run()


if __name__ == '__main__':
    main()
