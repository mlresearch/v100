export PYTHONPATH=$PYTHONPATH:$PWD/.carla/carla/PythonAPI/carla/dist/carla-0.9.5-py3.5-linux-x86_64.egg:$HOME/$PWD/custom_carla
