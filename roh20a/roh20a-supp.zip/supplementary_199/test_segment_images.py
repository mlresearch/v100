import random
from argparse import ArgumentParser
from itertools import product
from multiprocessing import Event, Queue, Process, Manager
from multiprocessing.dummy import Pool
from pathlib import Path
from typing import Tuple, List

import cv2
import numpy as np

import zmq

from data.storage import DataStorage
from util.common import get_logger

PORT_FRONT = 7777
PORT_BACK = 7778

logger = get_logger(__name__)


def req(host, port_front, key: str, image: np.ndarray):
    """sends an evaluation request to the evaluation server"""
    context = zmq.Context()
    socket = context.socket(zmq.REQ)
    socket.connect('tcp://{}:{}'.format(host, port_front))
    socket.send_pyobj((key, image))
    logger.info('sent a request {}'.format(key))
    socket.recv_pyobj()
    logger.info('received an ack signal')


def rep(socket: zmq.Socket, queue: Queue):
    """replies to a request and put that into a queue for handling"""
    info = socket.recv_pyobj()
    logger.info('received a request {}'.format(info[0]))
    socket.send_pyobj('ack')
    logger.info('sent an ack signal')
    queue.put(info)


def prep(host, port_back, queue: Queue, event: Event):
    """keep replying to requests and put them into a queue for handling"""
    context = None
    socket = None
    try:
        context = zmq.Context()
        socket = context.socket(zmq.REP)
        socket.connect('tcp://{}:{}'.format(host, port_back))
        while not event.is_set():
            rep(socket, queue)
    except Exception as e:
        logger.error(e)
    finally:
        event.set()
        if socket is not None:
            socket.close()
        if context is not None:
            context.term()


def psegment(index, queue: Queue, event: Event):
    """do evaluation from the request"""
    from model import prepare_deeplab_model
    segment_dir = Path.home() / '.carla/dataset/data/semantic1_images2'
    model = prepare_deeplab_model(index)
    try:
        while not event.is_set():
            if not queue.empty():
                info = queue.get_nowait()
                if info is None:
                    break
                key, image = info
                segment = model.run(image)
                cv2.imwrite(str(segment_dir / '{}.png'.format(key)), segment)
                logger.info('write {}'.format(key))
    except Exception as e:
        logger.error(e)
    finally:
        event.set()


def pqueue(port_front, port_back):
    """Running a routing queue to handle multiple requests and responses (XREQ and XREP)"""
    frontend, backend, context = None, None, None
    try:
        context = zmq.Context(1)
        frontend = context.socket(zmq.XREP)
        frontend.bind('tcp://*:{}'.format(port_front))
        backend = context.socket(zmq.XREQ)
        backend.bind('tcp://*:{}'.format(port_back))
        zmq.device(zmq.QUEUE, frontend, backend)
    except Exception as e:
        logger.error(e)
    finally:
        if frontend is not None:
            frontend.close()
        if backend is not None:
            backend.close()
        if context is not None:
            context.term()


def consumer(host, port_front, port_back, index):
    logger.info('consumer called {}, {}, {}, {}'.format(host, port_front, port_back, index))
    queue = Queue()
    event = Event()
    processes = [
        Process(target=prep, args=(host, port_back, queue, event,)),
        Process(target=psegment, args=(index, queue, event, )),
        Process(target=pqueue, args=(port_front, port_back))
    ]
    for p in processes:
        p.start()


def pimage(queue: Queue):
    indices = list(range(50520, 202193))
    keywords = ['l', 'c', 'r']
    keys = ['{:08d}{}'.format(i, k) for i, k in product(indices, keywords)]
    data_db_path = Path.home() / '.carla/dataset/data/semantic1'
    data_storage = DataStorage(read_only=True, db_path=data_db_path, use_multi_cam=True)
    data_storage.put_images_to_queue(keys, queue)


def preq(host: str, port_fronts: List[int], queue: Queue, event: Event):
    while not event.is_set():
        if not queue.empty():
            item = queue.get()
            if item is None:
                event.set()
                break
            key, image = item
            port_front = random.choice(port_fronts)
            req(host, port_front, key, image)


def producer(host: str, port_fronts: List[int]):
    logger.info('host is called {}, {}'.format(host, port_fronts))
    queue = Queue()
    event = Event()
    processes = [
        Process(target=preq, args=(host, port_fronts, queue, event,)),
        Process(target=pimage, args=(queue,))
    ]
    for p in processes:
        p.start()


def main():
    argparser = ArgumentParser()
    argparser.add_argument('mode', type=str)
    argparser.add_argument('--host', type=str, default='127.0.0.1')
    argparser.add_argument('--front', type=int)
    argparser.add_argument('--back', type=int)
    argparser.add_argument('--index', type=int, default=0)
    argparser.add_argument('--fronts', type=int, nargs='*')
    args = argparser.parse_args()

    host = args.host
    if args.mode == 'producer':
        fronts = args.fronts
        if not fronts:
            raise ValueError('at least one front should be specified')
        producer(host, fronts)
    elif args.mode == 'consumer':
        front, back, index = args.front, args.back, args.index
        consumer(host, front, back, index)
    else:
        raise TypeError('invalid mode {}'.format(args.mode))


if __name__ == '__main__':
    main()
