import os
from pathlib import Path
from subprocess import Popen, PIPE, STDOUT
from threading import Thread
from time import sleep
from typing import List, Dict

from config import GAME_PATH, EVALUATE_PORTS
from util.common import get_logger, add_carla_module

add_carla_module()
logger = get_logger(__name__)
import carla


def output_reader(proc):
    for line in iter(proc.stdout.readline, b''):
        print('got line: {0}'.format(line.decode('utf-8')), end='')


def output_from_cmd(cmds: List[str]) -> str:
    out, _ = Popen(cmds, shell=True, stdout=PIPE).communicate()
    return out.decode()


def check_game_status(host: str, port: int):
    checked = False
    try:
        client = carla.Client(host, port)
        client.set_timeout(5.0)
        logger.info('client initialized with port {}'.format(port))
        world = client.get_world()
        logger.info('got world {}'.format(world))
        if world:
            logger.info('successfully checked the port {}'.format(port))
            checked = True
    except:
        return False
    return checked


def kill_game(port_dict: Dict[int, int], port: int):
    if port in port_dict:
        pid, t = port_dict[port]
        cmds = ['kill', '-9', str()]
        logger.info(cmds)
        logger.info(output_from_cmd(cmds))
        t.join()
        del port_dict[port]


def launch_game(town_index: int, port: int, port_dict: Dict[int, int]):
    os.environ['DISPLAY'] = ':'
    game_path = Path.home() / GAME_PATH
    cmds = [str(game_path), 'CarlaUE4', '/Game/Carla/Maps/Town{:02d}'.format(town_index),
            '-benchmark', '-fps=50', '-carla-port={}'.format(port)]
    proc = Popen(cmds, stdout=PIPE, stderr=STDOUT)
    t = Thread(target=output_reader, args=(proc,))
    t.start()
    port_dict[port] = proc.pid, t


def launch_games(town_index: int, port_dict: Dict[int, int]):
    for port in EVALUATE_PORTS:
        launch_game(town_index, port, port_dict)
    logger.info(port_dict)


def manage_games_iteration(host: str, town_index: int, port_dict: Dict[int, int]):
    for port in EVALUATE_PORTS:
        if port not in port_dict:
            launch_game(town_index, port, port_dict)
        checked = check_game_status(host, port)
        logger.info('got checked output from {}, {}'.format(port, checked))
        if not checked:
            kill_game(port_dict, port)
    logger.info(port_dict)


if __name__ == '__main__':
    host = '172.0.0.1'
    town_index = 2
    port_dict = dict()
    # pid = launch_game(town_index, 5555).pid


    # while True:
    #     sleep(1)
    # sleep(5)

    launch_games(town_index, port_dict)
    sleep(20)
    while True:
        try:
            manage_games_iteration(host, town_index, port_dict)
        finally:
            sleep(1)
    # launch_game(2, 5555)
    # print(process.pid)
    # while True:
    #     if process.poll():
    #         break
    # print('process {} was terminated {}'.format(process.pid, process.returncode))
