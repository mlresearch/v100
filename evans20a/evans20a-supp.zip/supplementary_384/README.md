# Variational Optimization Based Reinforcement Learning for Infinite Dimensional Stochastic Systems (accepted at CoRL 2019)

## Requirements
- python 3.5.3
- Tensorflow 1.12

## Implemented Systems
- 1D Heat SPDE (distributed control)
- 1D Heat SPDE (boundary control)
- 2D Heat SPDE (distributed control)
- 1D Nagumo SPDE (distributed control)
- 1D Burgers SPDE (distributed control)

## Usage
For 1D systems, navigate to the `1D_tensorflow` directory, then use,<br/>
`python name_of_experiment.py`<br/>
such as,<br/>
`python main_heat1D.py`(to run the 1D heat SPDE experiment for results published in the CoRL 2019 paper) 

Similarly, for 2D systems. navigate to the `2D_tensorflow` directory, then use,<br/>
`python name_of_experiment.py`<br/>
such as,<br/>
`python main_heat2D_sparseconv.py`
(to run the 2D heat SPDE experiment for results published in the CoRL 2019 paper) 

## Modifying hyperparameters
To change/test different hyperparameters to assess the effect of these parameters on the trained policy, modify the respective configuration file which is used in the experiment's `main.py` file above. For example, in order to modify hyperparameters for the 1D heat SPDE distributed control experiment change the values in the `1Dheat.cfg` file.
 
### Description of hyperparameters
Following is a list of the hyperparamters used in the `1Dheat.cfg` file along with a small description of each,<br/>
`dt` = time discretization<br/>
`Tf` = simulation end time (Horizon)<br/>
`a` = length of the spatial domain in meters<br/>
`J` = number of spatial grid points<br/>
`iters` = number of ADAM iterations<br/>
`rollouts` = number of sampled trajectories from SPDE dynamics<br/>
`rho` = temperature parameter (inverse variance)<br/>
`epsilon` = thermal diffusivity<br/>
`desired_value` = desired temperature value<br/>
`learnrate` = learning rate for optimizer<br/>
`l2_scale` = weight for l2 regularization loss<br/> 
`Q` = state cost scaling term<br/>
`load_network_check` = boolean to check if graph and weights should be loaded from provided pre-trained model's filename<br/>
`dpi` = number of pixels per inch for plots<br/>
`actuator_locs` = locations of actuator centers (mean values of Gaussian-like exponential functions)<br/>
`hidden_layers` = number of neurons per hidden layer (should be a list)<br/>
`sig_val` = influence of actuators (standard deviation values of Gaussian-like exponential functions)<br/>
`load_file_name` = filename to reload a pre-trained tensorflow policy model<br/>

## Software Authors
[Marcus Pereira](mailto:mpereira30@gatech.edu), [Ethan Evans](mailto:eevans41@gatech.edu)
