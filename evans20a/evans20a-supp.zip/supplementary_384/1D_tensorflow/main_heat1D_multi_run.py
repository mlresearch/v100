import configparser
import tensorflow as tf
from mppi import MPPI
from model import Heat1D
from policy import Policy
import numpy as np
import matplotlib.pyplot as plt
import datetime

np_dtype = np.float32
tf_dtype = tf.float32


##################intialize random seed and pass it to functions###########################
seed = np.random.seed(1)
tfseed = tf.random.set_random_seed(1)
config = configparser.RawConfigParser()
config.read('1Dheat.cfg')

dt = config.getfloat('sec1', 'dt') #time increment
Tf = config.getfloat('sec1', 'Tf') #final time
a = config.getfloat('sec1', 'a') #length of heat line
J = config.getint('sec1', 'J') #number of noise expansion terms
iters = config.getint('sec1', 'iters') #number of MPC iterations per time step
rollouts = config.getint('sec1', 'rollouts') #number of rollouts
rho = config.getfloat('sec1', 'rho') #acts as "temperature", squared inverse of variance
learnrate = config.getfloat('sec1', 'learnrate') # learning rate for updates
epsilon = config.getfloat('sec1', 'epsilon') #heat pde constant (scaling of h_xx)
l2_scale = config.getfloat('sec1', 'l2_scale') #regularization scaling
#boundary_conds = config.getstring('sec1', 'boundary_conds')
desired_value = np.float32(config.getfloat('sec1', 'desired_value')) #goal temperature for MPC
#num_contour_levels = config.getint('sec1', 'num_contour_levels') #number of levels to plot
#vmin = config.getfloat('sec1', 'vmin') #min contour level to plot
#vmax = config.getfloat('sec1', 'vmax') #max contour level to plot
Q = config.getfloat('sec1', 'Q') #a single value
load_check = config.getboolean('sec1', 'load_network_check')
load_file_name = config.get('sec2', 'load_file_name')

mpc_steps = int(np.ceil(Tf/dt)) # total number of MPC timesteps

# Get/compute actuator data
actuator_locs = np.asarray(config.get('sec2', 'actuator_locs').split(','), dtype=np_dtype) * np.float32(a) #actuator locations

hidden_layers = np.asarray(config.get('sec2', 'hidden_layers').split(','), dtype=np.int32) #list of hidden nodes in each layer
N = len(actuator_locs) #number of actuators
sig_val = np.float32(config.getfloat('sec2','sig_val') * a)
sig_val = np.square(sig_val) * np.ones(N)
sig_xx = sig_val


class Params(object):
	def __init__(self):
		self.l2_scale = l2_scale
		self.dt = dt
		self.a = a
		self.bj = np.sqrt(2.0 * self.dt/self.a)
		self.iterations = iters #
		self.learnrate = learnrate
		self.J = J 
		self.avg_spacing = a/J
		self.epsilon = epsilon
		self.rho = rho #tuning parameter
		self.N = N
		self.mpc_steps = mpc_steps
		self.rollouts = rollouts #tuning parameter
		self.actuator_locs = actuator_locs
		self.sig_xx = sig_xx
		self.hidden_layers = hidden_layers
		self.Q = Q #tuning parameter
		self.desired_state = np.zeros((1, J+1), dtype=np_dtype)
		#self.h_0 = tf.multiply(tf.ones((rollouts, J+1), dtype=np_dtype), tf.random.normal((1, J+1), dtype=tf_dtype))
		#print("Initial state: ",self.h_0)
		self.h_0 = tf.zeros((rollouts, J+1), dtype=tf_dtype)

		self.num_layers = len(hidden_layers)-1
		range1 = np.int32(np.arange(np.round(0.18*J), np.round(0.22*J)+1, 1) )
		range2 = np.int32(np.arange(np.round(0.48*J), np.round(0.52*J)+1, 1) )
		range3 = np.int32(np.arange(np.round(0.78*J), np.round(0.82*J)+1, 1) )
		self.desired_indices = np.hstack([range1, range2, range3])
		self.desired_state[0, range1] = desired_value
		self.desired_state[0, range2] = desired_value * 0.5
		self.desired_state[0, range3] = desired_value
		print("Desired state: ",self.desired_state)

		self.num_weights = (J+1)*hidden_layers[0] + hidden_layers[0]
		for j in range(self.num_layers):
			self.num_weights += hidden_layers[j]*hidden_layers[j+1] + hidden_layers[j+1]
		self.num_weights += hidden_layers[-1]*N + N
		print("Constructing a network with ",self.num_weights,"parameters")
		self.random_seed = seed
		self.tf_random_seed = tfseed
		self.load_check = load_check
		self.desired_value = desired_value
		self.load_file_name = load_file_name

avg_state_cost_vec_list = []
obj_func_vec_list = []
params = Params()
policy = Policy(params)
heat1d = Heat1D(params)

sess = tf.Session()
mppi = MPPI(params, heat1d, policy, sess)
init_op = tf.global_variables_initializer()

trials = 200

for i in range(trials):
	print("trial ", i)
	if i > 0:
		mppi.sess = tf.Session()
	# tf.reset_default_graph()
	mppi.sess.run(init_op)
	avg_state_cost_vec, obj_func_vec = mppi._mppi()
	avg_state_cost_vec_list.append(avg_state_cost_vec)
	obj_func_vec_list.append(obj_func_vec)
	# sess.close()

	# params.random_seed = np.random.seed(i+2)
	# params.tf_random_seed = tf.random.set_random_seed(i+2)
	# heat1d.params.random_seed = np.random.seed(i+2)
	# heat1d.params.tf_random_seed = tf.random.set_random_seed(i+2)
	# policy.params.tf_random_seed = tf.random.set_random_seed(i+2)

# avg_state_cost_mat = np.asarray(avg_state_cost_vec_list)
# obj_func_mat = np.asarray(obj_func_vec_list)

# mean_loss = np.mean(obj_func_mat, axis=0)
# mean_state_cost = np.mean(avg_state_cost_mat, axis=0)
# var_loss = np.var(obj_func_mat, axis=0)
# var_state_cost = np.var(avg_state_cost_mat, axis=0)
# x_axis = np.arange(0,iters,1)
# fig = plt.figure()
# ax = plt.gca()
# plt.cla()
# ax.plot(x_axis, mean_loss)
# ax.fill_between(x_axis, mean_loss - var_loss, mean_loss + var_loss, alpha=0.2)
# ax.fill_between(x_axis, mean_state_cost - var_state_cost, mean_state_cost + var_state_cost, alpha=0.2)
# ax.plot(x_axis, mean_state_cost)
# plt.show()
		
# print("state cost iterations over trials", avg_state_cost_vec_list)
# print("objective function iterations over trials", obj_func_vec_list)


print("Saving data ... ")
avg_state_cost_data = np.asarray(avg_state_cost_vec_list)
obj_func_data = np.asarray(obj_func_vec_list)
now = datetime.datetime.now()
np.savez('savedir/test_data/'+str(now.isoformat())+'.npz', avg_state_cost_data=avg_state_cost_data, obj_func_data=obj_func_data)

fig1 = plt.figure()
ax1 = plt.gca()
mean_state_costs = np.mean(avg_state_cost_data, axis=0)
std_state_costs = 2 * np.std(avg_state_cost_data, axis=0)
plt.cla()
plt.xlabel('iterations')
plt.ylabel('average state cost')
x_axis =  np.arange(1,mean_state_costs.size+1)
ax1.plot(x_axis, mean_state_costs, linewidth=1.5)
ax1.fill_between(x_axis, mean_state_costs - std_state_costs, mean_state_costs + std_state_costs, alpha=0.4)

fig2 = plt.figure()
ax2 = plt.gca()
mean_obj_func = np.mean(obj_func_data, axis=0)
std_obj_func = 2 * np.std(obj_func_data, axis=0)
plt.cla()
plt.xlabel('iterations')
plt.ylabel('average objective function values')
ax2.plot(x_axis, mean_obj_func, linewidth=1.5)
ax2.fill_between(x_axis, mean_obj_func - std_obj_func, mean_obj_func + std_obj_func, alpha=0.4)

plt.show()	

