import configparser
import tensorflow as tf
from simulate import Simulate
from model import Nagumo1D
import numpy as np

np_dtype = np.float32
tf_dtype = tf.float32


##################intialize random seed and pass it to functions###########################
seed = np.random.seed(1)
tfseed = tf.random.set_random_seed(1)
config = configparser.RawConfigParser()
config.read('1Dnagumo.cfg')

dt = config.getfloat('sec1', 'dt') #time increment
Tf = config.getfloat('sec1', 'Tf') #final time
a = config.getfloat('sec1', 'a') #length of heat line
J = config.getint('sec1', 'J') #number of noise expansion terms
iters = config.getint('sec1', 'iters') #number of MPC iterations per time step
rollouts = config.getint('sec1', 'rollouts') #number of rollouts
rho = config.getfloat('sec1', 'rho') #acts as "temperature", squared inverse of variance
learnrate = config.getfloat('sec1', 'learnrate') # learning rate for updates
epsilon = config.getfloat('sec1', 'epsilon') #heat pde constant (scaling of h_xx)
l2_scale = config.getfloat('sec1', 'l2_scale') #regularization scaling
#boundary_conds = config.getstring('sec1', 'boundary_conds')
desired_value = np.float32(config.getfloat('sec1', 'desired_value')) #goal temperature for MPC
#num_contour_levels = config.getint('sec1', 'num_contour_levels') #number of levels to plot
#vmin = config.getfloat('sec1', 'vmin') #min contour level to plot
#vmax = config.getfloat('sec1', 'vmax') #max contour level to plot
Q = config.getfloat('sec1', 'Q') #a single value
load_check = config.getboolean('sec1', 'load_network_check')
mpc_steps = int(np.ceil(Tf/dt)) # total number of MPC timesteps
wave_speed = config.getfloat('sec1', 'wave_speed')
dpi = config.getint('sec1', 'dpi') 

# Get/compute actuator data
actuator_locs = np.asarray(config.get('sec2', 'actuator_locs').split(','), dtype=np_dtype) * np.float32(a) #actuator locations

hidden_layers = np.asarray(config.get('sec2', 'hidden_layers').split(','), dtype=np.int32) #list of hidden nodes in each layer
N = len(actuator_locs) #number of actuators
sig_val = np.float32(config.getfloat('sec2','sig_val') * a)
sig_val = np.square(sig_val) * np.ones(N)
sig_xx = sig_val


class Params(object):
	def __init__(self):
		self.desired_value = desired_value
		self.l2_scale = l2_scale
		self.dt = dt
		self.a = a
		self.bj = np.sqrt(2.0 * self.dt/self.a)
		self.iterations = iters #
		self.learnrate = learnrate
		self.J = J 
		self.avg_spacing = a/J
		self.epsilon = epsilon
		self.wave_speed = wave_speed
		self.rho = rho #tuning parameter
		self.N = N
		self.mpc_steps = mpc_steps
		self.rollouts = rollouts #tuning parameter
		self.actuator_locs = actuator_locs
		self.sig_xx = sig_xx
		self.hidden_layers = hidden_layers
		self.Q = Q #tuning parameter
		self.desired_state = np.full_like(np.zeros((1, J+1), dtype=np_dtype), np.nan)
		#self.h_0 = tf.multiply(tf.ones((rollouts, J+1), dtype=np_dtype), tf.random.normal((1, J+1), dtype=tf_dtype))
		#print("Initial state: ",self.h_0)
		xvals = np.arange(0, a+self.avg_spacing, self.avg_spacing)
		hvals = 1/(1+np.exp(-(2-xvals)/np.sqrt(2)))
		self.h_0 = tf.constant(hvals, dtype=tf_dtype) * tf.ones((self.rollouts, self.J+1), dtype=tf_dtype)

		self.num_layers = len(hidden_layers)-1
		range1 = np.int32(np.arange(np.round(0.7*J), np.round(0.99*J)+1, 1) )
		self.desired_indices = range1
		self.desired_state[0, range1] = desired_value
		print("Desired state: ",self.desired_state)

		self.num_weights = (J+1)*hidden_layers[0] + hidden_layers[0]
		for j in range(self.num_layers):
			self.num_weights += hidden_layers[j]*hidden_layers[j+1] + hidden_layers[j+1]
		self.num_weights += hidden_layers[-1]*N + N
		print("Constructing a network with ",self.num_weights,"parameters")
		self.random_seed = seed
		self.tf_random_seed = tfseed

		self.load_check = load_check
		self.xlabel = 'Position along axon'
		self.ylabel = 'Voltage'
		self.title = 'Wave Propagation Suppression Task'
		self.load_dir = 'savedir/good_data/Nagumo_1d/'
		self.filename = '2019-07-02T18:03:27.686747.npz'
		self.dpi = dpi

params = Params()
nagumo1d = Nagumo1D(params)
sim = Simulate(params, nagumo1d)
sim._simulate()



		