import configparser
import tensorflow as tf
from simulate import Simulate
from model import Heat1D_boundary
import numpy as np

np_dtype = np.float32
tf_dtype = tf.float32


##################intialize random seed and pass it to functions###########################
seed = np.random.seed(1)
tfseed = tf.random.set_random_seed(1)
config = configparser.RawConfigParser()
config.read('1Dheat_boundary.cfg')

dt = config.getfloat('sec1', 'dt') #time increment
Tf = config.getfloat('sec1', 'Tf') #final time
a = config.getfloat('sec1', 'a') #length of heat line
J = config.getint('sec1', 'J') #number of noise expansion terms
iters = config.getint('sec1', 'iters') #number of MPC iterations per time step
rollouts = config.getint('sec1', 'rollouts') #number of rollouts
rho = config.getfloat('sec1', 'rho') #acts as "temperature", squared inverse of variance
learnrate = config.getfloat('sec1', 'learnrate') # learning rate for updates
epsilon = config.getfloat('sec1', 'epsilon') #heat pde constant (scaling of h_xx)
l2_scale = config.getfloat('sec1', 'l2_scale') #regularization scaling
#boundary_conds = config.getstring('sec1', 'boundary_conds')
# desired_value = np.float32(config.getfloat('sec1', 'desired_value')) #goal temperature for MPC
Q = config.getfloat('sec1', 'Q') #a single value
load_check = config.getboolean('sec1', 'load_network_check')

load_dir = config.get('sec2', 'load_dir')
filename = config.get('sec2', 'filename')
dpi = config.getint('sec2', 'dpi')

mpc_steps = int(np.ceil(Tf/dt)) # total number of MPC timesteps

# Get/compute actuator data
actuator_locs = np.asarray([0.0, 1.0]) * np.float32(a) #actuator locations
hidden_layers = np.asarray(config.get('sec2', 'hidden_layers').split(','), dtype=np.int32) #list of hidden nodes in each layer
desired_value = np.asarray(config.get('sec2', 'desired_value').split(','), dtype=np.float32) #list of hidden nodes in each layer
N = len(actuator_locs) #number of actuators


class Params(object):
	def __init__(self):
		self.l2_scale = l2_scale
		self.dt = dt
		self.a = a
		self.bj = np.sqrt(2.0 * self.dt/self.a)
		self.iterations = iters #
		self.learnrate = learnrate
		self.J = J 
		self.avg_spacing = a/J
		self.epsilon = epsilon
		self.rho = rho #tuning parameter
		self.N = N
		self.mpc_steps = mpc_steps
		self.rollouts = rollouts #tuning parameter
		self.actuator_locs = actuator_locs
		# self.sig_xx = sig_xx
		self.hidden_layers = hidden_layers
		self.Q = Q #tuning parameter
		self.desired_state = np.zeros((mpc_steps, rollouts, J+1), dtype=np_dtype)
		start_idx = 0
		end_idx = int(mpc_steps/desired_value.shape[0])
		for i in range(len(desired_value)):
			self.desired_state[start_idx:end_idx, :,:] = desired_value[i]
			start_idx = end_idx
			end_idx = start_idx + end_idx

		self.desired_state[start_idx:,:,:] = desired_value[-1]
		#print("Initial state: ",self.h_0)
		self.h_0 = tf.zeros((rollouts, J+1), dtype=tf_dtype)

		self.num_layers = len(hidden_layers)-1
		print("Desired state: ",self.desired_state)
		self.desired_value = desired_value

		self.num_weights = (J+1)*hidden_layers[0] + hidden_layers[0]
		for j in range(self.num_layers):
			self.num_weights += hidden_layers[j]*hidden_layers[j+1] + hidden_layers[j+1]
		self.num_weights += hidden_layers[-1]*N + N
		print("Constructing a network with ",self.num_weights,"parameters")
		self.random_seed = seed
		self.tf_random_seed = tfseed
		self.xlabel = 'Spatial position'
		self.ylabel = 'Temperature'
		self.title = 'Tracking Desired Temperature Profile Task'
		self.load_check = load_check
		self.load_dir = load_dir
		self.filename = filename
		self.dpi = dpi 




params = Params()
heat1d = Heat1D_boundary(params)
sim = Simulate(params, heat1d)
sim._simulate()



		