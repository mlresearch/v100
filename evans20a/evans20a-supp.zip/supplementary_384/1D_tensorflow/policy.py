import tensorflow as tf
import utils

tf_dtype = tf.float32


class Policy(object):
	def __init__(self, params):

		self.params = params
		weight_initializer = tf.contrib.layers.xavier_initializer(dtype=tf_dtype, seed=self.params.tf_random_seed)
		weight_regularizer = None

		self.W1 = tf.get_variable( name="W_layer1", shape=[self.params.J+1, self.params.hidden_layers[0]], dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer )
		self.b1 = tf.get_variable( name="b_layer1", shape=[self.params.hidden_layers[0]], dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer )
		self.W2 = tf.get_variable( name="W_layer2", shape=[self.params.hidden_layers[0], self.params.hidden_layers[1]], dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer )
		self.b2 = tf.get_variable( name="b_layer2", shape=[self.params.hidden_layers[1]], dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer )
		self.W3 = tf.get_variable( name="W_output", shape=[self.params.hidden_layers[1], self.params.N], dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer )
		self.b3 = tf.get_variable( name="b_output", shape=[self.params.N], dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer )
		self.trainable_list = tf.trainable_variables()
		self.W = [self.W1, self.W2, self.W3]
		self.B = [self.b1, self.b2, self.b3]


	def _policy_forward_pass(self,h): #### PUT THIS SOMEWHERE ELSE
		#accepts h as shape = (rollouts * (J+1), (J+1)) or shape = (rollouts, J+1), returns shape = (rollouts * (J+1), N)
		output1 = tf.nn.relu(tf.matmul(h,self.W1) + self.b1)
		output2 = tf.nn.relu(tf.matmul(output1,self.W2) + self.b2)
		return tf.matmul(output2,self.W3) + self.b3 #shape = (rollouts * (J + 1), N)


	def _policy_eval(self, h):
		# This function takes input h, and returns a (rollouts, J+1, N) tensor resulting from running input's elements as eigenvalues of the spatial basis
		#h input should be shape=(rollouts x J)
		#policy_tensor = tf.zeros((self.params.rollouts, self.params.J+1, self.params.N), dtype=tf_dtype)
		I = tf.eye(self.params.J+1, dtype=tf_dtype, batch_shape=[self.params.rollouts])
		diag_h = tf.multiply(I, tf.expand_dims(h, axis=-1)) #shape = (rollouts, J + 1, J + 1)
		diag_h = tf.reshape(diag_h, (self.params.rollouts * (self.params.J+1), self.params.J+1)) #shape = (rollouts * (J + 1), (J+1))
		feed_out = self._policy_forward_pass(diag_h) #return shape = (rollouts * (J + 1), N)
		return tf.reshape(feed_out, (self.params.rollouts, self.params.J+1, self.params.N)) 



	# def _gradient_policy_eval_noise(self, h, small_m_expand, noise_matrix_expand):
	# 	# h is of shape = (rollouts , J)
	# 	# small_m_expand is of shape = (rollouts, (J+1), N, 1)
	# 	# noise_matrix_expand is of shape = (rollouts, (J+1))
	# 	# This function returns the gradients of the noise inner product output w.r.t. the weights. Output shape should = (rollouts, K)
	# 	#
	# 	# for loops over rollouts, N
	# 	# integration using summation provided by gradients: pass in m, b, 

	# 	out = tf.matmul(tf.expand_dims(self._policy_eval(h), axis=-2), small_m_expand) # shape = (rollouts, J+1, 1, 1)
	# 	out = tf.multiply(tf.squeeze(out), noise_matrix_expand)  # shape = (rollouts, J+1)
	# 	first = 0.5 * tf.ones((self.params.rollouts, 1), dtype=tf_dtype)
	# 	last = 0.5 * tf.ones((self.params.rollouts, 1), dtype=tf_dtype)
	# 	middle = tf.ones((self.params.rollouts, self.params.J-1), dtype=tf_dtype)
	# 	scale = tf.concat([first, middle, last], axis=-1)
	# 	out = out * scale * self.params.avg_spacing

	# 	grads = []

	# 	for r in range(self.params.rollouts):
	# 		temp = tf.gradients(out[r,:], self.trainable_list) #shape = (K, 1)
	# 		for j in range(len(temp)):
	# 			temp[j] = tf.reshape(temp[j], [-1,1])
	# 		temp = tf.concat(temp, axis=0) 
	# 		grads.append(temp) #shape = (K,1)
	# 		#grads is now a r indexed list of (K,1) vectors
	# 	grads = tf.concat(grads, axis=1) #shape = (K,rollouts)
	# 	return tf.transpose(grads, perm=[1,0]) #shape = (rollouts, K)

	# def _gradient_policy_eval_time(self, h, M_expand):
	# 	# h is of shape = (rollouts , J)
	# 	# M_expand is of shape = (rollouts, (J+1), N, N)
	# 	# This function returns the gradients of the time inner product output w.r.t. the weights. Output shape should = (rollouts, K)
	# 	#
	# 	# for loops over rollouts, N
	# 	# integration using summation provided by gradients: pass in m, b, 
	# 	policy_eval = self._policy_eval(h) #shape = (rollouts, J+1, N)
	# 	policy_eval_left = tf.expand_dims(policy_eval, axis=-2) #shape = (rollouts, J+1, 1, N)
	# 	policy_eval_right = tf.expand_dims(policy_eval, axis=-1) #shape = (rollouts, J+1, N, 1)
	# 	out = tf.squeeze(tf.matmul(tf.matmul(policy_eval_left, M_expand), policy_eval_right)) #shape = (rollouts, J+1)
	# 	first = 0.5 * tf.ones((self.params.rollouts, 1), dtype=tf_dtype)
	# 	last = 0.5 * tf.ones((self.params.rollouts, 1), dtype=tf_dtype)
	# 	middle = tf.ones((self.params.rollouts, self.params.J-1), dtype=tf_dtype)
	# 	scale = tf.concat([first, middle, last], axis=-1) #shape = (rollouts, J+1)
	# 	out = out * scale * self.params.avg_spacing

	# 	grads = []

	# 	for r in range(self.params.rollouts):
	# 		temp = tf.gradients(out[r,:], self.trainable_list) # list of gradients
	# 		for j in range(len(temp)):
	# 			temp[j] = tf.reshape(temp[j], [-1,1])
	# 		temp = tf.concat(temp, axis=0) 
	# 		grads.append(temp) #shape = (K,1)
	# 		#grads is now a r indexed list of (K,1) vectors
	# 	grads = tf.concat(grads, axis=1) #shape = (K,rollouts)
	# 	return tf.transpose(grads, perm=[1,0]) #shape = (rollouts, K)

	# def _update_apply_gradients(self, learnrate, deltaW):
	# 	# This function takes as input a flattened set of updated weights to replace the current set of network weights
	# 	# First unflatten, then assign new weights to old 
	# 	# deltaW is of shape (1, K)

	# 	delW = []
	# 	delB = []
	# 	assign = []

	# 	# Unflatten input layer
	# 	current_count = 0
	# 	next_count = (self.params.J+1)*self.params.hidden_layers[0]
	# 	delW.append( tf.reshape(deltaW[0, current_count:next_count], [self.params.J+1, self.params.hidden_layers[0]]) )
	# 	assign.append( tf.assign(self.W[0], self.W[0] + learnrate * delW[0]) )

	# 	current_count = next_count
	# 	next_count = current_count + self.params.hidden_layers[0]
	# 	delB.append( deltaW[0, current_count:next_count] )
	# 	assign.append( tf.assign(self.B[0], self.B[0] + learnrate * delB[0]) )
		
	# 	# unflatten middle layers
	# 	for j in range(self.params.num_layers):
	# 		current_count = next_count
	# 		next_count = current_count + self.params.hidden_layers[j]*self.params.hidden_layers[j+1]
	# 		delW.append( tf.reshape(deltaW[0, current_count:next_count ], [self.params.hidden_layers[j],  self.params.hidden_layers[j+1]]) )
	# 		assign.append( tf.assign(self.W[j+1], self.W[j+1] + learnrate * delW[j+1]) )

	# 		current_count = next_count
	# 		next_count = current_count + self.params.hidden_layers[j+1]
	# 		delB.append( deltaW[0, current_count:next_count] )
	# 		assign.append( tf.assign(self.B[j+1], self.B[j+1] + learnrate * delB[j+1]) )

	# 	# unflatten output layer
	# 	current_count = next_count
	# 	next_count = current_count + self.params.hidden_layers[-1]*self.params.N
	# 	delW.append( tf.reshape(deltaW[0, current_count:next_count], [self.params.hidden_layers[-1], self.params.N]) )
	# 	assign.append( tf.assign(self.W[-1], self.W[-1] + learnrate * delW[-1]) )

	# 	current_count =  next_count
	# 	next_count = current_count + self.params.N
	# 	delB.append( deltaW[0, current_count:next_count] )
	# 	assign.append( tf.assign(self.B[-1], self.B[-1] + learnrate * delB[-1]) )


	# 	self.assign_ops = tf.group(*assign)
	# 	#self.assign is a list of length