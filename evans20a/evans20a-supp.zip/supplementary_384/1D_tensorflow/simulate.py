import numpy as np
import tensorflow as tf
import os
np_dtype = np.float32
tf_dtype = tf.float32
from time import time
import matplotlib.pyplot as plt
import datetime
import sys
from utils import plot_1d_field, plot_1d_field_compare


class Simulate(object):
	def __init__(self, params, model):
		self.params = params
		self.model = model
		self._build_graph()
		self.sess = tf.Session()

	def _simulate(self):

		uncontrolled_trajectories, noise_trajs = self.sess.run([self.model.sim_traj, self.model.dQWiener])
		controlled_trajectories = np.load(self.params.load_dir + self.params.filename)['trajs']


		uncontrolled_mean_traj = np.mean(uncontrolled_trajectories, axis=1) # (100,65)
		uncontrolled_std_traj = 2*np.std(uncontrolled_trajectories, axis=1) # plotting 2 sigma 
		uncontrolled_upper_limit = np.amax(uncontrolled_mean_traj) + np.amax(uncontrolled_std_traj) + 0.1
		uncontrolled_lower_limit = np.amin(uncontrolled_mean_traj) - np.amax(uncontrolled_std_traj) - 0.1

		controlled_mean_traj = np.mean(controlled_trajectories, axis=1) # (100,65)
		controlled_std_traj = 2*np.std(controlled_trajectories, axis=1) # plotting 2 sigma
		controlled_upper_limit = np.amax(controlled_mean_traj) + np.amax(controlled_std_traj) + 0.1
		controlled_lower_limit = np.amin(controlled_mean_traj) - np.amax(controlled_std_traj) - 0.1

		upper_limit = np.maximum(uncontrolled_upper_limit, controlled_upper_limit)
		lower_limit = np.minimum(uncontrolled_lower_limit, controlled_lower_limit)
		# upper_limit = 15
		# lower_limit = -10

		# print(noise_trajs[0,0,:], "\n")
		# print(noise_trajs[-1,0,:], "\n")
		# print(noise_trajs[20,0,:], "\n")
		# plot_1d_field(uncontrolled_trajectories, self.params)
		plot_1d_field_compare(uncontrolled_trajectories, controlled_trajectories, self.params, upper_limit, lower_limit)
		# plot_1d_field(controlled_trajs, self.params)

	def _build_graph(self):
		self.model._simulate_dynamics()




