import configparser
import tensorflow as tf
from mppi import MPPI
from model import Heat1D
from policy import Policy
import numpy as np

np_dtype = np.float32
tf_dtype = tf.float32


##################intialize random seed and pass it to functions###########################
seed = np.random.seed(1)
tfseed = tf.random.set_random_seed(1)
config = configparser.RawConfigParser()
config.read('1Dheat.cfg')

dt = config.getfloat('sec1', 'dt') #time increment
Tf = config.getfloat('sec1', 'Tf') #final time
a = config.getfloat('sec1', 'a') #length of heat line
J = config.getint('sec1', 'J') #number of noise expansion terms
iters = config.getint('sec1', 'iters') #number of MPC iterations per time step
rollouts = config.getint('sec1', 'rollouts') #number of rollouts
rho = config.getfloat('sec1', 'rho') #acts as "temperature", squared inverse of variance
learnrate = config.getfloat('sec1', 'learnrate') # learning rate for updates
epsilon = config.getfloat('sec1', 'epsilon') #heat pde constant (scaling of h_xx)
l2_scale = config.getfloat('sec1', 'l2_scale') #regularization scaling
#boundary_conds = config.getstring('sec1', 'boundary_conds')
desired_temperature = np.float32(config.getfloat('sec1', 'desired_temperature')) #goal temperature for MPC
#num_contour_levels = config.getint('sec1', 'num_contour_levels') #number of levels to plot
#vmin = config.getfloat('sec1', 'vmin') #min contour level to plot
#vmax = config.getfloat('sec1', 'vmax') #max contour level to plot
Q = config.getfloat('sec1', 'Q') #a single value
load_check = config.getboolean('sec1', 'load_network_check')
bc1 = config.getfloat('sec1', 'bc1') #Boundary condition at x=0
bc2 = config.getfloat('sec1', 'bc2') #Boundary condition at x=a
mpc_steps = int(np.ceil(Tf/dt)) # total number of MPC timesteps

# Get/compute actuator data
actuator_locs = np.asarray(config.get('sec2', 'actuator_locs').split(','), dtype=np_dtype) * np.float32(a) #actuator locations

hidden_layers = np.asarray(config.get('sec2', 'hidden_layers').split(','), dtype=np.int32) #list of hidden nodes in each layer
N = len(actuator_locs) #number of actuators
sig_val = np.float32(config.getfloat('sec2','sig_val') * a)
sig_val = np.square(sig_val) * np.ones(N)
sig_xx = sig_val


class Params(object):
	def __init__(self):
		self.bc1 = bc1
		self.bc2 = bc2
		self.l2_scale = l2_scale
		self.dt = dt
		self.a = a
		self.bj = np.sqrt(2.0 * self.dt/self.a)
		self.iterations = iters #
		self.learnrate = learnrate
		self.J = J 
		self.avg_spacing = a/J
		self.epsilon = epsilon
		self.rho = rho #tuning parameter
		self.N = N
		self.mpc_steps = mpc_steps
		self.rollouts = rollouts #tuning parameter
		self.actuator_locs = actuator_locs
		self.sig_xx = sig_xx
		self.hidden_layers = hidden_layers
		self.Q = Q #tuning parameter
		self.desired_state = np.zeros((1, J+1), dtype=np_dtype)
		#self.h_0 = tf.multiply(tf.ones((rollouts, J+1), dtype=np_dtype), tf.random.normal((1, J+1), dtype=tf_dtype))
		#print("Initial state: ",self.h_0)
		zeros_mat = np.zeros((self.rollouts, self.J+1), dtype=np_dtype)
		zeros_mat[:,0] = bc1
		zeros_mat[:,-1] = bc2
		self.h_0 = tf.constant()

		self.num_layers = len(hidden_layers)-1
		range1 = np.int32(np.arange(np.round(0.18*J), np.round(0.22*J)+1, 1) )
		range2 = np.int32(np.arange(np.round(0.48*J), np.round(0.52*J)+1, 1) )
		range3 = np.int32(np.arange(np.round(0.78*J), np.round(0.82*J)+1, 1) )
		self.desired_indices = np.hstack([range1, range2, range3])
		self.desired_state[0, range1] = desired_temperature
		self.desired_state[0, range2] = desired_temperature * 0.5
		self.desired_state[0, range3] = desired_temperature
		print("Desired state: ",self.desired_state)

		self.num_weights = (J+1)*hidden_layers[0] + hidden_layers[0]
		for j in range(self.num_layers):
			self.num_weights += hidden_layers[j]*hidden_layers[j+1] + hidden_layers[j+1]
		self.num_weights += hidden_layers[-1]*N + N
		print("Constructing a network with ",self.num_weights,"parameters")
		self.random_seed = seed
		self.tf_random_seed = tfseed

		self.load_check = load_check

params = Params()
policy = Policy(params)
heat1d = Heat1D(params)
mppi = MPPI(params, heat1d, policy)
mppi._mppi()



		