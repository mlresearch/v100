import numpy as np
import tensorflow as tf
from scipy.sparse import spdiags, identity, csc_matrix, csr_matrix, hstack, vstack
from scipy.sparse.linalg import inv
from utils import tf_integrate_eval, tf_dst, scipy_dst_1d
from abc import ABC, abstractmethod

np_dtype = np.float32
tf_dtype = tf.float32

class Model1DBase(ABC):
	def __init__(self, params):
		self.params = params
		self.m_vector = self._small_m_eval()
		self.M_tensor = self.compute_capital_M_eval()
		
	def _test_policy(self, policy):
		h_t = []
		h_t.append(self.params.h_0)

		# Sample new noise for test:
		self._sample_noise()

		# Forward pass
		print("\nBuilding dynamics propagation for test...")
		for t in range(self.params.mpc_steps):
			h_t.append(self._propagate(h_t[-1], policy, self.dQWiener[t,...]))

		self.test_h_traj = tf.stack(h_t, axis=0)		

	def _simulate_dynamics(self):
		
		h_t = []
		h_t.append(self.params.h_0)

		# expected to return cost and gradients
		self._sample_noise()

		# Forward pass
		print("\nBuilding dynamics propagation...")
		for t in range(self.params.mpc_steps):
			h_t.append(self._simulate(h_t[-1], self.dQWiener[t,...]))

		self.sim_traj = tf.stack(h_t, axis=0)

	def _generate_rollouts(self, policy):
		
		h_t = []
		h_t.append(self.params.h_0)

		# expected to return cost and gradients
		self._sample_noise()

		# Forward pass
		print("\nBuilding dynamics propagation...")
		for t in range(self.params.mpc_steps):
			h_t.append(self._propagate(h_t[-1], policy, self.dQWiener[t,...]))

		h_traj = tf.stack(h_t[1:], axis=0)

		# Compute costs
		print("\nBuilding cost computations...")
		self.state_cost = self._state_cost(h_traj)
		print("\nBuilding stochastic integral term computation...")
		self.noise_inner_product_cost = self._noise_inner_product(h_traj, policy)
		print("\nBuilding time integral term computation...")
		self.time_inner_product_cost = self._time_inner_product(h_traj, policy)
		self.total_cost = self.state_cost + 1/tf.sqrt(self.params.rho) * self.noise_inner_product_cost + 0.5 * self.time_inner_product_cost

		# Compute importance sampling weights
		print("\nBuilding weights computation...")
		weights = self._averaging(self.total_cost)

		# Compute objective function to be used as loss
		print("\nBuilding objective function computation...")
		self.objective_function = tf.reduce_sum(weights * (- tf.sqrt(self.params.rho) * self.noise_inner_product_cost -  0.5 * self.params.rho * self.time_inner_product_cost), axis=0)
		# self.deltaW = -tf.sqrt(self.params.rho) * tf.reduce_sum(weights * self._noise_grad_inner_product(h_traj, policy), axis=0, keepdims=True) \
		# 				+ self.params.rho * tf.reduce_sum(weights * self._time_grad_inner_product(h_traj, policy), axis=0, keepdims=True)
		print("\nBuilding average costs computation...")
		self.avg_state_cost = tf.reduce_mean(self.state_cost, name='avg_state_cost')
		self.avg_total_cost = tf.reduce_mean(self.total_cost, name='avg_total_cost')

		# for debugging:
		self.avg_im_weights = tf.reduce_mean(weights)
		self.avg_noise_prod_cost = tf.reduce_mean(self.noise_inner_product_cost)
		self.avg_time_prod_cost = tf.reduce_mean(self.time_inner_product_cost)
		self.all_weights = weights
		self.all_traj_costs = self.total_cost

	@abstractmethod
	def _propagate(self, h, policy, dQWiener):
		pass

	def _simulate(self, h, dQWiener):
		pass

	@abstractmethod
	def _generate_prop_matrix(self):
		pass

	def _averaging(self, costvec):
		min_cost = tf.math.reduce_min(costvec)
		# costvec = costvec - min_cost
		cost = tf.exp(-self.params.rho * costvec)
		return cost/(tf.reduce_sum(cost)+1e-5)


	def _small_m_fcn(self,x,n):
		temp = np.exp( -0.5 * ((x-self.params.actuator_locs[n])**2)/self.params.sig_xx[n])
		return temp

	def _small_m_eval(self):
		#small m evaluated over space and control dimension
		m_vector = np.zeros((self.params.N, self.params.J+1), dtype=np_dtype)
		for n in range(self.params.N):
			for j in range(1, self.params.J): # start from second index, go to one from the end so that we cannot control the boundary 
				x = j*self.params.a/self.params.J
				m_vector[n,j] = self._small_m_fcn(x,n)

		return tf.constant(m_vector, dtype=tf_dtype) #shape = (N, J+1)

	def _sample_noise(self):

		# rands = tf.random.normal((self.params.mpc_steps, self.params.rollouts, self.params.J-1), seed=self.params.random_seed)
		# rands = tf.expand_dims(tf_dst(rands), -1)

		left_boundary = tf.zeros((self.params.mpc_steps, self.params.rollouts, 1), dtype=tf_dtype) # shape = (T, rollouts)
		right_boundary = tf.zeros((self.params.mpc_steps, self.params.rollouts, 1), dtype=tf_dtype)
		center_rands = tf.random.normal((self.params.mpc_steps * self.params.rollouts, self.params.J-1), seed=self.params.random_seed)
		
		# with tf_dst:
		# dW_center_rands = tf.reshape(tf_dst(center_rands), [self.params.mpc_steps, self.params.rollouts, self.params.J-1])

		# With scipy dst:
		dW_center_rands = tf.reshape(tf.py_func(scipy_dst_1d, [center_rands], tf_dtype), [self.params.mpc_steps, self.params.rollouts, self.params.J-1])		
		center_rands = tf.reshape(center_rands, (self.params.mpc_steps, self.params.rollouts, self.params.J-1))

		# Q-Wiener increments:
		self.dQWiener = self.params.bj * tf.concat(values=[left_boundary, dW_center_rands, right_boundary], axis=-1) #shape = (time, rollouts, J+1)


	def compute_capital_M(self, x):
		M = np.zeros((self.params.N,self.params.N), dtype=np_dtype)

		for i in range(self.params.N):
			for j in range(self.params.N):
				M[i,j] = self._small_m_fcn(x,i) * self._small_m_fcn(x,j)

		return M

	def compute_capital_M_eval(self):
		M_tensor = np.zeros((self.params.J+1, self.params.N, self.params.N), dtype=np_dtype)
		for j in range(self.params.J+1):
			x = j*self.params.a/self.params.J
			M_tensor[j,:,:] = self.compute_capital_M(x)

		return tf.constant(M_tensor, dtype=tf_dtype) #shape= (J+1, N, N)


	def _time_inner_product(self, h_traj, policy):
		#integrate temporally the inner product (spatial integral) of the policy and itself
		#h_traj should be shape = (T, rollouts, J+1)
		inner_product_sum = []#tf.zeros((self.params.rollouts), dtype=np_dtype)
		M_expand = tf.multiply(tf.ones((self.params.rollouts, self.params.J+1, self.params.N, self.params.N), dtype=tf_dtype), self.M_tensor) #shape = (rollouts, (J+1), N, N)

		#xvec = np.zeros((J))
		#fun = lambda x, t: policy(h_traj[t, (x-self.params.xvals[0])/self.params.x_step_size]).T * self.compute_capital_M(x) * policy(h_traj[t, (x-self.params.xvals[0])/self.params.x_step_size]) #ensure policy can accept scalar x. build it to zero out other spatial elements
		for t in range(self.params.mpc_steps):
			policy_eval = policy._policy_eval(h_traj[t,:,:]) #shape = (rollouts, (J+1), N)
			inner_product = tf.matmul(tf.matmul(tf.expand_dims(policy_eval, axis=-2), M_expand), tf.expand_dims(policy_eval, axis=-1) ) # shape = (rollouts, (J+1), 1, 1)
			inner_product = tf.squeeze(inner_product) # shape = (rollouts, (J+1))
			inner_product_sum.append( tf_integrate_eval(inner_product, self.params.avg_spacing) * self.params.dt) #shape = rollouts
			#inner_product_sum += integrate_eval(fun(self.params.avg_spacing, t), self.params.avg_spacing)
		return tf.squeeze(tf.math.add_n(inner_product_sum)) #shape = (rollouts)

	def _noise_inner_product(self, h_traj, policy):
		inner_product_time_sum = []
		small_m_expand = tf.expand_dims(tf.multiply(tf.ones((self.params.rollouts, self.params.J+1, self.params.N), dtype=tf_dtype), tf.transpose(self.m_vector)), axis=-1) #shape=(rollouts, (J+1), N, 1)
		#dQWiener is of shape = (time, rollouts, J+1)

		for t in range(self.params.mpc_steps):
			policy_eval = tf.expand_dims(policy._policy_eval(h_traj[t,:,:]), axis=-2) #shape = (rollouts, (J+1), 1, N)
			phi_m = tf.squeeze(tf.matmul(policy_eval, small_m_expand)) #shape = (rollouts, J+1)
			inner_product_time_sum.append( tf_integrate_eval(phi_m * self.dQWiener[t,:,:], self.params.avg_spacing) * self.params.dt) #shape = [T](rollouts)

		return tf.squeeze(tf.math.add_n(inner_product_time_sum)) # shape = (rollouts)


	def _state_cost(self, h_traj):
		# desired state should be of shape = (J+1)
		desired_state = tf.ones((self.params.mpc_steps, self.params.rollouts, self.params.J+1), dtype=tf_dtype) * self.params.desired_state
		cost_sq = self.params.Q * tf.square(tf.gather(desired_state, self.params.desired_indices, axis=-1) - tf.gather(h_traj,self.params.desired_indices, axis=-1))
		return tf.reduce_sum(cost_sq, axis=[0,2]) #shape = (rollouts)



class Heat1D(Model1DBase):
	def __init__(self, params):
		super().__init__(params)
		self.prop_matrix = self._generate_prop_matrix()

	def _propagate(self, h, policy, dQWiener):
		# h is of shape = (rollouts, J+1)
		# policy is a Policy object
		# dQWiener should have shape = (rollouts, J+1)
		u = tf.expand_dims(policy._policy_forward_pass(h), axis=-1) #shape = (rollouts, N, 1)
		mvec = tf.transpose(tf.multiply(tf.ones((self.params.rollouts, self.params.N, self.params.J+1)), tf.expand_dims(self.m_vector, axis=0)), perm=[0,2,1]) #shape = (rollouts, J+1, N)
		applied_control = tf.squeeze(tf.matmul(mvec, u)) #shape = (rollouts, J+1)
		h_new = tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h + applied_control * self.params.dt + 1.0/tf.sqrt(self.params.rho) * dQWiener)))
		# h_new = tf.matmul(tf.sparse_tensor_to_dense(EE_inv_tensor_cpu), h_n + dW_n, a_is_sparse=True)
		return h_new

	def _simulate(self, h, dQWiener):
		return tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h + 1.0/tf.sqrt(self.params.rho) * dQWiener)))

	def _generate_prop_matrix(self):

		diag_data = np.ones((self.params.J-1,1), dtype=np.float32)
		data = np.squeeze(np.asarray([-diag_data,  2*diag_data, -diag_data]))
		diagonals = np.asarray([-1, 0, 1])
		sp_A = (self.params.dt*self.params.epsilon/self.params.avg_spacing**2) * spdiags(data, diagonals, self.params.J-1, self.params.J-1) #J+1 x J+1 sparse matrix with 'data' placed on diagonals specified by 'diagonals'
		sp_I = identity((self.params.J-1), format='dia', dtype=np_dtype)
		prop_matrix = csc_matrix(sp_I + sp_A)
		prop_matrix_inv = inv(prop_matrix)

		# add boundaries
		zero_col = csc_matrix(np.zeros((self.params.J-1,1), dtype=np_dtype))
		zero_row = csc_matrix(np.zeros((1,self.params.J+1), dtype=np_dtype))
		prop_matrix_inv = vstack([zero_row, hstack([zero_col, prop_matrix_inv, zero_col]), zero_row]) #dynamics are zero at boundaries
		prop_matrix_inv_coo = prop_matrix_inv.tocoo() #convert to [ijv] format

		indices = np.mat([prop_matrix_inv_coo.row, prop_matrix_inv_coo.col]).transpose() #this returns a matrix of shape = (2, num_values), but we transpose because tf.SparseTensor needs (num_values, n_dims)
		return tf.sparse_reorder(tf.SparseTensor(indices=indices, values=prop_matrix_inv_coo.data, dense_shape=prop_matrix_inv_coo.shape))


class Burgers1D(Model1DBase):
	def __init__(self, params):
		super().__init__(params)
		self.prop_matrix = self._generate_prop_matrix() # shape: (J-1)x(J-1)
		print("Burgers 1D")

	def _propagate(self, h, policy, dQWiener):
		# h is of shape = (rollouts, J+1)
		# policy is a Policy object
		# dQWiener should have shape = (rollouts, J+1)

		# First propagate the points inside the boundary and then add boundary values:
		u = tf.expand_dims(policy._policy_forward_pass(h), axis=-1) #shape = (rollouts, N, 1)
		mvec = tf.transpose(tf.multiply(tf.ones((self.params.rollouts, self.params.N, self.params.J+1)), tf.expand_dims(self.m_vector, axis=0)), perm=[0,2,1]) #shape = (rollouts, J+1, N)
		applied_control = tf.squeeze(tf.matmul(mvec, u)) #shape = (rollouts, J+1) after squeeze

		# Add boundary effect(not included in sparse matrix as it is only (J-1)x(J-1)):
		x_0 = tf.ones((self.params.rollouts, 1), dtype=tf_dtype) * self.params.bc1
		x_a = tf.ones((self.params.rollouts, 1), dtype=tf_dtype) * self.params.bc2 
		x_middle = tf.zeros((self.params.rollouts, (self.params.J-3)), dtype=tf_dtype)		

		boundary_effect = (self.params.dt*self.params.epsilon/self.params.avg_spacing**2) * tf.concat([x_0, x_middle, x_a], axis=-1) # shape:(rollouts, J-1)

		h_new = tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h[:,1:-1] - self._nonlinear_term(h) + applied_control[:, 1:-1] * self.params.dt \
																			+ boundary_effect + 1.0/tf.sqrt(self.params.rho) * dQWiener[:, 1:-1]))) # shape:(rollouts, J-1)

		return tf.concat([x_0, h_new, x_a], axis=-1) # shape:(rollouts, J-1)

	def _simulate(self, h, dQWiener):
		# Add boundary effect(not included in sparse matrix as it is only (J-1)x(J-1)):
		x_0 = tf.ones((self.params.rollouts, 1), dtype=tf_dtype) * self.params.bc1
		x_a = tf.ones((self.params.rollouts, 1), dtype=tf_dtype) * self.params.bc2 
		x_middle = tf.zeros((self.params.rollouts, (self.params.J-3)), dtype=tf_dtype)		

		boundary_effect = (self.params.dt*self.params.epsilon/self.params.avg_spacing**2) * tf.concat([x_0, x_middle, x_a], axis=-1) # shape:(rollouts, J-1)

		h_new = tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h[:,1:-1] - self._nonlinear_term(h) \
																			+ boundary_effect + 1.0/tf.sqrt(self.params.rho) * dQWiener[:, 1:-1]))) # shape:(rollouts, J-1)

		return tf.concat([x_0, h_new, x_a], axis=-1) # shape:(rollouts, J-1)


	def _nonlinear_term(self, h):
		# h is of shape = (rollouts, J+1) 
		# boundary conditions are included in h 
		temp = h[:,1:-1] * 0.5 * (self.params.dt/self.params.avg_spacing) * (h[:, 2:] - h[:, 0:-2]) # 0.5 for central difference for spatial derivative
		return temp # shape:(rollouts, J-1)

	def _generate_prop_matrix(self):

		diag_data = np.ones((self.params.J-1,1), dtype=np.float32)
		data = np.squeeze(np.asarray([-diag_data,  2*diag_data, -diag_data]))
		diagonals = np.asarray([-1, 0, 1])
		sp_A = (self.params.dt*self.params.epsilon/self.params.avg_spacing**2) * spdiags(data, diagonals, self.params.J-1, self.params.J-1) #J+1 x J+1 sparse matrix with 'data' placed on diagonals specified by 'diagonals'
		sp_I = identity((self.params.J-1), format='dia', dtype=np_dtype)
		prop_matrix = csc_matrix(sp_I + sp_A)
		prop_matrix_inv = inv(prop_matrix)
		prop_matrix_inv_coo = prop_matrix_inv.tocoo() #convert to [ijv] format
		indices = np.mat([prop_matrix_inv_coo.row, prop_matrix_inv_coo.col]).transpose() #this returns a matrix of shape = (2, num_values), but we transpose because tf.SparseTensor needs (num_values, n_dims)
		return tf.sparse_reorder(tf.SparseTensor(indices=indices, values=prop_matrix_inv_coo.data, dense_shape=prop_matrix_inv_coo.shape)) # shape: (J-1)x(J-1)



class Nagumo1D(Model1DBase):
	def __init__(self, params):
		super().__init__(params)
		self.prop_matrix = self._generate_prop_matrix()

	def _propagate(self, h, policy, dQWiener):
		# h is of shape = (rollouts, J+1)
		# policy is a Policy object
		# dQWiener should have shape = (rollouts, J+1)
		u = tf.expand_dims(policy._policy_forward_pass(h), axis=-1) #shape = (rollouts, N, 1)
		mvec = tf.transpose(tf.multiply(tf.ones((self.params.rollouts, self.params.N, self.params.J+1)), tf.expand_dims(self.m_vector, axis=0)), perm=[0,2,1]) #shape = (rollouts, J+1, N)
		applied_control = tf.squeeze(tf.matmul(mvec, u))
		h_new = tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h + self._nonlinear_term(h) + applied_control * self.params.dt + 1.0/tf.sqrt(self.params.rho) * dQWiener)))
		# h_new = tf.matmul(tf.sparse_tensor_to_dense(EE_inv_tensor_cpu), h_n + dW_n, a_is_sparse=True)
		return h_new

	def _simulate(self, h, dQWiener):
		return tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h + self._nonlinear_term(h) + 1.0/tf.sqrt(self.params.rho) * dQWiener)))


	def _nonlinear_term(self, h):
		# h is of shape = (rollouts, J+1) 
		# boundary conditions are included in h 
		return h * (1 - h) * (h - self.params.wave_speed) * self.params.dt

	def _generate_prop_matrix(self):

		diag_data = np.ones((self.params.J+1,1), dtype=np_dtype)
		data = np.squeeze(np.asarray([-diag_data,  2*diag_data, -diag_data]))
		data[0,-2] = -2 #subdiagonal
		data[-1,1] = -2 #superdiagonal
		diagonals = np.asarray([-1, 0, 1])
		sp_A = (self.params.dt*self.params.epsilon/self.params.avg_spacing**2) * spdiags(data, diagonals, self.params.J+1, self.params.J+1) #J+1 x J+1 sparse matrix with 'data' placed on diagonals specified by 'diagonals'
		sp_I = identity((self.params.J+1), format='dia', dtype=np_dtype)
		prop_matrix = csc_matrix(sp_I + sp_A)
		prop_matrix_inv = inv(prop_matrix)

		# # add boundaries
		# np_zeros_vec = np.zeros((self.params.J-1,1), dtype=np_dtype)
		# np_zeros_vec[0,0] = -1.0
		# left_col = csc_matrix(np_zeros_vec)
		# np_zeros_vec[0,0], np_zeros_vec[-1,0] = 0.0, -1.0
		# right_col = csc_matrix(np_zeros_vec)

		# zero_row = csc_matrix(np.zeros((1,self.params.J+1), dtype=np_dtype))
		# prop_matrix_inv = vstack([zero_row, hstack([left_col, prop_matrix_inv, right_col]), zero_row]) #dynamics are zero at boundaries
		prop_matrix_inv_coo = prop_matrix_inv.tocoo() #convert to [ijv] format

		indices = np.mat([prop_matrix_inv_coo.row, prop_matrix_inv_coo.col]).transpose() #this returns a matrix of shape = (2, num_values), but we transpose because tf.SparseTensor needs (num_values, n_dims)
		return tf.sparse_reorder(tf.SparseTensor(indices=indices, values=prop_matrix_inv_coo.data, dense_shape=prop_matrix_inv_coo.shape))


class Heat1D_boundary(Model1DBase):
	def __init__(self, params):
		self.params = params
		self.m_vector = self._small_m_eval()
		self.M_tensor = self.compute_capital_M_eval()
		self.prop_matrix = self._generate_prop_matrix()

	def _propagate(self, h, policy, dQWiener):
		# h is of shape = (rollouts, J+1)
		# policy is a Policy object
		# dQWiener should have shape = (rollouts, J+1)
		u = policy._policy_forward_pass(h) #shape = (rollouts, N)
		# mvec = tf.transpose(tf.multiply(tf.ones((self.params.rollouts, self.params.N, self.params.J+1)), tf.expand_dims(self.m_vector, axis=0)), perm=[0,2,1]) #shape = (rollouts, J+1, N)
		# applied_control = tf.squeeze(tf.matmul(mvec, u)) #shape = (rollouts, J+1)

		# Add boundary effect:
		x_0 = -2 * (self.params.epsilon/self.params.avg_spacing) * (self.params.dt*u[:,0]  + 1.0/tf.sqrt(self.params.rho) * dQWiener[:,0])
		x_a =  2 * (self.params.epsilon/self.params.avg_spacing) * (self.params.dt*u[:,-1] + 1.0/tf.sqrt(self.params.rho) * dQWiener[:,-1])
		x_middle = tf.zeros((self.params.rollouts, (self.params.J-1)), dtype=tf_dtype)		

		boundary_noise_control = tf.concat([tf.expand_dims(x_0,-1) , x_middle, tf.expand_dims(x_a,-1)], axis=-1) # shape:(rollouts, J+1)

		h_new = tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h + boundary_noise_control)))
		# h_new = tf.matmul(tf.sparse_tensor_to_dense(EE_inv_tensor_cpu), h_n + dW_n, a_is_sparse=True)
		return h_new

	def _simulate(self, h, dQWiener):

		# Add boundary effect:
		x_0 = -2 * (self.params.epsilon/self.params.avg_spacing) * 1.0/tf.sqrt(self.params.rho) * dQWiener[:,0]
		x_a =  2 * (self.params.epsilon/self.params.avg_spacing) * 1.0/tf.sqrt(self.params.rho) * dQWiener[:,-1]
		x_middle = tf.zeros((self.params.rollouts, (self.params.J-1)), dtype=tf_dtype)		

		boundary_noise = tf.concat([tf.expand_dims(x_0,-1) , x_middle, tf.expand_dims(x_a,-1)], axis=-1) # shape:(rollouts, J+1)

		return tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h + boundary_noise)))

	def _generate_prop_matrix(self):

		diag_data = np.ones((self.params.J+1,1), dtype=np_dtype)
		data = np.squeeze(np.asarray([-diag_data,  2*diag_data, -diag_data]))
		data[0,-2] = -2 #subdiagonal
		data[-1,1] = -2 #superdiagonal
		diagonals = np.asarray([-1, 0, 1])
		sp_A = (self.params.dt*self.params.epsilon/self.params.avg_spacing**2) * spdiags(data, diagonals, self.params.J+1, self.params.J+1) #J+1 x J+1 sparse matrix with 'data' placed on diagonals specified by 'diagonals'
		sp_I = identity((self.params.J+1), format='dia', dtype=np_dtype)
		prop_matrix = csc_matrix(sp_I + sp_A)
		prop_matrix_inv = inv(prop_matrix)

		prop_matrix_inv_coo = prop_matrix_inv.tocoo() #convert to [ijv] format

		indices = np.mat([prop_matrix_inv_coo.row, prop_matrix_inv_coo.col]).transpose() #this returns a matrix of shape = (2, num_values), but we transpose because tf.SparseTensor needs (num_values, n_dims)
		return tf.sparse_reorder(tf.SparseTensor(indices=indices, values=prop_matrix_inv_coo.data, dense_shape=prop_matrix_inv_coo.shape))


	def _small_m_eval(self):
		#small m evaluated over space and control dimension
		m_vector = np.zeros((self.params.N, self.params.J+1), dtype=np_dtype)
		m_vector[0,0] = 1
		m_vector[-1,-1] = 1

		return tf.constant(m_vector, dtype=tf_dtype) #shape = (N, J+1)

	def compute_capital_M_eval(self):
		return tf.eye(self.params.N, dtype=tf_dtype)

	def _sample_noise(self):

		noise = tf.random.normal((self.params.mpc_steps, self.params.rollouts, self.params.N), seed=self.params.random_seed)
		# Q-Wiener increments:
		self.dQWiener = tf.sqrt(self.params.dt/self.params.avg_spacing) * tf.concat(values=[tf.expand_dims(noise[:,:,0], axis=-1), \
								tf.zeros((self.params.mpc_steps, self.params.rollouts, self.params.J-1), dtype=tf_dtype), \
								tf.expand_dims(noise[:,:,-1], axis=-1)], axis=-1) #shape = (time, rollouts, J+1)

	def _state_cost(self, h_traj):
		# desired state should be of shape = (J+1)
		desired_state = tf.ones((self.params.mpc_steps, self.params.rollouts, self.params.J+1), dtype=tf_dtype) * self.params.desired_state
		cost_sq = self.params.Q * tf.square(tf.gather(desired_state, self.params.desired_indices, axis=-1) - tf.gather(h_traj,self.params.desired_indices, axis=-1))
		return tf.reduce_sum(cost_sq, axis=[0,2]) #shape = (rollouts)



class Nagumo1D_boundary(Model1DBase):
	def __init__(self, params):
		self.params = params
		self.m_vector = self._small_m_eval()
		self.M_tensor = self.compute_capital_M_eval()
		self.prop_matrix = self._generate_prop_matrix()
		print("\nBuilding model for Nagumo 1D boundary control task (Suppression only)")

	def _propagate(self, h, policy, dQWiener):
		# h is of shape = (rollouts, J+1)
		# policy is a Policy object
		# dQWiener should have shape = (rollouts, J+1)
		u = policy._policy_forward_pass(h) #shape = (rollouts, N)

		# Add boundary effect:
		# x_0 = -2 * (self.params.epsilon/self.params.avg_spacing) * (self.params.dt*u[:,0]  + 1.0/tf.sqrt(self.params.rho) * dQWiener[:,0])
		x_a =  2 * (self.params.epsilon/self.params.avg_spacing) * (self.params.dt*u[:,-1] + 1.0/tf.sqrt(self.params.rho) * dQWiener[:,-1])
		x_middle = tf.zeros((self.params.rollouts, (self.params.J)), dtype=tf_dtype)	

		boundary_noise_control = tf.concat([x_middle, tf.expand_dims(x_a,-1)], axis=-1) # shape:(rollouts, J+1)

		h_new = tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h + boundary_noise_control + self._nonlinear_term(h))))
		return h_new

	def _simulate(self, h, dQWiener):

		# Add boundary effect:
		# x_0 = -2 * (self.params.epsilon/self.params.avg_spacing) * 1.0/tf.sqrt(self.params.rho) * dQWiener[:,0]
		x_a =  2 * (self.params.epsilon/self.params.avg_spacing) * 1.0/tf.sqrt(self.params.rho) * dQWiener[:,-1]
		x_middle = tf.zeros((self.params.rollouts, (self.params.J)), dtype=tf_dtype)		

		boundary_noise = tf.concat([x_middle, tf.expand_dims(x_a,-1)], axis=-1) # shape:(rollouts, J+1)

		return tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h + boundary_noise + self._nonlinear_term(h))))

	def _nonlinear_term(self, h):
		# h is of shape = (rollouts, J+1) 
		# boundary conditions are included in h 
		return h * (1 - h) * (h - self.params.wave_speed) * self.params.dt

	def _generate_prop_matrix(self):

		diag_data = np.ones((self.params.J+1,1), dtype=np_dtype)
		data = np.squeeze(np.asarray([-diag_data,  2*diag_data, -diag_data]))
		data[0,-2] = -2 #subdiagonal
		data[-1,1] = -2 #superdiagonal
		diagonals = np.asarray([-1, 0, 1])
		sp_A = (self.params.dt*self.params.epsilon/self.params.avg_spacing**2) * spdiags(data, diagonals, self.params.J+1, self.params.J+1) #J+1 x J+1 sparse matrix with 'data' placed on diagonals specified by 'diagonals'
		sp_I = identity((self.params.J+1), format='dia', dtype=np_dtype)
		prop_matrix = csc_matrix(sp_I + sp_A)
		prop_matrix_inv = inv(prop_matrix)

		prop_matrix_inv_coo = prop_matrix_inv.tocoo() #convert to [ijv] format

		indices = np.mat([prop_matrix_inv_coo.row, prop_matrix_inv_coo.col]).transpose() #this returns a matrix of shape = (2, num_values), but we transpose because tf.SparseTensor needs (num_values, n_dims)
		return tf.sparse_reorder(tf.SparseTensor(indices=indices, values=prop_matrix_inv_coo.data, dense_shape=prop_matrix_inv_coo.shape))


	def _small_m_eval(self):
		#small m evaluated over space and control dimension
		m_vector = np.zeros((self.params.N, self.params.J+1), dtype=np_dtype)
		m_vector[:,-1] = 1

		return tf.constant(m_vector, dtype=tf_dtype) #shape = (N, J+1)

	def compute_capital_M_eval(self):
		return tf.ones((self.params.N, self.params.N), dtype=tf_dtype)

	def _sample_noise(self):

		noise = tf.random.normal((self.params.mpc_steps, self.params.rollouts, self.params.N), seed=self.params.random_seed)
		# Q-Wiener increments:
		self.dQWiener = tf.sqrt(self.params.dt/self.params.avg_spacing) * tf.concat(values=[tf.zeros((self.params.mpc_steps, self.params.rollouts, self.params.J), dtype=tf_dtype), \
								tf.expand_dims(noise[:,:,-1], axis=-1)], axis=-1) #shape = (time, rollouts, J+1)

	# def _state_cost_old(self, h_traj):
	# 	# desired state should be of shape = (J+1)
	# 	# desired_state = tf.ones((self.params.mpc_steps, self.params.rollouts, self.params.J+1), dtype=tf_dtype) * self.params.desired_state
	# 	cost_sq = self.params.Q * tf.square(self.params.desired_state - h_traj[:,:,1:-1])
	# 	return tf.reduce_sum(cost_sq, axis=[0,2]) #shape = (rollouts)		

	def _state_cost(self, h_traj):
		# desired state should be of shape = (J+1)
		desired_state = tf.ones((self.params.mpc_steps, self.params.rollouts, self.params.J+1), dtype=tf_dtype) * self.params.desired_state
		cost_sq = self.params.Q * tf.square(tf.gather(desired_state, self.params.desired_indices, axis=-1) - tf.gather(h_traj,self.params.desired_indices, axis=-1))
		return tf.reduce_sum(cost_sq, axis=[0,2]) #shape = (rollouts)
