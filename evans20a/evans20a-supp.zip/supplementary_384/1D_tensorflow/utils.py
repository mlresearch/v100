import numpy as np
import tensorflow as tf
from scipy.fftpack import dst
np_dtype = np.float32
import matplotlib.pyplot as plt
import datetime
import sys
from matplotlib.lines import Line2D
from matplotlib import cm

# move this to utils
def integrate(function, values):
	# integrates the function 'function' over the discrete, monotonic, ordered values 'values' by using trapezial integration
	#spacing = values[1]-values[0] # if 'values' are equally spaced, can pick any two consecutive elements
	avg_spacing = np.absolute(values[-1] - values[0])/num(values)

	first = function(values[0])
	last = function(values[-1])

	#make sure function can accept arrays
	middle = function(values[1:-2])

	return np.float32( avg_spacing * ( first/2 + last/2 + np.sum(middle) ) )

# move this to utils
def integrate_eval(feval, values):
	# integrates the evaluated function 'feval' over the discrete, monotonic, ordered values 'values' by using trapezial integration
	# accepts feval of any shape, integration performed on last dimension
	# accepts values of shape vector
	avg_spacing = np.absolute(values[-1] - values[0])/num(values)

	first = feval[...,0]
	last = feval[...,-1]
	middle = np.array(feval[...,1:-1])

	return np.float32( avg_spacing * ( first/2 + last/2 + np.sum(middle, axis=-1) ) ) #removes last dimension while reducing during integration


def tf_integrate_eval(feval, avg_spacing):
	# integrates the evaluated function 'feval' by using trapezial integration. avg_spacing is the average spacing between function calls
	# accepts any shape, integration performed on last dimension

	first = feval[...,0]
	last = feval[...,-1]
	middle = feval[...,1:-1]

	return  avg_spacing * ( first/2 + last/2 + tf.reduce_sum(middle, axis=-1) )  #removes last dimension while reducing during integration

def scipy_dst_1d(Xi_):
	return 0.5*dst(Xi_, type=1)

def tf_dst(A):
	# Given noise values in A, this function generates the truncated sum of the Q-Wiener expansion
	# A should be real rank 2 tensor, function returns a real rank 2 tensor,
	# fft is occuring over the second dimension of A, broadcast over first dimension
	n, m = A.get_shape().as_list()
	A = tf.complex(A, tf.zeros((n,m), dtype=tf.float32))
	A_tf_rev = tf.reverse(-A, [0])
	y = tf.concat([tf.zeros([1,m], dtype=tf.complex64), A, tf.zeros([1,m], dtype=tf.complex64), A_tf_rev], axis=0)
	yy = tf.fft(y)
	deno = tf.complex(0.0,-2.0)
	return tf.real(yy[1:n+1,:]/deno)

def plot_1d_field_old(trajectories, params):
	mean_traj = np.mean(trajectories, axis=1) # (100,65)
	std_traj = 2*np.std(trajectories, axis=1) # plotting 2 sigma 
	x_axis = np.arange(0,params.J+1,1)
	fig = plt.figure()
	ax = plt.gca()
	upper_limit = np.amax(mean_traj) + np.amax(std_traj) + 0.5
	lower_limit = np.amin(mean_traj) - np.amin(std_traj) - 0.5
	for i in range(params.mpc_steps + 1):
		sys.stdout.write("step: %d/%d \r" % (i, params.mpc_steps))
		sys.stdout.flush()
		plt.cla()
		ax.plot(x_axis, mean_traj[i,:])
		ax.fill_between(x_axis, mean_traj[i,:] - std_traj[i,:], mean_traj[i,:] + std_traj[i,:], alpha=0.2)
		plt.ylim((lower_limit, upper_limit))
		plt.pause(0.01)

	plt.show()	

def plot_1d_field_compare(uncontrolled_trajectories, controlled_trajectories, params):
	uncontrolled_mean_traj = np.mean(uncontrolled_trajectories, axis=1) # (100,65)
	uncontrolled_std_traj = 2*np.std(uncontrolled_trajectories, axis=1) # plotting 2 sigma 
	uncontrolled_upper_limit = np.amax(uncontrolled_mean_traj) + np.amax(uncontrolled_std_traj) + 0.1
	uncontrolled_lower_limit = np.amin(uncontrolled_mean_traj) - np.amax(uncontrolled_std_traj) - 0.1

	controlled_mean_traj = np.mean(controlled_trajectories, axis=1) # (100,65)
	controlled_std_traj = 2*np.std(controlled_trajectories, axis=1) # plotting 2 sigma 
	controlled_upper_limit = np.amax(controlled_mean_traj) + np.amax(controlled_std_traj) + 0.1
	controlled_lower_limit = np.amin(controlled_mean_traj) - np.amax(controlled_std_traj) - 0.1

	# x_axis = np.arange(0,params.J+1,1)
	x_axis = np.arange(0,params.a+params.avg_spacing,params.avg_spacing)
	fig = plt.figure(dpi=params.dpi)
	ax = plt.gca()

	upper_limit = np.maximum(uncontrolled_upper_limit, controlled_upper_limit)
	lower_limit = np.minimum(uncontrolled_lower_limit, controlled_lower_limit)

	actuator_y_coo = np.ones((params.N,1)) * (lower_limit)
	actuator_lines = []
	for j in range(params.N):
		actuator_lines.append(Line2D(xdata=[params.actuator_locs[j], params.actuator_locs[j]],\
									 ydata=[upper_limit, lower_limit], linestyle=':', color='red', alpha=0.4, dash_joinstyle='round'))

	for i in range(params.mpc_steps + 1):
		sys.stdout.write("step: %d/%d \r" % (i, params.mpc_steps))
		sys.stdout.flush()
		plt.cla()
		plt.xlabel(params.xlabel)
		plt.ylabel(params.ylabel)
		
		ax.plot(x_axis, uncontrolled_mean_traj[i,:], linewidth=1.5)
		ax.fill_between(x_axis, uncontrolled_mean_traj[i,:] - uncontrolled_std_traj[i,:], uncontrolled_mean_traj[i,:] + uncontrolled_std_traj[i,:], alpha=0.4)

		ax.plot(x_axis, controlled_mean_traj[i,:], linewidth=1.5)
		ax.fill_between(x_axis, controlled_mean_traj[i,:] - controlled_std_traj[i,:], controlled_mean_traj[i,:] + controlled_std_traj[i,:], alpha=0.4)

		ax.plot(params.actuator_locs, actuator_y_coo, 'o', color='red', clip_on=False, markersize=7)
		if len(params.desired_state.shape)==3:
			ax.plot(x_axis, np.squeeze(params.desired_state[i,0,:]), '-', linewidth=1.5)
		else:
			ax.plot(x_axis, np.squeeze(params.desired_state), '-', linewidth=1.5)
		ax.legend(['Mean Uncontrolled Trajectory', 'Mean Controlled Trajectory', 'Actuator Centers', 'Desired profile'])	
		for j in range(params.N):
			ax.add_line(actuator_lines[j])
			# ax.fill_betweenx(y=actuator_lines[j].get_ydata(orig=False), x1=params.actuator_locs[j] - np.sqrt(params.sig_xx[j]), \
			# 				 x2= params.actuator_locs[j] + np.sqrt(params.sig_xx[j]), alpha=0.1, color='red')

		plt.ylim((lower_limit, upper_limit))
		plt.title(params.title)	
		# plt.savefig('savedir/video_data/'+str(i)+'.png')
		plt.pause(0.01)
		if i == params.mpc_steps:
			plt.savefig('savedir/plots/'+params.plot_name+'.png')

	plt.pause(1.0)
	plt.show(block=False)			

	print("plotting contour plot showing time evolution ... ")
	fig = plt.figure(dpi=params.dpi)
	ax = plt.gca()
	# Y = np.arange(params.dt, (controlled_mean_traj.shape[0])*params.dt, params.dt)
	Y = np.arange(0, (controlled_mean_traj.shape[0])*params.dt, params.dt)
	X = np.arange(0, (controlled_mean_traj.shape[1])*params.avg_spacing, params.avg_spacing)
	X, Y = np.meshgrid(X, Y)	
	# import pdb
	# pdb.set_trace()

	plt.contourf(X, Y, controlled_mean_traj, levels=200, cmap=cm.jet)
	plt.colorbar(orientation='horizontal', )
	plt.xlabel(params.xlabel)
	plt.ylabel("time in seconds")	
	plt.savefig('savedir/plots/'+params.plot_name+'_contour'+'.png')
	plt.show()

def plot_1d_field(controlled_trajectories, params):

	controlled_mean_traj = np.mean(controlled_trajectories, axis=1) # (100,65)
	controlled_std_traj = 2*np.std(controlled_trajectories, axis=1) # plotting 2 sigma 
	controlled_upper_limit = np.amax(controlled_mean_traj) + np.amax(controlled_std_traj) + 0.1
	controlled_lower_limit = np.amin(controlled_mean_traj) - np.amax(controlled_std_traj) - 0.1

	# x_axis = np.arange(0,params.J+1,1)
	x_axis = np.arange(0,params.a+params.avg_spacing,params.avg_spacing)
	fig = plt.figure(dpi=params.dpi)
	ax = plt.gca()

	upper_limit = controlled_upper_limit
	lower_limit = controlled_lower_limit

	actuator_y_coo = np.ones((params.N,1)) * (lower_limit)
	actuator_lines = []
	for j in range(params.N):
		actuator_lines.append(Line2D(xdata=[params.actuator_locs[j], params.actuator_locs[j]],\
									 ydata=[upper_limit, lower_limit], linestyle=':', color='red', alpha=0.4, dash_joinstyle='round'))

	for i in range(params.mpc_steps + 1):
		sys.stdout.write("step: %d/%d \r" % (i, params.mpc_steps))
		sys.stdout.flush()
		plt.cla()
		plt.xlabel(params.xlabel)
		plt.ylabel(params.ylabel)
		

		ax.plot(x_axis, controlled_mean_traj[i,:], linewidth=1.5)
		ax.fill_between(x_axis, controlled_mean_traj[i,:] - controlled_std_traj[i,:], controlled_mean_traj[i,:] + controlled_std_traj[i,:], alpha=0.4)

		ax.plot(params.actuator_locs, actuator_y_coo, 'o', color='red', clip_on=False, markersize=7)
		if len(params.desired_state.shape)==3:
			ax.plot(x_axis, np.squeeze(params.desired_state[i,0,:]), '-', linewidth=1.5)
		else:
			ax.plot(x_axis, np.squeeze(params.desired_state), '-', linewidth=1.5)
		# ax.legend(['Mean Controlled Trajectory', 'Actuator Centers', 'Desired profile'])	
		for j in range(params.N):
			ax.add_line(actuator_lines[j])
			# ax.fill_betweenx(y=actuator_lines[j].get_ydata(orig=False), x1=params.actuator_locs[j] - np.sqrt(params.sig_xx[j]), \
			# 				 x2= params.actuator_locs[j] + np.sqrt(params.sig_xx[j]), alpha=0.1, color='red')

		plt.ylim((lower_limit, upper_limit))
		plt.title(params.title)	
		# plt.savefig('savedir/video_data/'+str(i)+'.png')
		plt.pause(0.01)
		if i == params.mpc_steps:
			plt.savefig('savedir/plots/'+params.plot_name+'.png')

	plt.pause(1.0)
	plt.show(block=False)			

	print("plotting contour plot showing time evolution ... ")
	fig = plt.figure(dpi=params.dpi)
	ax = plt.gca()
	# Y = np.arange(params.dt, (controlled_mean_traj.shape[0])*params.dt, params.dt)
	Y = np.arange(0, (controlled_mean_traj.shape[0])*params.dt, params.dt)
	X = np.arange(0, (controlled_mean_traj.shape[1])*params.avg_spacing, params.avg_spacing)
	X, Y = np.meshgrid(X, Y)	
	# import pdb
	# pdb.set_trace()

	plt.contourf(X, Y, controlled_mean_traj, levels=200, cmap=cm.jet)
	plt.colorbar(orientation='horizontal', )
	plt.xlabel(params.xlabel)
	plt.ylabel("time in seconds")	
	plt.savefig('savedir/plots/'+params.plot_name+'_contour'+'.png')
	plt.show()