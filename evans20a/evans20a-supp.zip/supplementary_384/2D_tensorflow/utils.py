import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from scipy.fftpack import dst
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
tf_dtype = tf.float32
np_dtype = np.float32
import sys

# move this to utils
def integrate(function, values):
	# integrates the function 'function' over the discrete, monotonic, ordered values 'values' by using trapezial integration
	#spacing = values[1]-values[0] # if 'values' are equally spaced, can pick any two consecutive elements
	avg_spacing = np.absolute(values[-1] - values[0])/num(values)

	first = function(values[0])
	last = function(values[-1])

	#make sure function can accept arrays
	middle = function(values[1:-2])

	return np.float32( avg_spacing * ( first/2 + last/2 + np.sum(middle) ) )

# move this to utils
def integrate_eval(feval, values):
	# integrates the evaluated function 'feval' over the discrete, monotonic, ordered values 'values' by using trapezial integration
	# accepts feval of any shape, integration performed on last dimension
	# accepts values of shape vector
	avg_spacing = np.absolute(values[-1] - values[0])/num(values)

	first = feval[...,0]
	last = feval[...,-1]
	middle = np.array(feval[...,1:-1])

	return np.float32( avg_spacing * ( first/2 + last/2 + np.sum(middle, axis=-1) ) ) #removes last dimension while reducing during integration


def tf_integrate_eval(feval, avg_spacing):
	# integrates the evaluated function 'feval' by using trapezial integration. avg_spacing is the average spacing between function calls
	# accepts any shape, integration performed on last dimension

	first = feval[...,0]
	last = feval[...,-1]
	middle = feval[...,1:-1]

	return  avg_spacing * ( first/2 + last/2 + tf.reduce_sum(middle, axis=-1) )  #removes last dimension while reducing during integration

def tf_2D_integrate_eval(feval, avg_spacing):
	# 2D integration over a tensor with a matrix on the last two dimensions
	# accepts any shape, integration performed on the last two dimensions

	corners = feval[...,0,0] + feval[...,0,-1] + feval[...,-1,0] + feval[...,-1,-1]
	edges = 2 *( tf.reduce_sum(feval[...,0,:], axis=-1) + tf.reduce_sum(feval[...,-1,:], axis=-1) + tf.reduce_sum(feval[...,:,0], axis=-1) + tf.reduce_sum(feval[...,:,-1], axis=-1))
	center = 4 * tf.reduce_sum(feval[...,1:-1,1:-1], axis=[-1,-2])
	return 0.25 * avg_spacing**2 * (corners + edges + center)


def tf_dst(A):
	# Given noise values in A, this function generates the truncated sum of the Q-Wiener expansion
	# A should be real rank 2 tensor, function returns a real rank 2 tensor,
	# fft is occuring over the second dimension of A, broadcast over first dimension
	n, m = A.get_shape().as_list()
	A = tf.complex(A, tf.zeros((n,m), dtype=tf.float32))
	A_tf_rev = tf.reverse(-A, [0])
	y = tf.concat([tf.zeros([1,m], dtype=tf.complex64), A, tf.zeros([1,m], dtype=tf.complex64), A_tf_rev], axis=0)
	yy = tf.fft(y)
	deno = tf.complex(0.0,-2.0)
	return tf.real(yy[1:n+1,:]/deno)

def scipy_dst_1d(Xi_):
	return 0.5*dst(Xi_, type=1)

def tf_propagate_homogeneous_dirichlet_pad(A):
	l,m,n = A.get_shape().as_list() #note: m = n
	#accepts A of shape = (rollouts, J-1, J-1), returns a padded A of shape (rollouts, J+1, J+1)
	zero_col = tf.zeros((l, m, 1 ), dtype=tf_dtype)
	zero_row = tf.zeros((l, 1, m + 2 ), dtype=tf_dtype)
	return tf.concat([zero_row, tf.concat([zero_col, A, zero_col], axis=-1), zero_row], axis=-2) #shape = (rollouts, J+1, J+1)

def tf_toeplitz_overlap(A, n, stride):
	# Expects A as a mxm matrix corresponding to the filter, n corresponds to an input image shape of nxn, s is the stride
	m,q = A.get_shape().as_list() #q is a dummy, it should be equal to m
	shift = np.int32((n-m)/stride+1)

	# if n-m <= 1:
	# 	A_flat_pad = tf.expand_dims(tf.reshape(tf.concat([A, tf.zeros((m,(n-m)), dtype=tf_dtype)], axis=1), (1,-1))[0,0:-(n-m)], axis=0)
	# else:
	A_flat_pad = tf.reshape(tf.concat([A, tf.zeros((m,(n-m)), dtype=tf_dtype)], axis=1), (1,-1))[:,0:-(n-m)]

	pad_num = (n**2) - A_flat_pad.get_shape().as_list()[-1]
	toeplitz_list = []
	pre_zeros = 0
	shift_count = 0
	# down_count = 0
	for i in range(shift**2):
		if shift_count % shift == 0 and shift_count is not 0:
			# pre_zeros += m*stride-1
			# down_count += 1
			pre_zeros += m*stride-1
			# pre_zeros = n * m
			print("new row")

		toeplitz_list.append(tf.concat([tf.zeros((1,pre_zeros), dtype=tf_dtype), A_flat_pad, tf.zeros((1, pad_num - pre_zeros), dtype=tf_dtype)], axis=-1))
		pre_zeros += stride
		shift_count += 1


	return tf.concat(toeplitz_list, axis=0)

def tf_toeplitz(in_filter, image_length, stride):
	# Expects A as a mxm matrix corresponding to the filter, inage_length corresponds to an input image shape of image_length x image_length, s is the stride
	filter_length, q = in_filter.get_shape().as_list() #q is a dummy, it should be equal to m
	shift = np.int32((image_length-filter_length)/stride+1)

	filter_flat_padded = tf.reshape(tf.concat([in_filter, tf.zeros((filter_length,(image_length-filter_length)), dtype=tf_dtype)], axis=1), (1,-1))[:,0:-(image_length-filter_length)]

	pad_num = (image_length**2) - filter_flat_padded.get_shape().as_list()[-1] #number of zeros to post pad the row of the toeplitz matrix
	toeplitz_list = []
	pre_zeros = 0 #zeros before the row
	shift_count = 0 #how many horizontal shifts have occured
	down_count = 0 #how many vertical shifts have occured
	for i in range(shift**2):
		toeplitz_list.append(tf.concat([tf.zeros((1,pre_zeros), dtype=tf_dtype), filter_flat_padded, tf.zeros((1, pad_num - pre_zeros), dtype=tf_dtype)], axis=-1))
		pre_zeros += stride
		shift_count += 1

		if shift_count % shift == 0 and shift_count is not 0:
			down_count += 1
			pre_zeros = down_count * (image_length * stride)


	return tf.concat(toeplitz_list, axis=0) # shape: (shift**2, n**2)


def plot_2D_field(test_trajs, params, plot_3d=False, dpi_val=100, vmin=-0.25, num_contour_levels=150):

	mean_traj = np.mean(test_trajs, axis=1) # (T, J+1, J+1)	
	std_traj = 2*np.std(test_trajs, axis=1) # plotting 2 sigma 
	X = np.arange(0, params.a + params.avg_spacing, params.avg_spacing)
	Y = np.arange(0, params.a + params.avg_spacing, params.avg_spacing)
	X, Y = np.meshgrid(X, Y)		

	fig = plt.figure(dpi=dpi_val)
	if plot_3d:
		ax = fig.gca(projection='3d')
		for t_ in range(params.mpc_steps):
			sys.stdout.write("step: %d/%d \r" % (t_, params.mpc_steps))
			sys.stdout.flush()
			plt.cla()
			ax.plot_surface(X, Y, mean_traj[t_,:,:], cmap=cm.hot, antialiased=True)
			ax.set_zlim(-0.25, params.desired_value+0.5)
			plt.pause(0.01)
		plt.show()
	else:
		# import pdb
		# pdb.set_trace()
		vmax = params.desired_value+0.5
		for t_ in range(params.mpc_steps):
			sys.stdout.write("step: %d/%d \r" % (t_, params.mpc_steps))
			sys.stdout.flush()	
			plt.clf()
			plt.contourf(X, Y, mean_traj[t_,:,:], num_contour_levels, aspect='auto', cmap=cm.jet, vmin=vmin, vmax=vmax)
			plt.clim(vmin, vmax)		
			plt.colorbar()
			plt.pause(0.005)
		
		plt.show()		