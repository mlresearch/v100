import numpy as np
import tensorflow as tf
from utils import tf_dst
from scipy.fftpack import dst
np_dtype = np.float32
tf_dtype = tf.float32
seed = np.random.seed(1)
tfseed = tf.random.set_random_seed(1)

np.set_printoptions(linewidth=1000, precision=3)

a = 1
dt = 0.01
mpc_steps = 2
rollouts = 2
J = 5
bj = np.sqrt(2.0 * dt/a)
center_rands = tf.random.normal((mpc_steps * rollouts, J-1, J-1), seed=seed)

def scipy_dst_2d(Xi_):
	return np.transpose(0.5*dst(np.transpose(0.5*dst(Xi_, type=1)), type=1))

def scipy_dst_1d(Xi_):
	return 0.5*dst(Xi_, type=1)

def _test_for_loop(center_rands):
	# left_boundary = tf.zeros((self.params.mpc_steps, self.params.rollouts, 1), dtype=tf_dtype) # shape = (T, rollouts)
	# right_boundary = tf.zeros((self.params.mpc_steps, self.params.rollouts, 1), dtype=tf_dtype)

	temp_list = []
	# center_rands = tf.random.normal((mpc_steps * rollouts, J-1, J-1), seed=seed)

	for rt in range(mpc_steps*rollouts):
		# temp_list.append(tf.transpose(tf_dst(tf.transpose(tf_dst(center_rands[rt,:,:]), perm=[1,0])), perm=[1,0]))
		temp_list.append(tf.py_func(scipy_dst_2d, [center_rands[rt,:,:]], tf.float32))

	dW_center_rands = tf.reshape(tf.concat(temp_list, 0), (mpc_steps, rollouts, J-1, J-1))
	center_rands = tf.reshape(center_rands, (mpc_steps, rollouts, J-1, J-1))

	# Q-Wiener increments:
	dQWiener = bj * dW_center_rands #shape = (time, rollouts, (J-1)*(J-1))
	dBrownian = center_rands #shape = (time, rollouts, (J-1)*(J-1))

	return dQWiener, dBrownian


def _test_broadcast(center_rands):

	center_rands_l = tf.reshape(center_rands, (mpc_steps * rollouts * (J-1), J-1))
	temp = tf_dst(center_rands_l) #computes dst on the last axis, broadcast over the first
	temp1 = tf.reshape(tf.transpose(tf.reshape(temp, (rollouts*mpc_steps, J-1,J-1)), perm=[0,2,1]), (rollouts*mpc_steps*(J-1), J-1))
	temp2 = tf.reshape(tf_dst(temp1), (mpc_steps, rollouts, J-1, J-1 ))
	dQWiener = bj * temp2
	dBrownian = center_rands

	return dQWiener, dBrownian

def _test_broadcast_scipy_dst(center_rands):

	center_rands_l = tf.reshape(center_rands, (mpc_steps * rollouts * (J-1), J-1))
	temp = tf.py_func(scipy_dst_1d, [center_rands_l], tf.float32) #computes dst on the last axis, broadcast over the first

	temp1 = tf.reshape(tf.transpose(tf.reshape(temp, (rollouts*mpc_steps, J-1,J-1)), perm=[0,2,1]), (rollouts*mpc_steps*(J-1), J-1))
	temp2 = tf.transpose(tf.reshape(tf.py_func(scipy_dst_1d, [temp1], tf.float32), (mpc_steps, rollouts, J-1, J-1 )), perm=[0,1,3,2])
	dQWiener = bj * temp2
	dBrownian = center_rands

	return dQWiener, dBrownian


dQWiener_loop, dBrownian_loop = _test_for_loop(center_rands)
dQWiener_cast, dBrownian_cast = _test_broadcast(center_rands)
dQWiener_cast_scipy, dBrownian_cast_scipy = _test_broadcast_scipy_dst(center_rands)
difference = tf.reduce_sum(dQWiener_loop - dQWiener_cast)
sess = tf.Session()
dQWiener_loop_np, dQWiener_cast_np, difference, CRs, dQWiener_cast_sp = sess.run([dQWiener_loop, dQWiener_cast, difference, center_rands, dQWiener_cast_scipy])


# print("CRs:", CRs)
print("dQWiener resulting from loop =\n ", dQWiener_loop_np)
# print("dQWiener resulting from broadcast = ", dQWiener_cast_np)
print("dQWiener resulting from broadcast with scipy =\n ", dQWiener_cast_sp)
print("difference = ", difference)



