import numpy as np
import tensorflow as tf
import os
np_dtype = np.float32
tf_dtype = tf.float32
from time import time
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import datetime
import sys
from collections import OrderedDict

np.set_printoptions(linewidth=1000)

class MPPI(object):
	def __init__(self, params, model, policy, sess=None): #pass sess in from main file
		self.params = params
		self.model = model
		self.policy = policy
		start_time = time()
		gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.7)
		config = tf.ConfigProto(gpu_options=gpu_options)
		config.gpu_options.allow_growth = True
		
		self.export_dir = 'savedir/'+self.params.load_file_name
		# export_file = self.export_dir + '.meta'
		# self.exists = os.path.isfile(export_file)
		self._build_graph()
		if sess == None:
			self.sess = tf.Session(config=config)
		else:
			self.sess = sess
		self.saver = tf.train.Saver(max_to_keep=50)
		
		if self.params.load_check:
			print("\nBuilding graph and loading graph weights from file:", self.export_dir)
			print('\ntime to build graph = ', time()-start_time, '\n')
			#saver = tf.train.import_meta_graph(export_file)
			self.saver.restore(self.sess, self.export_dir)
			# self.sess.run(tf.initializers.global_variables())
		else:
			print('\ntime to build graph = ', time()-start_time, '\n')
			self.sess.run(tf.initializers.global_variables())
			# self.saver.save(self.sess, self.export_dir)
			# print("\nGraph Saved to",self.export_dir)

		
		#GPU OPTIONS TO LIMIT MEMORY


	def _mppi(self):

		# if self.exists:
		# 	avg_state_cost = tf.get_default_graph().get_operation_by_name("avg_state_cost")
		# 	avg_total_cost = tf.get_default_graph().get_operation_by_name("avg_total_cost")
		# 	self.learnrate = tf.get_default_graph().get_tensor_by_name("learn_rate")
		# 	for i in range(self.params.iterations):
		# 		#avg_state_cost, avg_total_cost, _ = self.sess.run([self.model.avg_state_cost, self.model.avg_total_cost, self.policy.assign_ops], feed_dict={self.learnrate: self.params.learnrate})
		# 		avg_state_cost_out, avg_total_cost_out = self.sess.run([avg_state_cost, avg_total_cost], feed_dict={self.learnrate: self.params.learnrate})
		# 		print('iteration = ', i, ', average state cost = ', avg_state_cost_out, ', average total cost = ', avg_total_cost_out)

		# else:

		avg_state_cost_list = []
		obj_func_list = []

		for i in range(self.params.iterations):
			#avg_state_cost, avg_total_cost, _ = self.sess.run([self.model.avg_state_cost, self.model.avg_total_cost, self.policy.assign_ops], feed_dict={self.learnrate: self.params.learnrate})

			_, avg_state_cost, avg_total_cost, obj_func_val, avg_noise_prod, avg_time_prod, all_Ws, reg_loss, traj_costs = self.sess.run([self.min_op,\
																		  self.model.avg_state_cost, \
																		  self.model.avg_total_cost, \
																		  self.model.objective_function, \
																		  self.model.avg_noise_prod_cost, 
																		  self.model.avg_time_prod_cost,\
																		  self.model.all_weights,\
																		  self.reg_losses,\
																		  self.model.all_traj_costs], \
											feed_dict={self.learnrate: self.params.learnrate})

			if (i+1) % 100 == 0:
				print("saving checkpoint")
				self.saver.save(self.sess, self.export_dir+"_iter_"+str(i+1))
			elif (i+1) % 500 == 0:
				self.params.learnrate = 0.5 * self.params.learnrate	

			print('iter = ', i, ', Costs: state = ', avg_state_cost, ', total = ', avg_total_cost, \
				', obj.func. = ', obj_func_val, ', avg w = ', np.mean(all_Ws), ', max w = ', np.amax(all_Ws), \
				', min w = ', np.amin(all_Ws), ', lr:', self.params.learnrate )

			avg_state_cost_list.append(avg_state_cost)
			obj_func_list.append(obj_func_val)

		# print("Done with training!... saving weights")
		# self.saver.save(self.sess, self.export_dir)

		# print("testing ... ")
		# test_trajs = self.sess.run(self.model.test_h_traj) # shape is (T, rollouts, J+1, J+1)	
		# now = datetime.datetime.now()
		# np.savez('savedir/test_data/'+str(now.isoformat())+'.npz', trajs=test_trajs)

		# mean_traj = np.mean(test_trajs, axis=1) # (T, J+1, J+1)	
		# std_traj = 2*np.std(test_trajs, axis=1) # plotting 2 sigma 
		# X = np.arange(0, self.params.a + self.params.avg_spacing, self.params.avg_spacing)
		# Y = np.arange(0, self.params.a + self.params.avg_spacing, self.params.avg_spacing)
		# X, Y = np.meshgrid(X, Y)		

		# import pdb
		# pdb.set_trace()

		# input("watch video?")
		# image_width = 5
		# image_height = 5
		# dpi_val = 300
		# height_pixels = image_height*dpi_val
		# width_pixels = image_width*dpi_val		
		# fig = plt.figure(figsize=(image_height, image_width), dpi=dpi_val)
		# ax = fig.gca(projection='3d')
		# for t_ in range(self.params.mpc_steps):
		# 	sys.stdout.write("step: %d/%d \r" % (t_, self.params.mpc_steps))
		# 	sys.stdout.flush()
		# 	plt.cla()
		# 	ax.plot_surface(X, Y, mean_traj[t_,:,:], cmap=cm.hot, antialiased=True)
		# 	ax.set_zlim(-0.25, self.params.desired_value+0.5)
		# 	plt.pause(0.01)
		# plt.show()

		self.sess.close()
		return np.asarray(avg_state_cost_list), np.asarray(obj_func_list)


	def _build_graph(self):

		self.learnrate = tf.placeholder(dtype=tf_dtype, shape=(), name="learn_rate")
		# perform one episode of RL
		self.model._generate_rollouts(self.policy) #this function will do everything through averaging
		print("\nBuilding gradients compuations through AdamOptimizer...")
		opt = tf.train.AdamOptimizer(learning_rate=self.learnrate)
		# self.reg_losses = tf.reduce_sum(tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES))

		weigth_decay_param = self.params.l2_scale
		norm_list = []
		total_num_params = 0
		nparams_dict = OrderedDict()

		for var in tf.trainable_variables():
			#L2 regularization
			norm_list.append(tf.nn.l2_loss(var)) 

			#Printing variables
			var_shape = var.get_shape().as_list()
			curr_params = 1
			for i in var_shape:
				curr_params *= i
			# assert curr_params == functools.reduce(lambda x, y: x*y, var_shape)
			nparams_dict[var.name] = "size %s = %s"%(str(var_shape), ("{:,}".format(curr_params)))
			total_num_params += curr_params
			print("Variable: %s - size %s = %s" % \
				(var.name, str(var_shape), ("{:,}".format(curr_params))))

		# L2 regularization
		self.reg_losses = weigth_decay_param * tf.reduce_sum(tf.stack(norm_list), keepdims=False)

		print("\nTotal num of params: %s" % ("{:,}".format(total_num_params)))
		# print("Constructing a network with " % ("{:,}".format(total_num_params)) + " parameters")

		# create operation for minimization through AdamOptimizer
		print("\nBuilding minimize operation...")
		self.min_op = opt.minimize(self.model.objective_function + self.reg_losses)

		# Create test graph:
		self.model._test_policy(self.policy) #this function will do everything through averaging
		










