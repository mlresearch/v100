import numpy as np
import tensorflow as tf
from scipy.sparse import spdiags, identity, csc_matrix, csr_matrix, hstack, vstack, dia_matrix
from scipy.sparse.linalg import inv
from utils import tf_2D_integrate_eval, tf_dst, tf_propagate_homogeneous_dirichlet_pad, scipy_dst_1d
from abc import ABC, abstractmethod

np_dtype = np.float32
tf_dtype = tf.float32

class Model2DBase(ABC):
	def __init__(self, params):
		self.params = params
		self.m_vector = self._small_m_eval()
		self.M_tensor = self.compute_capital_M_eval()
		
	def _test_policy(self, policy):
		h_t = []
		h_0_reshape = tf.reshape(self.params.h_0[:,1:-1,1:-1], (self.params.rollouts, (self.params.J-1)**2))
		h_t.append(h_0_reshape)

		self._sample_noise()

		# Forward pass
		print("\nBuilding dynamics propagation for test...")
		for t in range(self.params.mpc_steps):
			h_t.append(self._propagate(h_t[-1], policy, self.dQWiener[t,:,1:-1,1:-1]))

		h_traj = tf.reshape(tf.stack(h_t[1:], axis=0), (self.params.mpc_steps, self.params.rollouts, self.params.J-1, self.params.J-1))
		zero_col = tf.zeros((self.params.mpc_steps, self.params.rollouts, self.params.J-1, 1 ), dtype=tf_dtype)
		zero_row = tf.zeros((self.params.mpc_steps, self.params.rollouts, 1, self.params.J+1 ), dtype=tf_dtype)
		self.test_h_traj = tf.concat([zero_row, tf.concat([zero_col, h_traj, zero_col], axis=-1), zero_row], axis=-2) #shape = (T, rollouts, J+1, J+1)	

	def _simulate_dynamics(self):
		
		h_t = []
		h0_reshape = tf.reshape(self.params.h_0[:,1:-1,1:-1], (self.params.rollouts, (self.params.J-1)**2))
		h_t.append(h0_reshape)

		# expected to return cost and gradients
		self._sample_noise()

		# Forward pass
		print("\nBuilding dynamics propagation...")
		for t in range(self.params.mpc_steps):
			h_t.append(self._simulate(h_t[-1], self.dQWiener[t,:,1:-1,1:-1]))

		h_traj = tf.reshape(tf.stack(h_t[1:], axis=0), (self.params.mpc_steps, self.params.rollouts, self.params.J-1, self.params.J-1))
		zero_col = tf.zeros((self.params.mpc_steps, self.params.rollouts, self.params.J-1, 1 ), dtype=tf_dtype)
		zero_row = tf.zeros((self.params.mpc_steps, self.params.rollouts, 1, self.params.J+1 ), dtype=tf_dtype)
		self.sim_traj = tf.concat([zero_row, tf.concat([zero_col, h_traj, zero_col], axis=-1), zero_row], axis=-2) #shape = (T, rollouts, J+1, J+1)

	def _generate_rollouts(self, policy):
		
		h_t = []
		h_0_reshape = tf.reshape(self.params.h_0[:,1:-1,1:-1], (self.params.rollouts, (self.params.J-1)**2))
		h_t.append(h_0_reshape)

		# expected to return cost and gradients
		self._sample_noise()

		# Forward pass
		print("\nBuilding dynamics propagation...")
		for t in range(self.params.mpc_steps):
			h_t.append(self._propagate(h_t[-1], policy, self.dQWiener[t,:,1:-1,1:-1]))

		h_traj = tf.reshape(tf.stack(h_t[1:], axis=0), (self.params.mpc_steps, self.params.rollouts, self.params.J-1, self.params.J-1))
		zero_col = tf.zeros((self.params.mpc_steps, self.params.rollouts, self.params.J-1, 1 ), dtype=tf_dtype)
		zero_row = tf.zeros((self.params.mpc_steps, self.params.rollouts, 1, self.params.J+1 ), dtype=tf_dtype)
		h_traj = tf.concat([zero_row, tf.concat([zero_col, h_traj, zero_col], axis=-1), zero_row], axis=-2) #shape = (T, rollouts, J+1, J+1)


		# Compute costs
		print("\nBuilding cost computations...")
		self.state_cost = self._state_cost(h_traj)

		policy_list = []
		for t in range(self.params.mpc_steps):
			policy_list.append( policy._policy_eval(h_traj[t,...]))
		policy_eval = tf.stack(policy_list, axis=0) #shape = (T, rollouts, (J+1), (J+1), N)
		# print("\nBuilding policy evaluation loops...")
		# policy_eval = self._policy_loop(h_traj, policy)

		print("\nBuilding stochastic integral term computation...")
		self.noise_inner_product_cost = self._noise_inner_product(h_traj, policy_eval)
		print("\nBuilding time integral term computation...")
		self.time_inner_product_cost = self._time_inner_product(h_traj, policy_eval)
		self.total_cost = self.state_cost + 1/tf.sqrt(self.params.rho) * self.noise_inner_product_cost + 0.5 * self.time_inner_product_cost

		# Compute importance sampling weights
		print("\nBuilding weights computation...")
		weights = self._averaging(self.total_cost)

		# Compute objective function to be used as loss
		print("\nBuilding objective function computation...")
		self.objective_function = tf.reduce_sum(weights * (- tf.sqrt(self.params.rho) * self.noise_inner_product_cost -  0.5 * self.params.rho * self.time_inner_product_cost), axis=0)
		# self.deltaW = -tf.sqrt(self.params.rho) * tf.reduce_sum(weights * self._noise_grad_inner_product(h_traj, policy), axis=0, keepdims=True) \
		# 				+ self.params.rho * tf.reduce_sum(weights * self._time_grad_inner_product(h_traj, policy), axis=0, keepdims=True)
		print("\nBuilding average costs computation...")
		self.avg_state_cost = tf.reduce_mean(self.state_cost, name='avg_state_cost')
		self.avg_total_cost = tf.reduce_mean(self.total_cost, name='avg_total_cost')

		# for debugging:
		self.avg_im_weights = tf.reduce_mean(weights)
		self.avg_noise_prod_cost = tf.reduce_mean(self.noise_inner_product_cost)
		self.avg_time_prod_cost = tf.reduce_mean(self.time_inner_product_cost)
		self.all_weights = weights
		self.all_traj_costs = self.total_cost

	@abstractmethod
	def _propagate(self, h, policy, dQWiener):
		pass

	def _simulate(self, h, dQWiener):
		pass

	@abstractmethod
	def _generate_prop_matrix(self):
		pass

	def _averaging(self, costvec):
		min_cost = tf.math.reduce_min(costvec)
		# costvec = costvec - min_cost
		cost = tf.exp(-self.params.rho * costvec)
		return cost/(tf.reduce_sum(cost)+1e-5)

	def _policy_loop(self, h_traj, policy):
		#this function will create time and space for loops to push through the policy network
		# expects h_traj of shape = (T, rollouts, J+1, J+1)
		# output should be of shape = (T, rollouts, J+1, J+1, N)

		h_traj_flat = tf.reshape(h_traj, (self.params.mpc_steps, self.params.rollouts, (self.params.J+1)**2))
		# zero = np.zeros((self.params.rollouts,(self.params.J+1)**2) )
		
		time = []

		for t in range(self.params.mpc_steps):
			space = []
			for j in range((self.params.J+1)**2):
				paddings = tf.constant([[0,0],[j, (self.params.J+1)**2-j-1]])
				temp = tf.reshape(tf.pad(tf.expand_dims(h_traj_flat[t,:,j], axis=-1), paddings), (self.params.rollouts, self.params.J+1, self.params.J+1)) #shape = (rollouts, J+1, J+1)
				space.append( policy._policy_forward_pass(temp) ) #shape = [j](rollouts, N)
			time.append(tf.reshape(tf.stack(space, axis=1), (self.params.rollouts, self.params.J+1, self.params.J+1, self.params.N))) #shape = [T](rollouts, J+1, J+1, N)

		return tf.stack(time, axis=0) #shape = (T, rollouts, J+1, J+1, N)


	#Modified for 2D
	def _small_m_fcn(self,x,y,n):
		temp_x = np.exp( -0.5 * ((x-self.params.actuator_x_locs[n])**2)/self.params.actuator_variance_xx[n])
		temp_y = np.exp( -0.5 * ((y-self.params.actuator_y_locs[n])**2)/self.params.actuator_variance_yy[n])
		return temp_x*temp_y

	#Modified for 2D
	def _small_m_eval(self):
		#small m evaluated over space and control dimension
		m_vector = np.zeros((self.params.N, self.params.J+1, self.params.J+1), dtype=np_dtype)
		for n in range(self.params.N):
			for i in range(1, self.params.J): # start from second index, go to one from the end so that we cannot control the boundary 
				x = i*self.params.avg_spacing
				for j in range(1, self.params.J):
					y = j*self.params.avg_spacing
					m_vector[n,i,j] = self._small_m_fcn(x,y,n)

		return tf.constant(m_vector) #shape = (N, (J+1)^2)

	#Modified for 2D
	def _sample_noise(self):

		# make zeros because there is no noise at the boundary
		left_boundary = tf.zeros((self.params.mpc_steps, self.params.rollouts, self.params.J-1, 1), dtype=tf_dtype) # shape = (T, rollouts, J-1, 1)
		right_boundary = tf.zeros((self.params.mpc_steps, self.params.rollouts, self.params.J-1, 1), dtype=tf_dtype)
		top_boundary = tf.zeros((self.params.mpc_steps, self.params.rollouts, 1, self.params.J+1), dtype=tf_dtype)
		bottom_boundary = tf.zeros((self.params.mpc_steps, self.params.rollouts, 1, self.params.J+1), dtype=tf_dtype)

		# perform dst on the noise. dst operates on columns, broadcast on rows, so we need to shuffle dimensions around accordingly
		center_rands = tf.random.normal((self.params.mpc_steps * self.params.rollouts * (self.params.J-1), self.params.J-1), seed=self.params.random_seed)
		
		# With tf_dst (DOESN'T WORK!!!):
		# temp = tf.reshape(tf.transpose(tf.reshape(tf_dst(center_rands), (self.params.rollouts*self.params.mpc_steps, self.params.J-1,self.params.J-1)), perm=[0,2,1]), \
		# 										 (self.params.rollouts*self.params.mpc_steps*(self.params.J-1), self.params.J-1))
		# dW_center_rands = tf.reshape(tf_dst(temp), (self.params.mpc_steps, self.params.rollouts, self.params.J-1, self.params.J-1))

		# With scipy dst:
		temp = tf.py_func(scipy_dst_1d, [center_rands], tf_dtype)
		temp1 = tf.reshape(tf.transpose(tf.reshape(temp, (self.params.rollouts*self.params.mpc_steps, self.params.J-1, self.params.J-1)), perm=[0,2,1]), \
										(self.params.rollouts*self.params.mpc_steps*(self.params.J-1), self.params.J-1))
		dW_center_rands = tf.transpose(tf.reshape(tf.py_func(scipy_dst_1d, [temp1], tf_dtype), (self.params.mpc_steps, self.params.rollouts, self.params.J-1, self.params.J-1 )), perm=[0,1,3,2])

		# Q-Wiener increments:
		self.dQWiener = self.params.bj * tf.concat(values=[top_boundary, tf.concat(values=[left_boundary, dW_center_rands, right_boundary], axis=-1), bottom_boundary], axis=-2) #shape = (time, rollouts, J+1, J+1)

	# #Modified for 2D
	# def _noise_basis_fcn(self, i, j, k, l):
	# 	return self.params.bj * np.sin( (i*np.pi/self.params.J) * j*self.params.a ) * np.sin( (k*np.pi/self.params.J) * l*self.params.a )

	# #Modified for 2D
	# def _noise_basis_fcn_eval(self):
	# 	noise_mat = np.zeros((self.params.J+1, self.params.J+1, self.params.J+1, self.params.J+1))
	# 	for i in range(self.params.J+1):
	# 		for j in range(self.params.J+1):
	# 			for k in range(self.params.J+1):
	# 				for l in range(self.params.J+1):
	# 					noise_mat[i,j,k,l] = self._noise_basis_fcn(i,j,k,l)

	# 	return tf.constant(noise_mat, dtype=tf_dtype) #shape = (J+1, J+1)

	#Modified for 2D
	def compute_capital_M(self, x, y):
		M = np.zeros((self.params.N,self.params.N), dtype=np_dtype)

		for i in range(self.params.N):
			for j in range(self.params.N):
				M[i,j] = self._small_m_fcn(x,y,i) * self._small_m_fcn(x,y,j) 

		return M

	#Modified for 2D
	def compute_capital_M_eval(self):
		M_tensor = np.zeros((self.params.J+1, self.params.J+1, self.params.N, self.params.N), dtype=np_dtype)
		for i in range(self.params.J+1):
			x = i*self.params.a/self.params.J
			for j in range(self.params.J+1):
				y = j*self.params.a/self.params.J
				M_tensor[i,j,:,:] = self.compute_capital_M(x,y)

		return tf.constant(M_tensor, dtype=tf_dtype) #shape= (J+1, J+1, N, N)

	#Modified for 2D
	def _time_inner_product(self, h_traj, policy_eval_tensor):
		#integrate temporally the inner product (spatial integral) of the policy and itself
		#h_traj should be shape = (T, rollouts, J+1, J+1)
		# policy_eval should be shape = (rollouts, (J+1), (J+1), N)
		inner_product_sum = []#tf.zeros((self.params.rollouts), dtype=np_dtype)
		M_expand = tf.multiply(tf.ones((self.params.rollouts, self.params.J+1, self.params.J+1, self.params.N, self.params.N), dtype=tf_dtype), self.M_tensor) #shape = (rollouts, (J+1), (J+1), N, N)

		for t in range(self.params.mpc_steps):
			policy_eval1 = tf.expand_dims(policy_eval_tensor[t,...], axis=-2) #shape = (rollouts, (J+1), (J+1), 1, N)
			policy_eval2 = tf.expand_dims(policy_eval_tensor[t,...], axis=-1) #shape = (rollouts, J+1, J+1, N, 1)
			inner_product = tf.matmul(tf.matmul(policy_eval1, M_expand), policy_eval2) # shape = (rollouts, (J+1), (J+1), 1, 1)
			inner_product_sum.append( tf_2D_integrate_eval( tf.squeeze(inner_product), self.params.avg_spacing) * self.params.dt) #shape = rollouts

		return tf.squeeze(tf.math.add_n(inner_product_sum)) #shape = (rollouts)

	#Modified for 2D
	def _noise_inner_product(self, h_traj, policy_eval_tensor):
		#dQWiener is of shape = (time, rollouts, J+1, J+1)
		#m_vector is of shape = (N, J+1, J+1)
		inner_product_time_sum = []
		small_m_expand = tf.expand_dims(tf.multiply(tf.ones((self.params.rollouts, self.params.J+1, self.params.J+1, self.params.N), dtype=tf_dtype), \
										tf.transpose(self.m_vector, perm=[1,2,0])), axis=-1) #shape=(rollouts, (J+1), (J+1), N, 1)


		for t in range(self.params.mpc_steps):
			policy_eval = tf.expand_dims(policy_eval_tensor[t,...], axis=-2) #shape = (rollouts, (J+1), (J+1), 1, N)
			phi_m = tf.squeeze(tf.matmul(policy_eval, small_m_expand)) #shape = (rollouts, J+1, J+1)
			inner_product_time_sum.append( tf_2D_integrate_eval(phi_m * self.dQWiener[t,:,:,:], self.params.avg_spacing) * self.params.dt) #shape = [T](rollouts)

		return tf.squeeze(tf.math.add_n(inner_product_time_sum)) # shape = (rollouts)

	#Modified for 2D
	def _state_cost(self, h_traj):
		# desired state should be of shape = ((J+1), (J+1))
		# h_traj should be of shape = (T, rollouts, (J+1)*(J+1))

		actual_list = []

		desired_state_mat_expand = tf.ones((self.params.mpc_steps, self.params.rollouts, self.params.num_desired_regions * self.params.desired_region_length, self.params.desired_region_length), dtype=tf_dtype) * self.params.desired_state_mat #shape = (T, rollouts, region_length*num_regions, region_length)

		for j in range(len(self.params.range_start_x)):
			actual_list.append(h_traj[..., self.params.range_start_x[j]:self.params.range_end_x[j]+1, self.params.range_start_y[j]:self.params.range_end_y[j]+1])

		actual_tensor = tf.concat(actual_list, axis=2)
		cost_sq = self.params.Q * tf.square(desired_state_mat_expand - actual_tensor) #shape = (T, rollouts, xxx, xxx)
		return tf.reduce_sum(cost_sq, axis=[0,2,3]) #shape = (rollouts) 


class Heat2D(Model2DBase):
	def __init__(self, params):
		super().__init__(params)
		self.prop_matrix = self._generate_prop_matrix()

	def _propagate(self, h, policy, dQWiener):
		# h is of shape = (rollouts, (J-1)^2)
		# m_vector is of shape (N, J+1, J+1)
		# policy is a Policy object
		# dQWiener should have shape = (rollouts, J+1, J+1)
		h_pad = tf_propagate_homogeneous_dirichlet_pad(tf.reshape(h, (self.params.rollouts, self.params.J-1, self.params.J-1))) #shape = (rollouts, J+1, J+1)
		dQWiener_reshape = tf.reshape(dQWiener, (self.params.rollouts, (self.params.J-1)**2))
		u = tf.expand_dims(policy._policy_forward_pass(h_pad), axis=-1) #shape = (rollouts, N, 1)
		mvec = tf.transpose(tf.multiply(tf.ones((self.params.rollouts, self.params.N, self.params.J+1, self.params.J+1)), tf.expand_dims(self.m_vector, axis=0)), perm=[0,2,3,1]) #shape = (rolloutsm, J+1, J+1, N)
		mvec = tf.reshape(mvec[:,1:-1,1:-1,:], (self.params.rollouts, (self.params.J-1)**2, self.params.N)) #shape = (rollouts, (J-1)^2, N)
		applied_control = tf.squeeze(tf.matmul(mvec, u)) #shape = (rollouts, (J-1)^2)
		h_new = tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h + applied_control * self.params.dt + 1.0/tf.sqrt(self.params.rho) * dQWiener_reshape)))
		# h_new = tf.matmul(tf.sparse_tensor_to_dense(EE_inv_tensor_cpu), h_n + dW_n, a_is_sparse=True)
		return h_new

	def _simulate(self, h, dQWiener):
		dQWiener_reshape = tf.reshape(dQWiener, (self.params.rollouts, (self.params.J-1)**2))
		return tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h + 1.0/tf.sqrt(self.params.rho) * dQWiener_reshape)))

	def _generate_prop_matrix(self):

		diag_data = np.ones(((self.params.J-1)**2, 1), dtype=np.float32)
		data = np.squeeze(np.asarray([-diag_data, -diag_data,  4*diag_data, -diag_data, -diag_data]))
		diagonals = np.asarray([-(self.params.J-1), -1, 0, 1, self.params.J-1])
		sp_A = (self.params.dt*self.params.epsilon/self.params.avg_spacing**2) * spdiags(data, diagonals, (self.params.J-1)**2, (self.params.J-1)**2).toarray() #(J+1)^2 x (J+1)^2 sparse matrix with 'data' placed on diagonals specified by 'diagonals'
		for i in range(1,self.params.J-1):
			sp_A[ i*(self.params.J-1), i*(self.params.J-1)-1 ] = 0
			sp_A[ i*(self.params.J-1)-1, i*(self.params.J-1) ] = 0

		sp_I = identity((self.params.J-1)**2, format='csc', dtype=np_dtype)
		prop_matrix = sp_I + csc_matrix(sp_A)
		prop_matrix_inv = inv(prop_matrix)

		# add boundaries
		prop_matrix_inv_coo = prop_matrix_inv.tocoo() #convert to [ijv] format

		indices = np.mat([prop_matrix_inv_coo.row, prop_matrix_inv_coo.col]).transpose() #this returns a matrix of shape = (2, num_values), but we transpose because tf.SparseTensor needs (num_values, n_dims)
		return tf.sparse_reorder(tf.SparseTensor(indices=indices, values=prop_matrix_inv_coo.data, dense_shape=prop_matrix_inv_coo.shape))


# class Burgers2D(Model2DBase):
# 	def __init__(self, params):
# 		super().__init__(params)
# 		self.prop_matrix = self._generate_prop_matrix() # shape: (J-1)x(J-1)
# 		print("Burgers 1D")

# 	def _propagate(self, h, policy, dQWiener):
# 		# h is of shape = (rollouts, J+1)
# 		# policy is a Policy object
# 		# dQWiener should have shape = (rollouts, J+1)

# 		# First propagate the points inside the boundary and then add boundary values:
# 		u = tf.expand_dims(policy._policy_forward_pass(h), axis=-1) #shape = (rollouts, N, 1)
# 		mvec = tf.transpose(tf.multiply(tf.ones((self.params.rollouts, self.params.N, self.params.J+1)), tf.expand_dims(self.m_vector, axis=0)), perm=[0,2,1]) #shape = (rollouts, J+1, N)
# 		applied_control = tf.squeeze(tf.matmul(mvec, u)) #shape = (rollouts, J+1) after squeeze

# 		# Add boundary effect(not included in sparse matrix as it is only (J-1)x(J-1)):
# 		x_0 = tf.ones((self.params.rollouts, 1), dtype=tf_dtype) * self.params.bc1
# 		x_a = tf.ones((self.params.rollouts, 1), dtype=tf_dtype) * self.params.bc2 
# 		x_middle = tf.zeros((self.params.rollouts, (self.params.J-3)), dtype=tf_dtype)		

# 		boundary_effect = (self.params.dt*self.params.epsilon/self.params.avg_spacing**2) * tf.concat([x_0, x_middle, x_a], axis=-1) # shape:(rollouts, J-1)

# 		h_new = tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h[:,1:-1] - self._nonlinear_term(h) + applied_control[:, 1:-1] * self.params.dt \
# 																			+ boundary_effect + 1.0/tf.sqrt(self.params.rho) * dQWiener[:, 1:-1]))) # shape:(rollouts, J-1)

# 		return tf.concat([x_0, h_new, x_a], axis=-1) # shape:(rollouts, J-1)

# 	def _simulate(self, h, dQWiener):
# 		# Add boundary effect(not included in sparse matrix as it is only (J-1)x(J-1)):
# 		x_0 = tf.ones((self.params.rollouts, 1), dtype=tf_dtype) * self.params.bc1
# 		x_a = tf.ones((self.params.rollouts, 1), dtype=tf_dtype) * self.params.bc2 
# 		x_middle = tf.zeros((self.params.rollouts, (self.params.J-3)), dtype=tf_dtype)		

# 		boundary_effect = (self.params.dt*self.params.epsilon/self.params.avg_spacing**2) * tf.concat([x_0, x_middle, x_a], axis=-1) # shape:(rollouts, J-1)

# 		h_new = tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h[:,1:-1] - self._nonlinear_term(h) \
# 																			+ boundary_effect + 1.0/tf.sqrt(self.params.rho) * dQWiener[:, 1:-1]))) # shape:(rollouts, J-1)

# 		return tf.concat([x_0, h_new, x_a], axis=-1) # shape:(rollouts, J-1)


# 	def _nonlinear_term(self, h):
# 		# h is of shape = (rollouts, J+1) 
# 		# boundary conditions are included in h 
# 		temp = h[:,1:-1] * 0.5 * (self.params.dt/self.params.avg_spacing) * (h[:, 2:] - h[:, 0:-2]) # 0.5 for central difference for spatial derivative
# 		return temp # shape:(rollouts, J-1)

# 	def _generate_prop_matrix(self):

# 		diag_data = np.ones((self.params.J-1,1), dtype=np.float32)
# 		data = np.squeeze(np.asarray([-diag_data,  2*diag_data, -diag_data]))
# 		diagonals = np.asarray([-1, 0, 1])
# 		sp_A = (self.params.dt*self.params.epsilon/self.params.avg_spacing**2) * spdiags(data, diagonals, self.params.J-1, self.params.J-1) #J+1 x J+1 sparse matrix with 'data' placed on diagonals specified by 'diagonals'
# 		sp_I = identity((self.params.J-1), format='dia', dtype=np_dtype)
# 		prop_matrix = csr_matrix(sp_I + sp_A)
# 		prop_matrix_inv = inv(prop_matrix)
# 		prop_matrix_inv_coo = prop_matrix_inv.tocoo() #convert to [ijv] format
# 		indices = np.mat([prop_matrix_inv_coo.row, prop_matrix_inv_coo.col]).transpose() #this returns a matrix of shape = (2, num_values), but we transpose because tf.SparseTensor needs (num_values, n_dims)
# 		return tf.sparse_reorder(tf.SparseTensor(indices=indices, values=prop_matrix_inv_coo.data, dense_shape=prop_matrix_inv_coo.shape)) # shape: (J-1)x(J-1)



# class Nagumo2D(Model2DBase):
# 	def __init__(self, params):
# 		super().__init__(params)
# 		self.prop_matrix = self._generate_prop_matrix()

# 	def _propagate(self, h, policy, dQWiener):
# 		# h is of shape = (rollouts, J+1)
# 		# policy is a Policy object
# 		# dQWiener should have shape = (rollouts, J+1)
# 		u = tf.expand_dims(policy._policy_forward_pass(h), axis=-1) #shape = (rollouts, N, 1)
# 		mvec = tf.transpose(tf.multiply(tf.ones((self.params.rollouts, self.params.N, self.params.J+1)), tf.expand_dims(self.m_vector, axis=0)), perm=[0,2,1]) #shape = (rollouts, J+1, N)
# 		applied_control = tf.squeeze(tf.matmul(mvec, u))
# 		h_new = tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h + self._nonlinear_term(h) + applied_control * self.params.dt + 1.0/tf.sqrt(self.params.rho) * dQWiener)))
# 		# h_new = tf.matmul(tf.sparse_tensor_to_dense(EE_inv_tensor_cpu), h_n + dW_n, a_is_sparse=True)
# 		return h_new

# 	def _simulate(self, h, dQWiener):
# 		return tf.transpose(tf.sparse_tensor_dense_matmul(self.prop_matrix, tf.transpose(h + self._nonlinear_term(h) + 1.0/tf.sqrt(self.params.rho) * dQWiener)))


# 	def _nonlinear_term(self, h):
# 		# h is of shape = (rollouts, J+1) 
# 		# boundary conditions are included in h 
# 		return h * (1 - h) * (h - self.params.wave_speed) * self.params.dt

# 	def _generate_prop_matrix(self):

# 		diag_data = np.ones((self.params.J+1,1), dtype=np_dtype)
# 		data = np.squeeze(np.asarray([-diag_data,  2*diag_data, -diag_data]))
# 		data[0,-2] = -2 #subdiagonal
# 		data[-1,1] = -2 #superdiagonal
# 		diagonals = np.asarray([-1, 0, 1])
# 		sp_A = (self.params.dt*self.params.epsilon/self.params.avg_spacing**2) * spdiags(data, diagonals, self.params.J+1, self.params.J+1) #J+1 x J+1 sparse matrix with 'data' placed on diagonals specified by 'diagonals'
# 		sp_I = identity((self.params.J+1), format='dia', dtype=np_dtype)
# 		prop_matrix = csc_matrix(sp_I + sp_A)
# 		prop_matrix_inv = inv(prop_matrix)

# 		# # add boundaries
# 		# np_zeros_vec = np.zeros((self.params.J-1,1), dtype=np_dtype)
# 		# np_zeros_vec[0,0] = -1.0
# 		# left_col = csc_matrix(np_zeros_vec)
# 		# np_zeros_vec[0,0], np_zeros_vec[-1,0] = 0.0, -1.0
# 		# right_col = csc_matrix(np_zeros_vec)

# 		# zero_row = csc_matrix(np.zeros((1,self.params.J+1), dtype=np_dtype))
# 		# prop_matrix_inv = vstack([zero_row, hstack([left_col, prop_matrix_inv, right_col]), zero_row]) #dynamics are zero at boundaries
# 		prop_matrix_inv_coo = prop_matrix_inv.tocoo() #convert to [ijv] format

# 		indices = np.mat([prop_matrix_inv_coo.row, prop_matrix_inv_coo.col]).transpose() #this returns a matrix of shape = (2, num_values), but we transpose because tf.SparseTensor needs (num_values, n_dims)
# 		return tf.sparse_reorder(tf.SparseTensor(indices=indices, values=prop_matrix_inv_coo.data, dense_shape=prop_matrix_inv_coo.shape))
