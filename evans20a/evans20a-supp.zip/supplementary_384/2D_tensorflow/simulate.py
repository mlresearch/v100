import numpy as np
import tensorflow as tf
import os
np_dtype = np.float32
tf_dtype = tf.float32
from time import time
import matplotlib.pyplot as plt
import datetime
import sys
from utils import *

np.set_printoptions(linewidth=1000, precision=2)

class Simulate(object):
	def __init__(self, params, model):
		self.params = params
		self.model = model
		self._build_graph()
		self.sess = tf.Session()

	def _simulate(self):

		test_trajs, noise_trajs = self.sess.run([self.model.sim_traj, self.model.dQWiener])
		print(test_trajs.shape)
		plot_2D_field(test_trajs, self.params, plot_3d=False, image_width=5, image_height=7, dpi_val=300)
		print(noise_trajs[0,0,:,:], "\n")
		print(noise_trajs[-1,0,:,:], "\n")
		print(noise_trajs[20,0,:,:], "\n")

		# print(noise_trajs[0,-1,:,:], "\n")
		# print(noise_trajs[-1,-1,:,:], "\n")
		# print(noise_trajs[20,-1,:,:], "\n")

	def _build_graph(self):
		self.model._simulate_dynamics()




