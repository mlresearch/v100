import tensorflow as tf
from utils import *
from scipy.sparse import identity, csc_matrix

tf_dtype = tf.float32


class Policy_convolutional(object):
	def __init__(self, params):

		# print("\nBuilding a basic CNN policy with relu and without bias")
		print("\nBuilding a basic CNN policy with relu")
		self.params = params
		self.weight_initializer = tf.contrib.layers.xavier_initializer(dtype=tf_dtype, seed=self.params.tf_random_seed)
		self.weight_regularizer = None
		self.eye = tf.eye((self.params.J+1)**2, dtype=tf_dtype, batch_shape=[self.params.rollouts])

		self.W_out = tf.get_variable(name="W_output", shape=[int((self.params.J+1)**2/4) * self.params.num_filters[0], self.params.N], \
									 dtype=tf_dtype, initializer=self.weight_initializer, regularizer=self.weight_regularizer) 
		self.b_out = tf.get_variable(name="b_output", shape=[self.params.N], dtype=tf_dtype, initializer=self.weight_initializer, regularizer=self.weight_regularizer)

	def _policy_forward_pass(self,h):
		# accepts h as shape = (rollouts * (J+1), (J+1)) or shape = (rollouts, J+1), returns shape = (rollouts * (J+1), N)
		output1 = self._conv_operation(in_tensor=tf.expand_dims(h, -1), num_filters=self.params.num_filters[0], \
			                           kernel_size=(self.params.kernel_size[0],self.params.kernel_size[0]), \
			                           stride=(self.params.stride[0],self.params.stride[0]), name="conv1")
		output2 = self.params.activation(output1)
		output3 = tf.nn.max_pool(output2, (1,2,2,1), (1,2,2,1), padding='SAME', name="pool1")
		flat = tf.reshape(output3, (-1, int((self.params.J+1)**2/4) * self.params.num_filters[0]))
		# return tf.matmul(flat,self.W_out) # shape = (rollouts, N)
		return tf.matmul(flat,self.W_out) + self.b_out #shape = (rollouts, 5)

	def _conv_operation(self, in_tensor, num_filters, kernel_size, name, stride=1):
		return tf.layers.conv2d(in_tensor, 
								num_filters, 
								kernel_size=kernel_size,
								strides=stride, 
								padding='same', 
								name=name,
								# use_bias=False, 
								use_bias=True,
								reuse=tf.AUTO_REUSE,
								kernel_initializer=self.weight_initializer,
								kernel_regularizer=tf.contrib.layers.l2_regularizer(self.params.l2_scale),
								bias_initializer=self.weight_initializer,
								bias_regularizer=tf.contrib.layers.l2_regularizer(self.params.l2_scale))


	def _policy_eval(self,h):
		# This function takes input h, and returns a (rollouts, J+1, N) tensor resulting from running input's elements as eigenvalues of the spatial basis
		#h input should be shape=(rollouts x J)
		#policy_tensor = tf.zeros((self.params.rollouts, self.params.J+1, self.params.N), dtype=tf_dtype)
		feed_out = self._policy_forward_pass(tf.reshape(tf.multiply(self.eye, tf.expand_dims(tf.reshape(h, (self.params.rollouts, (self.params.J+1)**2)), axis=-1)), \
														(self.params.rollouts*(self.params.J+1)**2, self.params.J+1, self.params.J+1))) \
														#return shape = (rollouts * (J+1)^2, N)
		return tf.reshape(feed_out, (self.params.rollouts, self.params.J+1, self.params.J+1, self.params.N))


class Policy_feedforward(object):
	def __init__(self, params):

		self.params = params
		weight_initializer = tf.contrib.layers.xavier_initializer(dtype=tf_dtype, seed=self.params.tf_random_seed)
		weight_regularizer = None

		# self.W1 = tf.get_variable( name="W_layer1", shape=[(self.params.J+1)**2, self.params.hidden_layers[0]], dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer )
		# self.b1 = tf.get_variable( name="b_layer1", shape=[self.params.hidden_layers[0]], dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer )
		# self.W2 = tf.get_variable( name="W_layer2", shape=[self.params.hidden_layers[0], self.params.hidden_layers[1]], dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer )
		# self.b2 = tf.get_variable( name="b_layer2", shape=[self.params.hidden_layers[1]], dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer )
		# self.W3 = tf.get_variable( name="W_output", shape=[self.params.hidden_layers[1], self.params.N], dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer )
		# self.b3 = tf.get_variable( name="b_output", shape=[self.params.N], dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer )
		# self.trainable_list = tf.trainable_variables()
		# self.W = [self.W1, self.W2, self.W3]
		# self.B = [self.b1, self.b2, self.b3]

		self.W, self.b = [], []
		self.W.append( tf.get_variable( name="W_input", shape=[(self.params.J+1)**2, self.params.hidden_layers[0]], \
										  dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer) )
		self.b.append( tf.get_variable( name="b_input", shape=[self.params.hidden_layers[0]], \
										  dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer) )
		for i in range(len(self.params.hidden_layers)-1):
			self.W.append( tf.get_variable( name="W_layer"+str(i+1), shape=[self.params.hidden_layers[i], self.params.hidden_layers[i+1]], \
											  dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer) )
			self.b.append( tf.get_variable( name="b_layer"+str(i+1), shape=[self.params.hidden_layers[i+1]], \
											  dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer) )

		self.W.append( tf.get_variable( name="W_output", shape=[self.params.hidden_layers[-1], self.params.N], \
										  dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer) )
		self.b.append( tf.get_variable( name="b_output", shape=[self.params.N], \
										  dtype=tf_dtype, initializer=weight_initializer, regularizer=weight_regularizer) )

		temp_list = []
		for r in range(self.params.rollouts):
			temp_list.append(tf.sparse.expand_dims(tf.sparse.eye((self.params.J+1)**2), axis=0))
		self.sp_eye = tf.sparse.concat(0, temp_list) #shape = (rollouts, (J+1)^2, (J+1)^2)

		self.nonlinear_activation = 'tanh' # relu or tanh
		print("\nBuilding a FNN policy with "+self.nonlinear_activation+" activations")


	def _policy_forward_pass(self,h):
		#accepts h as shape = (rollouts, (J+1), (J+1)) so must be reshaped to (rollouts, (J+1)^2)  

		# output1 = tf.nn.relu(tf.matmul(tf.reshape(h, [self.params.rollouts, (self.params.J+1)**2]),self.W1) + self.b1)
		# output2 = tf.nn.relu(tf.matmul(output1,self.W2) + self.b2)
		# return tf.matmul(output2,self.W3) + self.b3 #shape = (rollouts * (J + 1), N)

		activation = tf.reshape(h, [self.params.rollouts, (self.params.J+1)**2])
		for i in range(len(self.W)-1): # one less because of linear activation for output layer
			if self.nonlinear_activation == 'relu':
				activation = tf.nn.relu( tf.matmul(activation, self.W[i])+self.b[i] )
			elif self.nonlinear_activation == 'tanh':
				activation = tf.nn.tanh( tf.matmul(activation, self.W[i])+self.b[i] )
		return tf.matmul(activation, self.W[-1]) + self.b[-1] #shape = (rollouts * (J + 1), N)		

	def _sparse_forward_pass(self,h):
		#accepts a sparse h tensor of shape = (rollouts * (J+1)^2, (J+1)^2)
		# output1 = tf.nn.relu(tf.sparse_tensor_dense_matmul(h, self.W1) + self.b1)
		# output2 = tf.nn.relu(tf.matmul(output1,self.W2) + self.b2)
		# return tf.matmul(output2,self.W3) + self.b3 #shape = (rollouts * (J + 1), N)

		if self.nonlinear_activation == 'relu':
			activation = tf.nn.relu( tf.sparse_tensor_dense_matmul(h, self.W[0]) + self.b[0] )
		elif self.nonlinear_activation == 'tanh':
			activation = tf.nn.tanh( tf.sparse_tensor_dense_matmul(h, self.W[0]) + self.b[0] )

		for i in range(1, len(self.W)-1): #start with 1, because input layer is sparse operation and one less because of linear activation for output layer
			if self.nonlinear_activation == 'relu':
				activation = tf.nn.relu( tf.matmul(activation, self.W[i])+self.b[i] )
			elif self.nonlinear_activation == 'tanh':
				activation = tf.nn.tanh( tf.matmul(activation, self.W[i])+self.b[i] )
		return tf.matmul(activation, self.W[-1]) + self.b[-1] #shape = (rollouts * (J + 1), N)				


	def _policy_eval(self,h):
		# This function takes input h, and returns a (rollouts, J+1, N) tensor resulting from running input's elements as eigenvalues of the spatial basis
		#h input will be shape=(rollouts, J+1, J+1) so must be reshaped to (rollouts, (J+1)^2) 
		h_exp = tf.expand_dims(tf.reshape(h, [self.params.rollouts, (self.params.J+1)**2]), axis=-1) 
		diag_h = tf.sparse.reshape(self.sp_eye * h_exp, (self.params.rollouts * (self.params.J+1)**2, (self.params.J+1)**2)) #shape = (rollouts * (J+1)^2, (J+1)^2)
		return tf.reshape( self._sparse_forward_pass(diag_h) , (self.params.rollouts, self.params.J+1, self.params.J+1, self.params.N))

class Policy_sparse_convolutional(object):
	def __init__(self, params):

		self.params = params
		if self.params.relu_activation:
			print("\nBuilding a sparse CNN policy with relu activation with use_bias = ", self.params.use_bias)
		else:
			print("\nBuilding a sparse CNN policy with tanh activation with use_bias = ", self.params.use_bias)

		self.weight_initializer = tf.contrib.layers.xavier_initializer(dtype=tf_dtype, seed=self.params.tf_random_seed)
		# self.weight_initializer = tf.zeros_initializer()
		self.weight_regularizer = None
		self.eye = tf.eye((self.params.J+1)**2, dtype=tf_dtype, batch_shape=[self.params.rollouts])

		# Create Toeplitz matrix for input convolution layer:
		self.input_toeplitz_matrix_list = []
		for i in range(self.params.num_filters[0]):
			self.input_toeplitz_matrix_list.append( tf_toeplitz(tf.get_variable(name="input_kernel_"+str(i+1), shape=[self.params.kernel_size[0], self.params.kernel_size[0]], \
									dtype=tf_dtype, initializer=self.weight_initializer, regularizer=self.weight_regularizer), self.params.J+1, self.params.stride[0]) )
			# each has a shape of (shift**2, n**2)
		self.first_layer_shift = int((self.params.J+1 - self.params.kernel_size[0])/self.params.stride[0] + 1)

		temp_list = []
		for r in range(self.params.rollouts):
			temp_list.append(tf.sparse.expand_dims(tf.sparse.eye((self.params.J+1)**2), axis=0))
		self.sp_eye = tf.sparse.concat(0, temp_list) #shape = (rollouts, (J+1)^2, (J+1)^2)       


	def _policy_forward_pass(self,h):
		# accepts h as shape = (rollouts, (J+1), (J+1) ) 
		# First perform input convolution:
		input_toeplitz_matrix = tf.ones((self.params.rollouts, self.params.num_filters[0], self.first_layer_shift**2, (self.params.J+1)**2)) \
										* tf.expand_dims(tf.stack(self.input_toeplitz_matrix_list, axis=0), axis=0) # shape: (rollouts, num_filters, shift**2, n**2)
		h_flat = tf.expand_dims(tf.ones((self.params.rollouts, self.params.num_filters[0],  (self.params.J+1)**2)) \
									    * tf.expand_dims(tf.reshape(h, (self.params.rollouts, -1)), axis=1), axis=-1)
		input_conv = tf.matmul(input_toeplitz_matrix, h_flat)
		input_relu = tf.reshape(self.params.activation(input_conv), (self.params.rollouts, self.params.num_filters[0], self.first_layer_shift, self.first_layer_shift)) #shape = (rollouts, num_filters, shift, shift)
		input_max_pool = tf.nn.max_pool(tf.transpose(input_relu, perm=[0,2,3,1]), (1,2,2,1), (1,2,2,1), padding='SAME', name="pool1") # shape = (rollouts, shift/2, shift/2, num_filters)
		for i in range(1,len(self.params.stride)):
			output1 = self._conv_operation(in_tensor=input_max_pool, num_filters=self.params.num_filters[i], \
									   kernel_size=(self.params.kernel_size[i],self.params.kernel_size[i]), stride=(self.params.stride[i],self.params.stride[i]), name="conv"+str(i+1))
			output2 = self.params.activation(output1)
			input_max_pool = tf.nn.max_pool(output2,(1,2,2,1), (1,2,2,1), padding='SAME', name="pool"+str(i+1)) 

		flat = tf.reshape(input_max_pool, (self.params.rollouts, -1))
		# print(flat.shape)

		return tf.layers.dense(flat, self.params.N, kernel_initializer=self.weight_initializer, kernel_regularizer=self.weight_regularizer, \
							   use_bias=self.params.use_bias, reuse=tf.AUTO_REUSE, name="output_layer")

	def _sparse_forward_pass(self,h):
		# accepts h as shape = (rollouts * (J+1)**2, (J+1)**2) as a sparse matrix
		# First perform input convolution:

		# Three ways to perform sparse matmul:
		# (1.) Using reshape():
		# h_exp = tf.sparse_reshape(h, (self.params.rollouts * (self.params.J+1)**2, 1, 1, (self.params.J+1)**2))
		# toeplitz_exp = tf.reshape(tf.stack(self.input_toeplitz_matrix_list, axis=0), (1, self.params.num_filters[0], self.first_layer_shift**2, (self.params.J+1)**2))
		# h_conv = h_exp * toeplitz_exp
		# input_conv = tf.sparse.reduce_sum(h_conv, axis=-1) #shape = (rollouts *(J+1)^2, num_filters, first_layer^2)
		
		# (2.) Using expand_dims():
		# h_exp = tf.sparse.expand_dims(tf.sparse.expand_dims(h, axis=1), axis=1)
		# toeplitz_exp = tf.expand_dims(tf.stack(self.input_toeplitz_matrix_list, axis=0), axis=0)
		# h_conv = h_exp * toeplitz_exp
		# input_conv = tf.sparse.reduce_sum(h_conv, axis=-1) #shape = (rollouts *(J+1)^2, num_filters, first_layer^2)

		# (3.) Use for-loop over the number of filters in input layer:
		# h_exp = tf.sparse.expand_dims(h, axis=1) # shape: (rollouts*(J+1)^2, 1, (J+1)^2)
		# toeplitz_exp = tf.expand_dims(tf.stack(self.input_toeplitz_matrix_list, axis=0), axis=0) # shape: (1, num_filters, first_layer^2, n^2)
		matmul_list = []
		for j in range(self.params.num_filters[0]):
			matmul_list.append(tf.sparse_tensor_dense_matmul(h, tf.transpose(self.input_toeplitz_matrix_list[j], perm=[1,0]) ) ) #shape = (rollouts * J+1^2, first_layer^2)
			# matmul_list.append( tf.sparse.reduce_sum(h_exp * toeplitz_exp[:,j,:,:], axis=-1) ) # each is: (rollouts*(J+1)^2, first_layer^2)
		input_conv = tf.stack(matmul_list, axis=1) # shape: (rollouts*(J+1)^2, num_filters, first_layer^2)

		input_relu = tf.reshape(self.params.activation(input_conv), (self.params.rollouts * (self.params.J+1)**2, self.params.num_filters[0], self.first_layer_shift, self.first_layer_shift)) #shape = (rollouts, num_filters, shift, shift)
		input_max_pool = tf.nn.max_pool(tf.transpose(input_relu, perm=[0,2,3,1]), (1,2,2,1), (1,2,2,1), padding='SAME', name="pool1") # shape = (rollouts, shift/2, shift/2, num_filters)
		for i in range(1,len(self.params.stride)):
			output1 = self._conv_operation(in_tensor=input_max_pool, num_filters=self.params.num_filters[i], \
									   kernel_size=(self.params.kernel_size[i],self.params.kernel_size[i]), stride=(self.params.stride[i],self.params.stride[i]), name="conv"+str(i+1))
			output2 = self.params.activation(output1)
			input_max_pool = tf.nn.max_pool(output2,(1,2,2,1), (1,2,2,1), padding='SAME', name="pool"+str(i+1)) 

		flat = tf.reshape(input_max_pool, (self.params.rollouts * (self.params.J+1)**2, -1))

		return tf.layers.dense(flat, self.params.N, kernel_initializer=self.weight_initializer, kernel_regularizer=self.weight_regularizer, \
							   use_bias=self.params.use_bias, reuse=tf.AUTO_REUSE, name="output_layer")


	def _conv_operation(self, in_tensor, num_filters, kernel_size, name, stride=1):
		return tf.layers.conv2d(in_tensor, 
								num_filters, 
								kernel_size=kernel_size,
								strides=stride, 
								padding='same', 
								name=name, 
								use_bias=self.params.use_bias,
								reuse=tf.AUTO_REUSE,
								kernel_initializer=self.weight_initializer,
								kernel_regularizer=tf.contrib.layers.l2_regularizer(self.params.l2_scale),
								bias_initializer=self.weight_initializer,
								bias_regularizer=tf.contrib.layers.l2_regularizer(self.params.l2_scale))

	def _policy_eval(self,h):
		# This function takes input h, and returns a (rollouts, J+1, N) tensor resulting from running input's elements as eigenvalues of the spatial basis
		#h input will be shape=(rollouts, J+1, J+1) so must be reshaped to (rollouts, (J+1)^2) 
		h_exp = tf.expand_dims(tf.reshape(h, [self.params.rollouts, (self.params.J+1)**2]), axis=-1) #shape = (rollouts, J+1^2, 1)
		diag_h = tf.sparse.reshape(self.sp_eye * h_exp, (self.params.rollouts * (self.params.J+1)**2, (self.params.J+1)**2)) #shape = (rollouts * (J+1)^2, (J+1)^2)
		return tf.reshape( self._sparse_forward_pass(diag_h) , (self.params.rollouts, self.params.J+1, self.params.J+1, self.params.N))
