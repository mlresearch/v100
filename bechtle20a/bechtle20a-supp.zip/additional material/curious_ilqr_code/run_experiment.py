import numpy as np
from cost import QuadraticCost
from uncertain_ilqr import iLQR
from simulated_dynamics import SimulatedDynamics
from envs.reacher_sim import ReacherSimulation


import pickle
global experiments_result

experiments_result = {}
experiments_result['runs'] = []


def run_ilqr(dynamics, env, sigma, x_target, ee_target, u_init=None, baseline=None):

    iteration = {}

    state_dim = 4
    action_dim = 2
    Q = 0 * np.eye(state_dim)
    Q[0,0] = Q[1,1] = 5e4
    Q[2,2] = Q[3,3] = 1e3

    Q_terminal = Q.copy()
    R = 3e-3 * np.eye(action_dim)
    cost = QuadraticCost(Q, R, Q_terminal=Q_terminal,x_target=x_target)


    def iteration_callback(iteration_count, xs, us, J_opt, accepted, converged):
        info = "converged" if converged else ("accepted" if accepted else "failed")
        final_state = xs[-1]
        print("iterationss", iteration_count, info, J_opt, final_state)

    time_horizon =len(u_init)
    x0 =np.array(env.reset(np.zeros(2)))

    ilqr = iLQR(dynamics, cost, time_horizon,sigma)

    res = ilqr.run(x0, u_init, 100, iteration_callback)

    iteration['x_traj'] = res['x_traj']
    iteration['u_opt'] = res['u_seq']
    iteration['K'] = res['K']
    iteration['iter'] = res['iter']
    iteration['sigma'] = sigma

    K = res['K']
    Quu_inv = res['Quu_inv']
    torques = res['u_seq']
    x_traj = res['x_traj']

    obs=env.reset(np.zeros(2))
    actions = []
    traj_rew = []
    observations = []
    next_observation = []
    pred_next_states = []
    pred_variances = []
    end_effector_pos = []

    for t in range(len(K)):
        noise = 0.0
        if baseline=='gaussian':
            noise = np.random.multivariate_normal(mean=np.zeros(2),cov=np.diag(np.zeros(2)+0.2))
        elif baseline=='max_ent':
            noise =np.random.multivariate_normal(mean=np.zeros(2),cov=Quu_inv[t])

        ac = torques[t] + K[t].dot(obs - x_traj[t]) + noise
        ac = ac.clip(-np.ones(2),np.ones(2))
        next_obs,ee_pos=env.apply_joint_torque(ac)
        state = obs.copy()
        end_effector_pos.append(ee_pos)
        pred_next_state,pred_variance = dynamics.dynamics_model.forward_uncertainty(np.hstack([state,ac]))
        pred_variances.append(pred_variance)
        pred_next_states.append(pred_next_state)
        observations.append(np.array(obs).flatten())
        actions.append(ac)
        next_observation.append(np.array(next_obs).flatten())
        obs = next_obs.copy()


    print('last_obs:',next_obs)
    print('joint target:', x_target)

    iteration['states'] = observations
    iteration['actions'] = actions
    iteration['next_states'] = next_observation
    iteration['traj_rew'] = traj_rew
    iteration['pred_variance'] = pred_variances
    iteration['joint_target'] = x_target
    iteration['ee_pos'] = np.array(end_effector_pos)
    iteration['ee_target'] = ee_target

    dynamics.dynamics_model.train(np.array(observations),np.array(actions),np.array(next_observation))

    iteration['tested_actions'] = dynamics.dynamics_model.tested_actions
    iteration['tested_pos_unc'] = dynamics.dynamics_model.tested_uncertainties_pos
    iteration['tested_vel_unc'] = dynamics.dynamics_model.tested_uncertainties_vel

    experiments_result['runs'].append(iteration)


def random_babbling(rand_actions,env,dynamic_model):
    state = env.reset(np.zeros(2))
    states = []
    actions = []
    next_states = []
    for ac in rand_actions:
        states.append(np.array(state).flatten())
        actions.append(ac)
        next_state,ee_pos = env.apply_joint_torque(ac)
        next_states.append(np.array(next_state).flatten())
        state = next_state.copy()
    dynamic_model.train(np.array(states),np.array(actions),np.array(next_states))

   

def main(seed):
    global logger
    global experiments_result
    action_bounds = np.array([1.0, 1.0])
    targets = [[0.02534078, 0.19863741,0.0]]

    env=ReacherSimulation(gui=False)
    time_horizon = 200
    u_init = np.random.uniform(-1.0, 1.0, (time_horizon, 2))
    sigmas = [-1.0,0.0,'gaussian','max_ent']
    random_actions = np.random.uniform(low=-1.0,high=1.0,size=(2,2))

    for target in targets:
        env.reset(np.zeros(2)+np.random.normal(0.0,0.1,2))
        joint_target = np.hstack([env.get_target_joint_configuration(target), np.zeros(2)])
        for sigma in sigmas:
            experiments_result = {}
            experiments_result['runs'] = []
            dynamics = SimulatedDynamics(action_bounds)
            random_babbling(random_actions, env, dynamics.dynamics_model)
            for i in range(5):
                x_target =joint_target
                if isinstance(sigma, str):
                    run_ilqr(dynamics, env, 0.0, x_target, target[:2], u_init=u_init, baseline=sigma)
                else:
                    run_ilqr(dynamics, env, sigma, x_target, target[:2], u_init=u_init, baseline=sigma)

                with open('experiment_data/ilqr_experiment_seed_' + str(seed)+'sigma_'+str(sigma)+'_.p', 'wb') as fp:
                    pickle.dump(experiments_result, fp, protocol=pickle.HIGHEST_PROTOCOL)

if __name__ == '__main__':
    for seed in range(5,10):
        np.random.seed(seed)
        main(seed)
