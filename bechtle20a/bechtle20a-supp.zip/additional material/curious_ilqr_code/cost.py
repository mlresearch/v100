
import numpy as np


# class QuadraticCost(object):

#     def __init__(self, Q, R, Q_terminal=None, x_target=None):

#         self._Q = Q
#         self._R = R
#         self.target = x_target

#     def eval(self, x, u, terminal=False):
#         # x in D_x x 1, u in D_u x 1
#         if terminal:
#             wp = 1e4 # terminal position cost weight
#             wv = 1e4
#             xy_err = np.array([x[-2] - self.target[0], x[-1] - self.target[1]])
#             l = (wp * np.sum(xy_err**2) + wv * np.sum(x[4:6]**2))
#             return l

#         else:
#             return np.sum(u)**2



#     def du(self, u):
#         return 2 * u
            
#     def dx(self, x):
#         return np.zeros(8)



#     def dxu(self, x, u):
#         return np.zeros((8, 2))

#     def dux(self, x, u):
#         return np.zeros((2, 8))

#     def duu(self, u):
#         return 2 * np.eye(2)

#     def dxx(self, x):
#         return np.zeros_like(x)

#     def dx_terminal(self, x, u):
#         l_x = np.zeros((8))
#         wp = 1e4 # terminal position cost weight
#         wv = 1e4
#         l_x[0:2] = wp * self.dif_end(self._reduce_state(x)[0:2])
#         l_x[4:6] = (2 * wv * x[4:6])
#         return l_x


#     def dxx_terminal(self, x, u):
#         l_xx = np.zeros((8, 8))
#         eps = 1e-4
#         wp = 1e4 # terminal position cost weight
#         wv = 1e4 # finite difference epsilon
#         # calculate second derivative with finite differences
#         for k in range(2): 
#             veps = np.zeros(2)
#             veps[k] = eps
#             d1 = wp * self.dif_end(self._reduce_state(x)[0:2] + veps)
#             d2 = wp * self.dif_end(self._reduce_state(x)[0:2] - veps)
#             l_xx[0:2, k] = ((d1-d2) / 2.0 / eps).flatten()

#         l_xx[4:6, 4:6] = 2 * wv * np.eye(2)
#         return l_xx

#     # Compute derivative of endpoint error 
#     def dif_end(self, x):

#         xe = -self.target.copy()
#         for ii in range(2):
#             xe[0] += .1 * np.cos(np.sum(x[:ii+1]))
#             xe[1] += .1 * np.sin(np.sum(x[:ii+1]))

#         edot = np.zeros((2,1))
#         for ii in range(2):
#             edot[ii,0] += (2 * .1 * (xe[0] * -np.sin(np.sum(x[:ii+1])) + xe[1] * np.cos(np.sum(x[:ii+1]))))
#         edot = np.cumsum(edot[::-1])[::-1][:]

#         return edot

#     def _reduce_state(self, state):
#         # theta = np.arctan2(state[1], state[2])
#         # reduced_state = np.zeros(4)
#         # reduced_state[0] = state[0]
#         # reduced_state[1] = theta
#         # reduced_state[2] = state[3]
#         # reduced_state[3] = state[4]

#         #return reduced_state
#         return np.concatenate([np.arctan2(state[:2],state[2:4]),state[4:6],state[6:]])




class QuadraticCost(object):

    def __init__(self, Q, R, Q_terminal=None, x_target=None):

        self._Q = Q
        self._R = R
        if Q_terminal is None:
            self._Q_terminal = 100.0 * np.eye(len(self._Q))
        else:
            self._Q_terminal = Q_terminal

        if x_target is None:
            self._x_target = np.zeros(Q.shape[0])
        else:
            self._x_target = x_target

    def eval(self, x, u, terminal=False):
        # x in D_x x 1, u in D_u x 1
        x_err = np.zeros_like(x)
        x_err = x - self._x_target
        if terminal:
            Q = self._Q_terminal
            return np.dot(x_err.T, np.dot(Q, x_err)) 
        else:
            Q = self._Q
            return np.dot(x_err.T, np.dot(Q, x_err)) + np.dot(u.T, np.dot(self._R, u))

    def du(self, u):
        return np.dot(self._R, u)
            
    def dx(self, x):
        x_err = np.zeros_like(x)
        x_err = x - self._x_target
        return np.dot(self._Q, x_err)

    def dx_terminal(self, x, u):
        x_err = np.zeros_like(x)
        x_err = x - self._x_target
        return np.dot(self._Q_terminal, x_err)

    def dxu(self, x, u):
        return np.zeros_like(x)

    def dux(self, x, u):
        return np.zeros_like(x)

    def duu(self, u):
        return self._R

    def dxx(self, x):
        return self._Q

    def dxx_terminal(self, x, u):
        return self._Q_terminal


# import numpy as np
# from scipy.optimize import approx_fprime
# import scipy.misc

# class QuadraticCost(object):

#     def __init__(self, Q, R, Q_terminal=None, x_target=None,state_dim=8,u_dim=2):

#         self._Q = Q
#         self._R = R
#         if Q_terminal is None:
#             self._Q_terminal = Q
#         else:
#             self._Q_terminal = Q_terminal

#         if x_target is None:
#             self._x_target = np.zeros(Q.shape[0])
#         else:
#             self._x_target = x_target

#         self.state_dim = state_dim
#         self.u_dim = u_dim
#         self.wp = 1e3
#         self.wv=1e2
#         self.vel_position = 4
#         self.vel_end = 6

#     def eval(self, x, u, terminal=False):
#         # # x in D_x x 1, u in D_u x 1
#         # x_err = x - self._x_target
#         # x_err[1:] = np.zeros(len(x)-1)
#         # if terminal:
#         #     Q = self._Q_terminal
#         # else:
#         #     Q = self._Q
        
#         # return (0.5*np.dot(x_err.T, np.dot(Q, x_err)) +
#         #         0.5*np.dot(u.T, np.dot(self._R, u)))

#         if terminal:
#             wp=1e3
#             wv=1e2
#             xy_err = self.wp*np.sum((x[-2:]-self._x_target)**2)
#             vel_error = self.wv*np.sum(x[self.vel_position:self.vel_end]**2)
#             #l=wp*xy_err #+ wv*np.sum(x[6:]**2)
#             #print('terminal cost',xy_err)
#             return xy_err+vel_error
#         else:
#             return np.sum(u**2)

#     def du(self, u):
#         return 2*u
            
#     def dx(self, x):
#         return np.zeros(self.state_dim)

#     # def dx_terminal(self, x):
#     #     dx = np.zeros(self.state_dim)
#     #     dx[-2:]=(self.wp*2*(x[-2]-self._x_target))
#     #     dx[self.vel_position:self.vel_end]=(self.wv*2)*x[self.vel_position:self.vel_end]
#     #     return dx

#     def dxu(self, x, u):
#         return np.zeros([self.state_dim,self.u_dim])

#     def dux(self, x, u):
#         return np.zeros([self.u_dim,self.state_dim])

#     def duu(self, u):
#         return 2*np.eye(self.u_dim)

#     def dxx(self, x):
#         return np.zeros([self.state_dim,self.state_dim])

#     def dxx_terminal(self, x,u):

#         J=scipy.misc.derivative(self.eval, x, n=2, args=(x,u), order=5, dx=1e-6)
#         print(J)
#         return J
#         # dxx = np.zeros([self.state_dim,self.state_dim])
#         # dxx[-2:,-2:] = (2*self.wp)*np.eye(self.u_dim)
#         # eps = 1e-4
#         # #print(np.vstack([approx_fprime(u, lambda u: self.dx_terminal(x, u)[i], eps) for i in range(len(x))]))
#         # #dxx[-2:,-2:] = np.vstack([approx_fprime(u, lambda u: self.dx_terminal(x, u)[i], eps) for i in range(len(x))])[0]
#         # dxx[self.vel_position:self.vel_end,self.vel_position:self.vel_end] = (2*self.wv)*np.eye(2)
        
#         # #return (2*1e4)*np.eye(self.state_dim)

#         # # eps = 1e-3 # finite difference epsilon
#         # # # calculate second derivative with finite differences
#         # # for k in range(2): 
#         # #     veps = np.zeros(2)
#         # #     veps[k] = eps
#         # #     d1 = self.wp * approx_fprime(x, lambda x: self.eval(x, u,True), eps)
#         # #     d2 = self.wp * approx_fprime(x, lambda x: self.eval(x, u,True), -eps)
#         # #     #print(d1)
#         # #     dxx[:, -k] = ((d1-d2) / 2.0 / eps).flatten()
#         # return dxx

#     def dx_terminal(self, x, u):
#         eps = 1e-6
#         J = approx_fprime(x, lambda x: self.eval(x, u,True), eps)
#         return J

 
