import numpy as np
import GPy
MACHINE_EPSILON = np.finfo(np.double).eps

class DynamicsLearner(object):
	'''
	multivariete wrapper for gaussian process model for sklearn
	'''
	
	
	def __init__( self,input_dimension, output_dimension):

		self.kernels = [GPy.kern.RBF(input_dim=input_dimension, lengthscale=0.3,variance=0.1,useGPU=False) for i in range(output_dimension)]
		self.gps_models = [None for i in range(output_dimension)]
		self.output_dimension = output_dimension
		self.X=[]
		self.Ys=[[] for i in range(output_dimension)]
		
		self.iter=0
		self.inneriter=0
		self.tested_actions = []
		self.tested_uncertainties_pos=[]
		self.tested_uncertainties_vel=[]
		self.norm_in = np.ones(input_dimension)
		self.norm_in[2] = self.norm_in[3] = 8.0
		self.norm_in = np.expand_dims(self.norm_in,axis=0)
		self.dt = 1.0/240.0
	
	def train( self,obs,tau,next_obs):
		print(np.shape(obs))
		print(np.shape(tau))
		inputs = np.hstack((obs,tau))/self.norm_in
		outputs = next_obs[:,2:] - obs[:,2:]


		self.X +=list(inputs)

		for dim in range(self.output_dimension):
			self.Ys[dim] +=list(outputs[:,dim].reshape([len(next_obs),1]))

		print(np.shape(self.Ys))

		for dim in range(self.output_dimension):
			self.gps_models[dim] = GPy.models.GPRegression(np.array(self.X),np.array(self.Ys[dim]),self.kernels[dim])
			self.gps_models[dim].optimize()


	def forward(self,obs):
		input_x = obs/self.norm_in
		if self.gps_models[0] is not None:
			prediction = np.zeros(2)

			for dim in range(self.output_dimension):
				pred = self.gps_models[dim].predict(input_x)[0]
				prediction[dim] = pred[0]

			vel = np.array(obs)[2:4] + prediction
			result = np.zeros(4)
			result[2:] = vel
			result[:2] = np.array(obs)[:2] + vel * self.dt
			return result
		else:
			return np.random.uniform(-1.0,1.0,6)


	def forward_uncertainty(self,obs):
		input_x = obs/self.norm_in
		if self.gps_models[0] is not None:
			prediction = np.zeros(2)
			variances = np.zeros(2)
			for dim in range(self.output_dimension):
				pred = self.gps_models[dim].predict(input_x)
				prediction[dim] =pred[0][0]
				variances[dim] = pred[1][0]


			vel = np.array(obs)[2:4] + prediction
			result = np.zeros(4)
			result[2:] = vel
			result[:2] = np.array(obs)[:2] + vel * self.dt
			return result, np.array(list(variances)+list(variances))
		else:
			return np.random.uniform(-1.0,1.0,6)


	def get_pred_error( self, obs,tau):
		X = np.append(obs,tau)/self.norm_in
		if self.gps_models[0] is not None:
			
			self.tested_actions.append(tau)
			diagonal = []
			predictions = []

			for dim in range(self.output_dimension):
				pred = self.gps_models[dim].predict(X)
				diagonal+=list(pred[1][0])
				predictions +=list(pred[0][0])

			diagonal=np.array(diagonal)/self.dt
			diagonal = np.clip(diagonal, 0.0, 1.0)
			covar_matrix = np.hstack([diagonal,diagonal])

			return covar_matrix



		return np.zeros(6)


	def get_gradients(self,state,action):
		X = np.append(state,action)/self.norm_in
		gradients = []
		for dim in range(self.output_dimension):
				gradient = self.gps_models[dim].predictive_gradients(X,kern=self.kernels[dim])
				gradients.append(gradient[0])
		return np.array(gradients).reshape([2,6])