import numpy as np
from envs.bullet_sim import BulletSimulationFromMJCF


class ReacherSimulation(BulletSimulationFromMJCF):
    def __init__(self,  gui, controlled_joints=None, ee_idx=None, torque_limits=None):
        rel_xml_path = "mujoco_robots/reacher.xml"

        #fingertip
        if ee_idx is None:
            self.ee_idx = 4
        if controlled_joints is None:
            controlled_joints = [0, 2]
        if torque_limits is None:
            torque_limits = np.asarray([1, 1])

        super(ReacherSimulation, self).__init__(rel_mjcf_path=rel_xml_path,
                                                gui=gui,
                                                controlled_joints=controlled_joints,
                                                ee_idx=self.ee_idx,
                                                torque_limits=torque_limits)

        if gui:
            self.sim.resetDebugVisualizerCamera(cameraDistance=1, cameraYaw=-30, cameraPitch=-30,
                                                cameraTargetPosition=[0, 0, 0])

        n_dofs_total = self.sim.getNumJoints(self.robot_id)
        print("n dofs total (including fixed joints): {}".format(n_dofs_total))

        for i in range(n_dofs_total):
            print(self.sim.getJointInfo(self.robot_id, i))
        return

