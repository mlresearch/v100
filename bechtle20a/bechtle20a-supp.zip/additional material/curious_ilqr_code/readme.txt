The code runs with python3.6

Dependencies:

pip install pybullet,
pip install numpy
pip install GPy


to run experiment:

python run_experiment.py

for visualisations:

analyse_data_2d_reacher.ipynb
