import numpy as np


class iLQR(object):
    def __init__(self, dynamics, cost, time_horizon, sigma, max_reg=1e4, dt=1.0 / 240, num_processes=8):
        self.dt = dt
        self._dynamics = dynamics
        self._time_horizon = time_horizon
        self._cost = cost
        self._reg_min = 1e-6
        self._reg_factor = 10
        self._reg_max = 1000

        # Regularization terms: Levenberg-Marquardt parameter.
        self._mu = 1.0
        self._mu_min = 1e-6
        self._mu_max = max_reg
        self._delta_0 = 2.0
        self._delta = self._delta_0
        self.sigma = sigma
        self._pos_dim=2

    def _forward_pass(self, x0, u_seq):
        # x0 Dx1 , u_seq N x 1
        print(self._time_horizon)
        x_traj = np.zeros((self._time_horizon + 1, len(x0)))
        x_traj[0, :] = x0
        for t, u in enumerate(u_seq):
            x_traj[t + 1, :] = self._dynamics(x_traj[t, :], u)

        return x_traj

    def _smooth_inv(self, m):
        try:
            w, v = np.linalg.eigh(m)
            w_inv = w / (w ** 2 + 1e-6)
            return v.dot(np.diag(w_inv)).dot(v.transpose())
        except:
            return np.linalg.inv(m+np.eye(4)*1e-6)

    def _regularize(self, m):
        # print(m)
        w, v = np.linalg.eigh(m)
        if w[0] < 1e-4:
            # print('regularizing')
            # print w
            m += (abs(w[0]) + 1e-4) * np.eye(len(w))
        return np.linalg.inv(m)


    def _backward_pass(self, x_traj, u_seq):
        # traj has length time_horizon+1
        # u_seq has length time_horizon

        k = [None] * self._time_horizon
        K = [None] * self._time_horizon
        K_normal = [None] * self._time_horizon
        reg = 0  # self._mu * np.identity(x_traj.shape[1])

        Vxx = self._cost.dxx_terminal(x_traj[-1, :], u_seq[-1])
        Vx = self._cost.dx_terminal(x_traj[-1, :], u_seq[-1])
        Quu_invs = np.zeros([self._time_horizon, self._pos_dim, self._pos_dim])


        for t in reversed(range(self._time_horizon)):
            xt, ut = x_traj[t, :], u_seq[t, :]
            q, r = self._cost.dx(xt), self._cost.du(ut)
            Q, R = self._cost.dxx(xt), self._cost.duu(ut)
            P = self._cost.dux(xt, ut)

            A, B = self._dynamics.dx_du(xt, ut)

            sigma = self.sigma

            C = np.eye(4)  # 0.1
            uncertainty = self._dynamics.dynamics_model.get_pred_error(xt, ut)
            covar = np.diag(uncertainty)

            if self.sigma==-100:
                covar = np.diag(np.random.normal(0.0,1.0,size=4))
                sigma = -1.0


            term_covar = C.dot(covar).dot(C.T)

            H = R + B.T.dot(Vxx).dot(B) + sigma * B.T.dot(Vxx.T).dot(term_covar).dot(Vxx).dot(B)

            g = r + B.T.dot(Vx) + sigma * B.T.dot(Vxx.T).dot(term_covar).dot(Vx)

            G = P.T + B.T.dot(Vxx).dot(A) + sigma * B.T.dot(Vxx.T).dot(term_covar.T).dot(Vxx).dot(A)

            iH = np.nan_to_num(self._smooth_inv(H))
            Quu_invs[t] = iH

            k[t] = -iH.dot(g)
            K[t] = -iH.dot(G)

            s = q + A.T.dot(Vx) + G.T.dot(k[t]) + K[t].T.dot(g) + K[t].T.dot(H).dot(k[t]) + sigma * A.T.dot(Vxx.T).dot(
                term_covar).dot(Vx)

            Vx = s[:]

            S = Q + A.T.dot(Vxx).dot(A) + K[t].T.dot(H).dot(K[t]) + G.T.dot(K[t]) + K[t].T.dot(G) + sigma * A.T.dot(
                Vxx.T).dot(term_covar).dot(Vxx).dot(A)
            Vxx = 0.5 * (S + S.T)[:]

        return np.nan_to_num(np.array(k)), np.nan_to_num(np.array(K)), Quu_invs

    def _eval_trajectory_cost(self, x_traj, u_seq):
        J = 0.0
        for t in range(self._time_horizon):
            xt, ut = x_traj[t, :], u_seq[t]
            J += self._cost.eval(xt, ut)

        J += self._cost.eval(x_traj[-1, :], np.zeros_like(ut), terminal=True)
        return J

    def run(self, x0, u_init_seq, max_iter, iteration_callback=None, tol=1e-4):

        self._mu = 1.0
        alphas = 1.1 ** (-np.arange(10) ** 2)

        u_seq = u_init_seq.copy()
        x_traj = self._forward_pass(x0, u_init_seq)
        K_accepted = np.zeros_like(u_seq)
        Quu_invs_accepted = np.zeros([self._time_horizon, self._pos_dim, self._pos_dim])
        # print(x_traj)
        print("u_init len: {}".format(len(u_init_seq)))
        print("traj len: {}".format(x_traj.shape[0]))

        J_opt = self._eval_trajectory_cost(x_traj, u_init_seq)
        J_list = [J_opt]

        converged = False
        import time
        curr = time.time()
        for i in range(max_iter):
            print('time taken: {}'.format(time.time() - curr))
            curr = time.time()
            accept = False
            k, K,Quu_invs = self._backward_pass(x_traj, u_seq)
            for alpha in alphas:
                x_traj_new, u_seq_new = self._run_feedback_policy(x_traj, u_seq, k, K, alpha)
                J_new = self._eval_trajectory_cost(x_traj_new, u_seq_new)
                if J_new < J_opt:
                    if np.abs((J_opt - J_new) / J_opt) < tol:
                        converged = True
                        break
                    else:
                        # decrease regularization
                        self._delta = min(1.0, self._delta) / self._delta_0
                        self._mu *= self._delta
                        if self._mu <= self._mu_min:
                            self._mu = 0.0
                        accept = True

                    J_opt = J_new
                    x_traj = x_traj_new.copy()
                    u_seq = u_seq_new.copy()
                    K_accepted = K.copy()
                    Quu_invs_accepted = Quu_invs.copy()
                    break
                else:
                    accept = False

            if not accept:
                if i==0:
                    J_opt = J_new
                    x_traj = x_traj.copy()
                    u_seq = u_seq.copy()
                    K_accepted = K
                self._delta = max(1.0, self._delta) * self._delta_0
                self._mu = max(self._mu_min, self._mu * self._delta)
                if self._mu_max and self._mu >= self._mu_max:
                    print("regularization term too large, quitting")
                break

            if converged:
                print('converged')
                break

            if iteration_callback:
                iteration_callback(i, x_traj, u_seq, J_opt, accept, converged)

        result = {}
        result['iter'] = i
        result['u_seq'] = u_seq
        result['x_traj'] = x_traj
        result['K'] = K_accepted
        result['Quu_inv'] = Quu_invs_accepted

        return result

    def _run_feedback_policy(self, x_des, u_seq, k, K, alpha):
        x_new = np.zeros_like(x_des)
        u_new = np.zeros_like(u_seq)

        x_new[0, :] = x_des[0, :]
        for t in range(self._time_horizon):
            u_new[t] = u_seq[t] + alpha * k[t] + K[t].dot(x_new[t] - x_des[t])
            x_new[t + 1] = self._dynamics(x_new[t], u_new[t])

        return x_new, u_new
