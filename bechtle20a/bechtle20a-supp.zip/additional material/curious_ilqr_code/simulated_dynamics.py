# import autograd.numpy as np
# from autograd import grad
import numpy as np
from model_gpy import DynamicsLearner



class SimulatedDynamics():

    def __init__(self, action_bounds):
        super(SimulatedDynamics, self).__init__()
        self.state_dim=4
        self.action_dim=2
        self.dynamics_model = DynamicsLearner(self.state_dim+self.action_dim,self.action_dim)
        self.norm_vel = self.dynamics_model.norm_in[0,2:4]
        self.torques_norm = self.dynamics_model.norm_in[0,4:]
        self.norm_in = self.dynamics_model.norm_in
        self.torque_limits = action_bounds
        self.dt = self.dynamics_model.dt

    def __call__(self, state, u):
        # set the state x.
        return self._eval(state, u)


    def _eval(self,state,u):
        u = u.clip(-self.torque_limits,self.torque_limits)
        _input = np.hstack((state,u))
        new_state=self.dynamics_model.forward(_input)
        return new_state


    def dx_du(self, x, u):
        u = np.array(u)
        orig_torque = u.copy()
        clipped_u = u.clip(-self.torque_limits, self.torque_limits)
        gradients = self.dynamics_model.get_gradients(x, clipped_u)
        gradients_x = gradients[:, :4]
        gradients_x[:, 2:] = gradients_x[:, 2:] / self.norm_vel

        gradients_u = gradients[:, 4:] / self.torques_norm
        gradients_u[:, abs(orig_torque) > self.torques_norm] = 0.0
        dx = np.eye(4)
        dx[:2, 2:] = (gradients_x[:, 2:] + np.eye(2)) * self.dt
        dx[:2, :2] += gradients_x[:, :2] * self.dt

        dx[2:, :] += gradients_x

        du = np.zeros([4, 2])
        du[:2, :] += gradients_u * self.dt
        du[2:, :] += gradients_u

        return dx, du
