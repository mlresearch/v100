import os

import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as f
from torch.utils.data import DataLoader

# from debug import info


from convLSTM_dataset import *


# from pytorch-prednet.prednet import PredNet
from torch.utils.data.dataset import random_split


from pytorch_prednet.prednet import PredNet
# from logger import Logger
# logger = Logger('./logs')

import IPython

from torch.utils.data.sampler import SubsetRandomSampler, SequentialSampler


import os

from termcolor import colored


def random_split_customized(dataset, train_ratio=0.9, shuffle_dataset=True):
    random_seed = 41
    # Creating data indices for training and validation splits:
    dataset_size = len(dataset)
    indices = list(range(dataset_size))
    # print indices
    split = int(np.floor(train_ratio * dataset_size))
    # print split
    if shuffle_dataset:
        np.random.seed(random_seed)
        np.random.shuffle(indices)
    # print indices[0:10]
    train_indices, test_indices = indices[:split], indices[split:]

    # Creating PT data samplers and loaders:
    train_sampler = SubsetRandomSampler(train_indices)
    # test_sampler = SubsetRandomSampler(test_indices)
    test_sampler = SequentialSampler(test_indices)

    return train_sampler, test_sampler

def generate_dataloader(path, batch_size, n_class):
    convlstm_dataset = convLSTM_Dataset_dxdy(dataset_dir=path,
                                        n_class=n_class,
                                        transform=transforms.Compose([
                                            RandomHorizontalFlip(),
                                            RandomVerticalFlip(),
                                            ToTensor()])
                                        )

    train_sampler, _ = random_split_customized(convlstm_dataset, train_ratio=0.9)

    train_dataloader = DataLoader(convlstm_dataset, batch_size=batch_size, sampler=train_sampler,
                                  num_workers=4)

    # test set loaded without augmentation
    convlstm_dataset_wo_flip = convLSTM_Dataset_dxdy(dataset_dir=path,
                                        n_class=n_class,
                                        transform=transforms.Compose([
                                            ToTensor()])
                                        )

    print(len(convlstm_dataset))
    # IPython.embed()
    print(convlstm_dataset[1]['frames'].shape)
    _, test_sampler = random_split_customized(convlstm_dataset_wo_flip, train_ratio=0.9)
    test_dataloader = DataLoader(convlstm_dataset_wo_flip, batch_size=batch_size, sampler=test_sampler,
                                 num_workers=4)

    return train_sampler, test_sampler, train_dataloader, test_dataloader

def peek_data(dataloader):
    for step, data in enumerate(dataloader):
        print(step)
        sequence = data['frames'][1]
        fig, axes = plt.subplots(nrows=1, ncols=15, figsize=(10, 4),
                                 sharex=True, sharey=True)
        print(sequence.shape)
        for n in range(0, 15):
            # IPython.embed()
            
            img = sequence[n].cpu().detach().numpy()
            img = np.moveaxis(img, 0, 2)
            img_encoded = vec_color_encoding(img[:, :, 0], img[:, :, 1],encoding='rgb')

            axes[n].imshow(img_encoded)
            # axes[1, n].set_title('ground truth of frame {}'.format(n))
            axes[n].axis('off')
        break
        plt.tight_layout()
        plt.show()


from skimage import data, img_as_float
from skimage.measure import compare_ssim


def image_similarity_metrics(img1, img2):

    # images are with shape of (batch_size, channel, height, width)
    # ========MSE===================
    shape = img1.shape
    if len(shape) == 4:
        B = shape[0]  # batch_size
    numel = shape[-3] * shape[-2] * shape[-1]

    output_matrix = []
    for ind_B in range(0, B):
        im1 = img1[ind_B]
        im2 = img2[ind_B]
        im1 = np.moveaxis(im1, 0, -1)
        im2 = np.moveaxis(im2, 0, -1)

        # IPython.embed()
        l2 = np.linalg.norm((im1 - im2)) ** 2 / numel
        # ========L1====================
        l1 = np.sum(np.abs(im1 - im2)) / numel
        # =======SSIM===================
        ssim = compare_ssim(im1, im2, data_range=img2.max() - img2.min(), multichannel=True)

        output_matrix.append([l1, l2, ssim])

    return np.array(output_matrix)

def construct_metrics_table(values, metrics=['L1', 'L2', 'SSIM']):
    N = len(values)
    n_frames_ahead = range(1, N+1)
    index = list(map(str, n_frames_ahead))
    array1 = np.repeat(n_frames_ahead, 3)
    # array1 = np.concatenate((array1, np.repeat(['Ave'], 3)), axis=0)
    array2 = np.tile(metrics, N)
    # IPython.embed()

    arrays = np.stack((array1, array2))

    tuples = list(zip(*arrays))
    column = pd.MultiIndex.from_tuples(tuples, names=['Future Frame Number', 'Metrics'])

    df = pd.DataFrame(values, index=index, columns=column)
    df.to_csv('metric_results_10patience_l1loss.csv')

import time
from pytorchtools import EarlyStopping

def lr_scheduler(optimizer, epoch, num_epochs):
    if epoch < num_epochs //2:
        return optimizer
    else:
        for param_group in optimizer.param_groups:
            param_group['lr'] = param_group['lr']/2.0
        return optimizer


from pixel_motion_net_vid_pred import PixelMotionNet
def _main(resume=False):
    
    num_epochs = 1
    batch_size = 8
    conv_channels = [32, 64]
    convLSTM_channels = [32, 32]
    upsample_channels = [64, 32]
    n_future = 5

    lr = 0.0001 # if epoch < 75 else 0.0001
    nt = 10 # num of time steps

    print('Instantiate model.............', 'green')
    model = PixelMotionNet(2, conv_channels, convLSTM_channels, upsample_channels, n_future)

    print(repr(model))

    # IPython.embed()
    if torch.cuda.is_available():
        print('sending model to GPU')
        model = model.cuda()


    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=0.02)
    # optimizer = torch.optim.RMSprop(model.parameters(), lr=lr, weight_decay=0.05)
    # define batch_size, channels, height, width
    # batch_size, channels, height, width = 32, 2, 30, 30
    # hidden_size = 32 # 64           # hidden state size
    # lr = 10e-5     # learning rate
    # max_epoch = 1000 # number of epochs

    channels, height, width = 2, 30, 30
    max_epoch = 1000

    dataset_path = '../dataset/resample_skipping_stride1_continuous_case0-4'
    train_sampler, test_sampler, train_dataloader, test_dataloader = generate_dataloader(dataset_path,
                                                                                         batch_size, 
                                                                                         n_class=3)

    # peek_data(test_dataloader)
    
    # IPython.embed()

    train_loss_cache = []
    test_loss_cache = []

    end_epoch = []

    max_frames_ahead = 5
    n_metrics = 3
    metric_table = np.zeros([max_frames_ahead, max_frames_ahead*n_metrics]).astype(str)

    for n_frames_ahead in [5]:
        n_frames = 10 # we fix the input frame size to 10
        print('*************************************************************')
        print('\n =============[Train with n_frames_ahead = {} ================]'.format(n_frames_ahead))
    
        print('Create input and target Variables')
        x = Variable(torch.rand(n_frames, batch_size, channels, height, width))
        # y = Variable(torch.randn(T, b, d, h, w))
        y = Variable(torch.rand(batch_size))
        # IPython.embed()

        print('Create a MSE criterion')
        loss_fn = nn.MSELoss()
        # loss_fn = nn.MSELoss()
        # loss_fn = nn.SmoothL1Loss()
        # optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=0.05)

        # early stopping
        # to track the training loss as the model trains
        train_losses = []
        # to track the validation loss as the model trains
        valid_losses = []
        # to track the average training loss per epoch as the model trains
        avg_train_losses = []
        # to track the average validation loss per epoch as the model trains
        avg_valid_losses = [] 

        # IPython.embed()
        es = EarlyStopping(patience=100, verbose=True)

        if resume:
            model_path_last_train ='./saved_model/pixelmotionnet_20190706_100patience_1000epoch_8BS_case012_additive.pth'
            print(colored('Resume from last check point, start training ...', 'green'))
            model.load_state_dict(torch.load(model_path_last_train))
        else:
            print(colored('Start to train from scratch...', 'blue'))
        # model = model.train()

        print('**************Start to run for {} epochs, Resume from last check point? {} ****************'.format(max_epoch, resume))
        for epoch in range(max_epoch):
            optimizer = lr_scheduler(optimizer, epoch, max_epoch)

            loss_train = 0
            n_right_train = 0

            model = model.train()

            edgePadding = nn.ReplicationPad2d((1,1, 1,1, 0,0))
            # pad_dim = (1,1, 1,1)

            for step, sample_batched in enumerate(train_dataloader):
                # model = model.train()
                loss = 0

                frames = sample_batched['frames']

                # y = sample_batched['target']
                # transpose time sequence and batch (sequence, batch, channel, height, width)
                frames = torch.transpose(frames, 0, 1)

                x = frames[:n_frames]
                y = frames[n_frames:n_frames+n_frames_ahead]
                
                # zero padding to change the image size to 32 x 32
                x = edgePadding(x)
                y = edgePadding(y)
                # print(x.shape)
                # IPython.embed()
                # x = x.type(torch.FloatTensor)
                # print x.size()

                if torch.cuda.is_available():
                    # print 'sending input and target to GPU'
                    x = x.type(torch.cuda.FloatTensor)
                    y = y.type(torch.cuda.FloatTensor)

                state = None
                out = None

                # IPython.embed()
                # print('new step...')
                x = torch.transpose(x, 0, 1) # batch x time_sequence x channels x height x width

                # print(x.size())
                frame_predictions = model(x)

                frame_predictions = torch.transpose(frame_predictions, 0, 1)
                
                loss = 0
                for tt in range(n_frames_ahead):
                    loss += loss_fn(frame_predictions[tt], y[tt])

                # print(errors.shape)
                loc_batch = x.size(0)
                 

                optimizer.zero_grad()

                loss.backward()

                optimizer.step()
                
                loss_train += loss.item() * loc_batch / n_frames_ahead

                train_losses.append(loss.item() / n_frames_ahead)

                Step = 20
                if (step + 1) % Step == 0:
                    loss_train_reduced = loss_train / (Step * loc_batch)
                    loss_train = 0.
                    print(colored('==================================================================', 'green'))
                    print('****** [TRAIN set] Epoch {}, Step {}, Average Loss (every 20 steps): {:.6f} '
                           .format(epoch, step + 1, loss_train_reduced))

            # ================================================================== #
            #                        Validation                                  #
            # ================================================================== #
            print('****** [VALID set]Running through validation set.............')
            model = model.eval()

            loss_test = 0
            for test_step, test_sample_batched in enumerate(test_dataloader):
                loss = 0.

                frames = test_sample_batched['frames']
                # y = test_sample_batched['target']
                frames = torch.transpose(frames, 0, 1)
                # x = x.type(torch.FloatTensor)
                x = frames[:n_frames]
                y = frames[n_frames:]
                # IPython.embed()
                x = edgePadding(x)
                y = edgePadding(y)

                if torch.cuda.is_available():
                    # print 'sending input and target to GPU'
                    x = x.type(torch.cuda.FloatTensor)
                    y = y.type(torch.cuda.FloatTensor)

                state_test = None
                out_test = None


                x = torch.transpose(x, 0, 1)
                frame_predictions = model(x)

                frame_predictions = torch.transpose(frame_predictions, 0, 1)
                
                loss = 0
                for tt in range(n_frames_ahead):
                    loss += loss_fn(frame_predictions[tt], y[tt])

                # print(errors.shape)
                loc_batch = x.size(0)

                loss_test += loss.item() * loc_batch / n_frames_ahead
                valid_losses.append(loss.item() / n_frames_ahead) # append avg loss on each image

            # model_path = './saved_model/convlstm_frame_predict_20190415_400epochs_4000data_flipped_{}f_ahead.pth'.format(n_frames_ahead)
            # torch.save(model.state_dict(), model_path)

            train_loss_cache.append(loss_train_reduced)

            # early stopping
            train_loss = np.average(train_losses)
            valid_loss = np.average(valid_losses)
            avg_train_losses.append(train_loss)
            avg_valid_losses.append(valid_loss)
            # clear lists to track next epoch
            train_losses = []
            valid_losses = []

            model_path ='./saved_model/pixelmotionnet_20190706_100patience_1000epoch_8BS_case012_additive.pth'
            es(valid_loss, model, model_path)
            if es.early_stop:
                print('xxxxxxxxxxxxxxx Early stopping xxxxxxxxxxxxxxxxxxxxxxxxx')
                end_epoch.append(epoch)
                break

            # image_prediction_comparison(n_frames_ahead, test_dataloader, model_path, ifbreak=True)




        print('****************************************************')
        '''
        print('-----Starting the evaluation over the test set.....')
        print('loading model weights from best checkpoint...')
        model.load_state_dict(torch.load(model_path))
        model = model.eval()


        n_metrics = 3
        metric_tmp = np.zeros((len(test_sampler), n_frames_ahead*n_metrics))
        start = time.time()
        loss_test = 0
        for test_step, test_sample_batched in enumerate(test_dataloader):
            loss = 0.

            frames = test_sample_batched['frames']
            # y = test_sample_batched['target']
            frames = torch.transpose(frames, 0, 1)
            # x = x.type(torch.FloatTensor)
            x = frames[:n_frames]
            y = frames[n_frames:]
            # IPython.embed()
            x = edgePadding(x)

            if torch.cuda.is_available():
                # print 'sending input and target to GPU'
                x = x.type(torch.cuda.FloatTensor)
                y = y.type(torch.cuda.FloatTensor)

            state_test = None
            out_test = None


            for t in range(0, n_frames):
                out_test, state_test = model(x[t], state_test)
                # if t in range(0, n_frames)[-n_frames_ahead:]:
                #     # IPython.embed()
                #     loss += loss_fn(out_test, y[n_frames_ahead - (n_frames - t)])
                if t == n_frames - 1:
                    out_test = out_test.view(-1, n_frames_ahead, channels, height, width)
                    out_test = torch.transpose(out_test, 0, 1)
                    # print(out_test.shape)
                    for i in range(n_frames_ahead):
                        loss += loss_fn(out_test[i], y[i])
                        
                        # calculate different metrics
                        metric = image_similarity_metrics(out_test[i].cpu().detach().numpy(), y[i].cpu().detach().numpy())
                        metric_tmp[test_step*batch_size:(test_step+1)*batch_size, 3*i:3*(i+1)] = metric

            # print(y.size())
            current_batch_size = y.size()[1]
            loss_test += loss.item() *  current_batch_size / n_frames_ahead
            # IPython.embed()

        # ---------------------------------

        # print metric_tmp.shape
        mu = np.mean(metric_tmp, axis=0)
        sigma = np.var(metric_tmp, axis=0)
        mu = mu.round(2)
        sigma = sigma.round(2)
        print(mu, sigma)
        # IPython.embed()
        for n in range(0, len(mu)):
            metric_table[n_frames_ahead-1, n] = '{:.2f}+/-{:.2f}'.format(mu[n], sigma[n])

        loss_test_reduced = loss_test / len(test_sampler)
        print ('-----[TEST set] Average MSELoss (over all set): {:.6f}'
               .format(loss_test_reduced))

        gt = y.squeeze()[1][0]
        gt = gt.cpu().detach().numpy()
        out_single = out_test[0].cpu().detach().numpy()

        test_loss_cache.append(loss_test_reduced)

        # IPython.embed()
        # show_two_img(gt, out_single)

    #=======save metric results to file===========
    construct_metrics_table(metric_table)
    

    # random output a comparison of images
    # n_frames_ahead = 1
    # model_path = './saved_model/convlstm_frame_predict_20190513_400epochs_7000data_flipped_{}f_ahead_10patience.pth'.format(n_frames_ahead)
    
    # IPython.embed()
    

    # save end of training epoch
    end_ep = np.array(end_epoch)
    df_ep  = pd.DataFrame(end_ep)
    # df_ep.to_csv('./convlstm_frame_predict_end_1000epoch_L2Loss_32BS.csv')

    # plt.show()
    '''
    image_prediction_comparison(n_frames_ahead, test_dataloader, model_path, ifbreak=False)

import sys
sys.path.remove('/opt/ros/kinetic/lib/python2.7/dist-packages')
import cv2

def vec_color_encoding(x, y, encoding='hsv'):
    if not x.shape == y.shape:
        print('2d vector components should have same shapes.')
        return None
    hsv = np.zeros((x.shape[0], x.shape[1], 3))
    hsv[..., 1] = 255

    mag, ang = cv2.cartToPolar(x, y)

    hsv[...,0] = ang*180/np.pi/2
    # hsv[...,2] = cv2.normalize(mag,None,0,255,cv2.NORM_MINMAX)
    hsv[..., 2] = mag*10
    # hsv[..., 2 ] = 100

    hsv = np.uint8(hsv)
    if encoding == 'hsv':
        return hsv
    elif encoding == 'rgb':
        bgr = cv2.cvtColor(hsv,cv2.COLOR_HSV2RGB)
        return bgr


def image_prediction_comparison(n_frames_ahead, dataloader, model_path, ifbreak=False):
    n_frames = 10
    batch_size, channels, height, width = 16, 2, 30, 30
    
    conv_channels = [32, 64]
    convLSTM_channels = [32, 32]
    upsample_channels = [64, 32]
    n_future = 5

    lr = 0.0005 # if epoch < 75 else 0.0001
    nt = 10 # num of time steps

    print('Instantiate model.............')
    model = PixelMotionNet(2, conv_channels, convLSTM_channels, upsample_channels, n_future)
    print(repr(model))

    # model_path = './saved_model/convlstm_frame_predict_20190415_200epochs_4000data_flipped_{}f_ahead.pth'.format(n_frames_ahead)

    model.load_state_dict(torch.load(model_path))

    if torch.cuda.is_available():
        model = model.cuda()
    
    saving_count = 0 
    edgePadding = nn.ReplicationPad2d((1,1, 1,1, 0,0))
    for test_step, test_sample_batched in enumerate(dataloader):
        loss = 0.

        frames = test_sample_batched['frames']
        # y = test_sample_batched['target']
        frames = torch.transpose(frames, 0, 1)
        # x = x.type(torch.FloatTensor)
        x = frames[:n_frames]
        y = frames[n_frames:]

        start = time.time()

        x = edgePadding(x)
        y = edgePadding(y)

        if torch.cuda.is_available():
            # print 'sending input and target to GPU'
            x = x.type(torch.cuda.FloatTensor)
            y = y.type(torch.cuda.FloatTensor)

        state_test = None
        out_test = None

        image_hat = []
        x = torch.transpose(x, 0, 1)
        frame_predictions = model(x)

        frame_predictions = torch.transpose(frame_predictions, 0, 1)

        image_hat = frame_predictions
        print(image_hat.shape)

        print('Avg time for forwarding', (time.time() - start)/batch_size)
        # print(out_test.shape)
        # random sample from this mini batch
        np.random.seed(10)
        i = np.random.randint(0, batch_size)
        print(i)    

        # IPython.embed()

        fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(10, 10),
                                 sharex=True, sharey=True)
        # ax = axes.ravel()
        # axes = axes.reshape((2,n_frames_ahead))
        axes = axes.ravel()
        # print(axes.shape)
        # print(image_hat[0].shape)
        for i in range(frames.shape[1]):
            for n in range(0, frames.shape[0]):
                # IPython.embed()
                # img_hat = image_hat[n][i].cpu().detach().numpy()
                img = frames[n, i].cpu().detach().numpy()

                # img_hat = np.moveaxis(img_hat, 0, 2)
                img = np.moveaxis(img, 0, 2)

                # IPython.embed()
                # img_hat_encoded = vec_color_encoding(img_hat[:, :, 0], img_hat[:, :, 1],encoding='rgb')
                img_encoded = vec_color_encoding(img[:, :, 0], img[:, :, 1],encoding='rgb')
                axes[n].imshow(img_encoded)
                # axes[0, n].set_title('prediction of frame {}'.format(n))
                axes[n].axis('off')
            
            for l in range(n_frames_ahead):
                img_hat = image_hat[l][i].cpu().detach().numpy()
                img_hat = np.moveaxis(img_hat, 0, 2)

                img_hat_encoded = vec_color_encoding(img_hat[:, :, 0], img_hat[:, :, 1],encoding='rgb')

                axes[15+l].imshow(img_hat_encoded)
                axes[15+l].axis('off')
            
            # save the figure
            print('[Saving predicted images and ground truth No. {}...]'.format(saving_count))
            # plt.show()
            img_dir = './video_prediction/pixelmotionnet_case012_0706_additive'
            if not os.path.exists(img_dir):
                os.makedirs(img_dir)

            plt.savefig(os.path.join(img_dir, '{}.png'.format(saving_count)))
            
            # plt.savefig('./video_prediction/prednet_circulating_L0_case012/{}.png'.format(saving_count))
            saving_count += 1

        if ifbreak:
            break


                


    #     break

    # plt.tight_layout()

    # plt.show()


if __name__ == '__main__':
    _main(resume=False)




