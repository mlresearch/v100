import torch
from torch import nn
import torch.nn.functional as f
from torch.autograd import Variable
import torch

import os

# Define some constants
KERNEL_SIZE = 3
PADDING = KERNEL_SIZE // 2


class ConvLSTMCell(nn.Module):
    """
    Generate a convolutional LSTM cell
    """

    def __init__(self, input_size, hidden_size, n_frames_ahead):
        super(ConvLSTMCell, self).__init__()
        self.input_size = input_size
        self.n_frames_ahead = n_frames_ahead
        self.hidden_size = hidden_size
        self.Gates_layer1 = nn.Conv2d(input_size + hidden_size, 4 * hidden_size, KERNEL_SIZE, padding=PADDING)

        self.Gates_layer2 = nn.Conv2d(2*hidden_size, 4*hidden_size, KERNEL_SIZE, padding=PADDING)

        self.height, self.width = 30, 30

        self.Shrink = nn.Conv2d(hidden_size, self.input_size*n_frames_ahead, KERNEL_SIZE, padding=PADDING)

    def forward(self, input_, prev_state):

        # get batch and spatial sizes
        batch_size = input_.data.size()[0]
        spatial_size = input_.data.size()[2:]

        # print spatial_size

        # generate empty prev_state, if None is provided
        if prev_state is None:
            state_size1 = [batch_size, self.hidden_size] + list(spatial_size)  # (B,Hidden_size, H, W)
            prev_state1 = (
                Variable(torch.zeros(state_size1)).type(torch.cuda.FloatTensor),
                Variable(torch.zeros(state_size1)).type(torch.cuda.FloatTensor)
            )  # list of h[t-1] and C[t-1]: both of size [batch_size, hidden_size, D, D]

            # =======layer2 lstm previous states
            state_size2 = [batch_size, self.hidden_size] + list(spatial_size)

            prev_state2 = (
                Variable(torch.zeros(state_size2)).type(torch.cuda.FloatTensor),
                Variable(torch.zeros(state_size2)).type(torch.cuda.FloatTensor)
            )  # list of h[t-1] and C[t-1]: both of size [batch_size, hidden_size, D, D]

            prev_state = (prev_state1, prev_state2)

        prev_state1, prev_state2 = prev_state
        prev_hidden1, prev_cell1 = prev_state1
        prev_hidden2, prev_cell2 = prev_state2

        # data size is [batch, channel, height, width]
        # print input_.type(), prev_hidden.type()
        # IPython.embed()
        stacked_inputs = torch.cat((input_, prev_hidden1), 1)  # concat x[t] with h[t-1]
        gates = self.Gates_layer1(stacked_inputs)

        # chunk across channel dimension
        in_gate, remember_gate, out_gate, cell_gate = gates.chunk(4, 1)

        # apply sigmoid non linearity
        in_gate = torch.sigmoid(in_gate)
        remember_gate = torch.sigmoid(remember_gate)
        out_gate = torch.sigmoid(out_gate)

        # apply tanh non linearity
        cell_gate = torch.tanh(cell_gate)
        # print cell_gate.shape

        # compute current cell and hidden state
        cell1 = (remember_gate * prev_cell1) + (in_gate * cell_gate)
        hidden1 = out_gate * torch.tanh(cell1)

        # print hidden.size()
        # conv2 = self.Conv(hidden)
        # flat = conv2.view(-1, conv2.size(1) * conv2.size(2) * conv2.size(3))

        # =============layer 2 gates operation =================================
        # feed hidden state from layer 1 to layer 2 as input
        stacked_inputs2 = torch.cat((hidden1, prev_hidden2), 1)  # concat x[t] with h[t-1]
        gates2 = self.Gates_layer2(stacked_inputs2)

        # chunk across channel dimension
        in_gate2, remember_gate2, out_gate2, cell_gate2 = gates2.chunk(4, 1)

        # apply sigmoid non linearity
        in_gate2 = torch.sigmoid(in_gate2)
        remember_gate2 = torch.sigmoid(remember_gate2)
        out_gate2 = torch.sigmoid(out_gate2)

        # apply tanh non linearity
        cell_gate2 = torch.tanh(cell_gate2)
        # print cell_gate.shape

        # compute current cell and hidden state
        cell2 = (remember_gate2 * prev_cell2) + (in_gate2 * cell_gate2)
        hidden2 = out_gate2 * torch.tanh(cell2)

        # flat = hidden2.view(-1, hidden2.size(1)*hidden2.size(2)*hidden2.size(3))
        # # print flat.size()
        # out = self.linear(flat)
        # out = self.dropout(out)

        out = self.Shrink(hidden2)

        # print(out.shape)

        # print out.shape
        # out = out.view(-1, self.n_frames_ahead, self.input_size, self.height, self.width)
        # print out.shape
        # out = torch.transpose(out, 0, 1)

        return out, ((hidden1, cell1), (hidden2, cell2))



from convLSTM_dataset import *
from torch.utils.data import DataLoader

from torch.utils.data.dataset import random_split

# from logger import Logger
# logger = Logger('./logs')

import IPython

from torch.utils.data.sampler import SubsetRandomSampler, SequentialSampler


def random_split_customized(dataset, train_ratio=0.9, shuffle_dataset=True):
    random_seed = 41
    # Creating data indices for training and validation splits:
    dataset_size = len(dataset)
    indices = list(range(dataset_size))
    # print indices
    split = int(np.floor(train_ratio * dataset_size))
    # print split
    if shuffle_dataset:
        np.random.seed(random_seed)
        np.random.shuffle(indices)
    # print indices[0:10]
    train_indices, test_indices = indices[:split], indices[split:]

    # Creating PT data samplers and loaders:
    train_sampler = SubsetRandomSampler(train_indices)
    test_sampler = SequentialSampler(test_indices)

    return train_sampler, test_sampler

def generate_dataloader(path, batch_size, n_class):
    convlstm_dataset = convLSTM_Dataset_dxdy(dataset_dir=path,
                                        n_class=n_class,
                                        transform=transforms.Compose([
                                            RandomHorizontalFlip(),
                                            RandomVerticalFlip(),
                                            ToTensor()])
                                        )

    train_sampler, _ = random_split_customized(convlstm_dataset, train_ratio=0.9)

    train_dataloader = DataLoader(convlstm_dataset, batch_size=batch_size, sampler=train_sampler,
                                  num_workers=4)

    # test set loaded without augmentation
    convlstm_dataset_wo_flip = convLSTM_Dataset_dxdy(dataset_dir=path,
                                        n_class=n_class,
                                        transform=transforms.Compose([
                                            ToTensor()])
                                        )

    print(len(convlstm_dataset))
    # IPython.embed()
    print(convlstm_dataset[1]['frames'].shape)
    _, test_sampler = random_split_customized(convlstm_dataset_wo_flip, train_ratio=0.9)
    test_dataloader = DataLoader(convlstm_dataset, batch_size=batch_size, sampler=test_sampler,
                                 num_workers=4)

    return train_sampler, test_sampler, train_dataloader, test_dataloader

def peek_data(dataloader):
    for step, data in enumerate(dataloader):
        print(step)
        sequence = data['frames'][1]
        fig, axes = plt.subplots(nrows=1, ncols=15, figsize=(10, 4),
                                 sharex=True, sharey=True)
        print(sequence.shape)
        for n in range(0, 15):
            # IPython.embed()
            
            img = sequence[n].cpu().detach().numpy()
            img = np.moveaxis(img, 0, 2)
            img_encoded = vec_color_encoding(img[:, :, 0], img[:, :, 1],encoding='rgb')

            axes[n].imshow(img_encoded)
            # axes[1, n].set_title('ground truth of frame {}'.format(n))
            axes[n].axis('off')
        break
        plt.tight_layout()
        plt.show()


from skimage import data, img_as_float
from skimage.measure import compare_ssim


def image_similarity_metrics(img1, img2):

    # images are with shape of (batch_size, channel, height, width)
    # ========MSE===================
    shape = img1.shape
    if len(shape) == 4:
        B = shape[0]  # batch_size
    numel = shape[-3] * shape[-2] * shape[-1]

    output_matrix = []
    for ind_B in range(0, B):
        im1 = img1[ind_B]
        im2 = img2[ind_B]
        im1 = np.moveaxis(im1, 0, -1)
        im2 = np.moveaxis(im2, 0, -1)

        # IPython.embed()
        l2 = np.linalg.norm((im1 - im2)) ** 2 / numel
        # ========L1====================
        l1 = np.sum(np.abs(im1 - im2)) / numel
        # =======SSIM===================
        ssim = compare_ssim(im1, im2, data_range=img2.max() - img2.min(), multichannel=True)

        output_matrix.append([l1, l2, ssim])

    return np.array(output_matrix)

def construct_metrics_table(values, metrics=['L1', 'L2', 'SSIM']):
    N = len(values)
    n_frames_ahead = range(1, N+1)
    index = list(map(str, n_frames_ahead))
    array1 = np.repeat(n_frames_ahead, 3)
    # array1 = np.concatenate((array1, np.repeat(['Ave'], 3)), axis=0)
    array2 = np.tile(metrics, N)
    # IPython.embed()

    arrays = np.stack((array1, array2))

    tuples = list(zip(*arrays))
    column = pd.MultiIndex.from_tuples(tuples, names=['Future Frame Number', 'Metrics'])

    df = pd.DataFrame(values, index=index, columns=column)
    df.to_csv('metric_results_10patience_l1loss.csv')

import time
from pytorchtools import EarlyStopping


def _main():
    
    # define batch_size, channels, height, width
    batch_size, channels, height, width = 32, 2, 30, 30
    hidden_size = 32 # 64           # hidden state size
    lr = 10e-5     # learning rate
    max_epoch = 500 # number of epochs

    dataset_path = '../dataset/resample_skipping_stride1_continuous_case0-4'
    train_sampler, test_sampler, train_dataloader, test_dataloader = generate_dataloader(dataset_path, 
                                                                                        batch_size,
                                                                                        n_class=3)

    # peek_data(test_dataloader)
    
    # IPython.embed()
    
    
    train_loss_cache = []
    test_loss_cache = []

    end_epoch = []

    max_frames_ahead = 5
    n_metrics = 3
    metric_table = np.zeros([max_frames_ahead, max_frames_ahead*n_metrics]).astype(str)
    # train with different values of n_frames_ahead to see the performance
    # for n_frames_ahead in range(1, 6):
    for n_frames_ahead in [5]:
        n_frames = 10 # we fix the input frame size to 10
        print('*************************************************************')
        print('\n =============[Train with n_frames_ahead = {} ================]'.format(n_frames_ahead))
        print('Instantiate model.............')
        model = ConvLSTMCell(channels, hidden_size, n_frames_ahead)
        print(repr(model))

        if torch.cuda.is_available():
            # print 'sending model to GPU'
            model = model.cuda()

        print('Create input and target Variables')
        x = Variable(torch.rand(n_frames, batch_size, channels, height, width))
        # y = Variable(torch.randn(T, b, d, h, w))
        y = Variable(torch.rand(batch_size))
        # IPython.embed()

        print('Create a MSE criterion')
        loss_fn = nn.MSELoss()
        # loss_fn = nn.SmoothL1Loss()
        optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=0.05)

        # early stopping
        # to track the training loss as the model trains
        train_losses = []
        # to track the validation loss as the model trains
        valid_losses = []
        # to track the average training loss per epoch as the model trains
        avg_train_losses = []
        # to track the average validation loss per epoch as the model trains
        avg_valid_losses = [] 

        # IPython.embed()
        es = EarlyStopping(patience=10, verbose=True)

        
        # -----------------------------------------------------------
        print('Start the training, Running for', max_epoch, 'epochs with early stopping(patience=10epochs)')
        for epoch in range(0, max_epoch):
            loss_train = 0
            n_right_train = 0

            model = model.train()
            for step, sample_batched in enumerate(train_dataloader):
                # model = model.train()
                loss = 0

                frames = sample_batched['frames']

                # y = sample_batched['target']
                # transpose time sequence and batch (sequence, batch, channel, height, width)
                frames = torch.transpose(frames, 0, 1)

                x = frames[:n_frames]
                y = frames[n_frames:n_frames+n_frames_ahead]
                # IPython.embed()
                # x = x.type(torch.FloatTensor)
                # print x.size()

                if torch.cuda.is_available():
                    # print 'sending input and target to GPU'
                    x = x.type(torch.cuda.FloatTensor)
                    y = y.type(torch.cuda.FloatTensor)

                state = None
                out = None

                # IPython.embed()
                # print('new step...')
                for t in range(0, n_frames):
                    # print x[t,0,0,:,:]
                    # print('run run ', t)
                    out, state = model(x[t], state)
                    # if t in range(0, n_frames)[-n_frames_ahead:]:
                    #     # IPython.embed()
                    #     loss += loss_fn(out, y[n_frames_ahead - (n_frames - t)])
                    if t == n_frames - 1:
                        out = out.view(-1, n_frames_ahead, channels, height, width)
                        out = torch.transpose(out, 0, 1)
                        for i in range(n_frames_ahead):
                            loss += loss_fn(out[i], y[i])



                # reduce loss to be loss on single frame discrepancy/loss

                # zero grad parameters
                model.zero_grad()

                # compute new grad parameters through time!
                loss.backward()
                optimizer.step()

                loss_train += loss.item() * batch_size / n_frames_ahead

                train_losses.append(loss.item())

                Step = 20
                if (step + 1) % Step == 0:
                    loss_train_reduced = loss_train / (Step * batch_size)
                    loss_train = 0.
                    print('         ==================================================================')
                    print('        [TRAIN set] Epoch {}, Step {}, Average Loss (every 20 steps): {:.6f}'
                           .format(epoch, step + 1, loss_train_reduced))

            # ================================================================== #
            #                        Validation                                  #
            # ================================================================== #
            print('~~~~run through validation set.............')
            model = model.eval()

            loss_test = 0
            for test_step, test_sample_batched in enumerate(test_dataloader):
                loss = 0.

                frames = test_sample_batched['frames']
                # y = test_sample_batched['target']
                frames = torch.transpose(frames, 0, 1)
                # x = x.type(torch.FloatTensor)
                x = frames[:n_frames]
                y = frames[n_frames:]
                # IPython.embed()

                if torch.cuda.is_available():
                    # print 'sending input and target to GPU'
                    x = x.type(torch.cuda.FloatTensor)
                    y = y.type(torch.cuda.FloatTensor)

                state_test = None
                out_test = None

                # print('new step...', state_test, out_test)
                for t in range(0, n_frames):
                    # print('run run ', t)
                    out_test, state_test = model(x[t], state_test)
                    # if t in range(0, n_frames)[-n_frames_ahead:]:
                    #     # IPython.embed()
                    #     loss += loss_fn(out_test, y[n_frames_ahead - (n_frames - t)])
                    if t == n_frames - 1:
                        out_test = out_test.view(-1, n_frames_ahead, channels, height, width)
                        out_test = torch.transpose(out_test, 0, 1)
                        for i in range(n_frames_ahead):
                            loss += loss_fn(out_test[i], y[i])


                loss_test += loss.item() * batch_size / n_frames_ahead

                valid_losses.append(loss.item()/n_frames_ahead) # append avg loss on each image

            # model_path = './saved_model/convlstm_frame_predict_20190415_400epochs_4000data_flipped_{}f_ahead.pth'.format(n_frames_ahead)
            # torch.save(model.state_dict(), model_path)

            train_loss_cache.append(loss_train_reduced)

            # early stopping
            train_loss = np.average(train_losses)
            valid_loss = np.average(valid_losses)
            avg_train_losses.append(train_loss)
            avg_valid_losses.append(valid_loss)
            # clear lists to track next epoch
            train_losses = []
            valid_losses = []

            model_path ='./saved_model/convlstm_frame_predict_20190626_L2loss_earlystopping_7000data_flipped_{}f_ahead_10patience_1000epoch_32BS.pth'.format(n_frames_ahead)
            es(valid_loss, model, model_path)
            if es.early_stop:
                print('early stopping')
                end_epoch.append(epoch)
                break
            if epoch == max_epoch:
                end_epoch.append(epoch)

        
        print('****************************************************')
        print('-----Starting the evaluation over the test set.....')
        print('loading model weights from best checkpoint...')
        model.load_state_dict(torch.load(model_path))
        model = model.eval()


        n_metrics = 3
        metric_tmp = np.zeros((len(test_sampler), n_frames_ahead*n_metrics))
        start = time.time()
        loss_test = 0
        for test_step, test_sample_batched in enumerate(test_dataloader):
            loss = 0.

            frames = test_sample_batched['frames']
            # y = test_sample_batched['target']
            frames = torch.transpose(frames, 0, 1)
            # x = x.type(torch.FloatTensor)
            x = frames[:n_frames]
            y = frames[n_frames:]
            # IPython.embed()

            if torch.cuda.is_available():
                # print 'sending input and target to GPU'
                x = x.type(torch.cuda.FloatTensor)
                y = y.type(torch.cuda.FloatTensor)

            state_test = None
            out_test = None


            for t in range(0, n_frames):
                out_test, state_test = model(x[t], state_test)
                # if t in range(0, n_frames)[-n_frames_ahead:]:
                #     # IPython.embed()
                #     loss += loss_fn(out_test, y[n_frames_ahead - (n_frames - t)])
                if t == n_frames - 1:
                    out_test = out_test.view(-1, n_frames_ahead, channels, height, width)
                    out_test = torch.transpose(out_test, 0, 1)
                    # print(out_test.shape)
                    for i in range(n_frames_ahead):
                        loss += loss_fn(out_test[i], y[i])
                        
                        # calculate different metrics
                        metric = image_similarity_metrics(out_test[i].cpu().detach().numpy(), y[i].cpu().detach().numpy())
                        metric_tmp[test_step*batch_size:(test_step+1)*batch_size, 3*i:3*(i+1)] = metric

            # print(y.size())
            current_batch_size = y.size()[1]
            loss_test += loss.item() *  current_batch_size / n_frames_ahead
            # IPython.embed()

        # ---------------------------------

        # print metric_tmp.shape
        mu = np.mean(metric_tmp, axis=0)
        sigma = np.var(metric_tmp, axis=0)
        mu = mu.round(2)
        sigma = sigma.round(2)
        print(mu, sigma)
        # IPython.embed()
        for n in range(0, len(mu)):
            metric_table[n_frames_ahead-1, n] = '{:.2f}+/-{:.2f}'.format(mu[n], sigma[n])

        loss_test_reduced = loss_test / len(test_sampler)
        print ('-----[TEST set] Average MSELoss (over all set): {:.6f}'
               .format(loss_test_reduced))

        gt = y.squeeze()[1][0]
        gt = gt.cpu().detach().numpy()
        out_single = out_test[0].cpu().detach().numpy()

        test_loss_cache.append(loss_test_reduced)

        # IPython.embed()
        # show_two_img(gt, out_single)

    #=======save metric results to file===========
    construct_metrics_table(metric_table)
    

    # random output a comparison of images
    # n_frames_ahead = 1
    # model_path = './saved_model/convlstm_frame_predict_20190513_400epochs_7000data_flipped_{}f_ahead_10patience.pth'.format(n_frames_ahead)
    image_prediction_comparison(n_frames_ahead, test_dataloader, model_path)
    # IPython.embed()
    

    # save end of training epoch
    end_ep = np.array(end_epoch)
    df_ep  = pd.DataFrame(end_ep)
    df_ep.to_csv('./convlstm_frame_predict_end_1000epoch_L2Loss_32BS.csv')

    plt.show()


import sys
sys.path.remove('/opt/ros/kinetic/lib/python2.7/dist-packages')
import cv2

def vec_color_encoding(x, y, encoding='hsv'):
    if not x.shape == y.shape:
        print('2d vector components should have same shapes.')
        return None
    hsv = np.zeros((x.shape[0], x.shape[1], 3))
    hsv[..., 1] = 255

    mag, ang = cv2.cartToPolar(x, y)

    hsv[...,0] = ang*180/np.pi/2
    # hsv[...,2] = cv2.normalize(mag,None,0,255,cv2.NORM_MINMAX)
    hsv[..., 2] = mag*10

    hsv = np.uint8(hsv)
    if encoding == 'hsv':
        return hsv
    elif encoding == 'rgb':
        bgr = cv2.cvtColor(hsv,cv2.COLOR_HSV2RGB)
        return bgr


def image_prediction_comparison(n_frames_ahead, dataloader, model_path):
    n_frames = 10
    batch_size, channels, height, width = 32, 2, 30, 30
    hidden_size = 32
    print('Instantiating model...')
    model = ConvLSTMCell(channels, hidden_size, n_frames_ahead)
    print(repr(model))

    # model_path = './saved_model/convlstm_frame_predict_20190415_200epochs_4000data_flipped_{}f_ahead.pth'.format(n_frames_ahead)

    model.load_state_dict(torch.load(model_path))

    if torch.cuda.is_available():
        model = model.cuda()
    saving_count = 0 
    for test_step, test_sample_batched in enumerate(dataloader):
        loss = 0.

        frames = test_sample_batched['frames']
        # y = test_sample_batched['target']
        frames = torch.transpose(frames, 0, 1)
        # x = x.type(torch.FloatTensor)
        x = frames[:n_frames]
        y = frames[n_frames:]

        start = time.time()

        if torch.cuda.is_available():
            # print 'sending input and target to GPU'
            x = x.type(torch.cuda.FloatTensor)
            y = y.type(torch.cuda.FloatTensor)

        state_test = None
        out_test = None

        image_hat = []
        for t in range(0, n_frames):
            out_test, state_test = model(x[t], state_test)
            # if t in range(0, n_frames)[-1:]:
            #     image_hat.append(out_test)

        image_hat = out_test.view(-1, n_frames_ahead, channels, height, width)
        image_hat = torch.transpose(image_hat, 0, 1)
        print(image_hat.shape)

        print('Avg time for forwarding', (time.time() - start)/batch_size)
        # print(out_test.shape)
        # random sample from this mini batch
        np.random.seed(10)
        i = np.random.randint(0, batch_size)
        print(i)    

        fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(10, 10),
                                 sharex=True, sharey=True)
        # ax = axes.ravel()
        # axes = axes.reshape((2,n_frames_ahead))
        axes = axes.ravel()
        # print(axes.shape)
        # print(image_hat[0].shape)
        for i in range(frames.shape[1]):
            for n in range(0, frames.shape[0]):
                # IPython.embed()
                # img_hat = image_hat[n][i].cpu().detach().numpy()
                img = frames[n, i].cpu().detach().numpy()

                # img_hat = np.moveaxis(img_hat, 0, 2)
                img = np.moveaxis(img, 0, 2)

                # IPython.embed()
                # img_hat_encoded = vec_color_encoding(img_hat[:, :, 0], img_hat[:, :, 1],encoding='rgb')
                img_encoded = vec_color_encoding(img[:, :, 0], img[:, :, 1],encoding='rgb')
                axes[n].imshow(img_encoded)
                # axes[0, n].set_title('prediction of frame {}'.format(n))
                axes[n].axis('off')
            
            for l in range(n_frames_ahead):
                img_hat = image_hat[l][i].cpu().detach().numpy()
                img_hat = np.moveaxis(img_hat, 0, 2)

                img_hat_encoded = vec_color_encoding(img_hat[:, :, 0], img_hat[:, :, 1],encoding='rgb')

                axes[15+l].imshow(img_hat_encoded)
                axes[15+l].axis('off')
            
            # save the figure
            print('[Saving predicted images and ground truth No. {}...]'.format(saving_count))
            # plt.show()
            img_dir ='./video_prediction/no_circulating_case012' 
            if not os.path.exists(img_dir):
                os.makedirs(img_dir)
            plt.savefig(os.path.join(img_dir, '{}.png'.format(saving_count)))
            saving_count += 1

        # break


                


    #     break

    # plt.tight_layout()

    # plt.show()


if __name__ == '__main__':
    _main()
