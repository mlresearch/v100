import os

import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as f
from torch.utils.data import DataLoader

# from debug import info


from convLSTM_dataset import *


# from pytorch-prednet.prednet import PredNet
from torch.utils.data.dataset import random_split


from pytorch_prednet.prednet import PredNet
# from logger import Logger
# logger = Logger('./logs')

import IPython

from torch.utils.data.sampler import SubsetRandomSampler, SequentialSampler


import os

from termcolor import colored


def random_split_customized(dataset, train_ratio=0.9, shuffle_dataset=True):
    random_seed = 41
    # Creating data indices for training and validation splits:
    dataset_size = len(dataset)
    indices = list(range(dataset_size))
    # print indices
    split = int(np.floor(train_ratio * dataset_size))
    # print split
    if shuffle_dataset:
        np.random.seed(random_seed)
        np.random.shuffle(indices)
    # print indices[0:10]
    train_indices, test_indices = indices[:split], indices[split:]

    # Creating PT data samplers and loaders:
    train_sampler = SubsetRandomSampler(train_indices)
    # test_sampler = SubsetRandomSampler(test_indices)
    test_sampler = SequentialSampler(test_indices)

    return train_sampler, test_sampler

def generate_dataloader(path, batch_size, n_class):
    convlstm_dataset = convLSTM_Dataset_dxdy(dataset_dir=path,
                                        n_class=n_class,
                                        transform=transforms.Compose([
                                            RandomHorizontalFlip(),
                                            RandomVerticalFlip(),
                                            ToTensor()])
                                        )

    train_sampler, _ = random_split_customized(convlstm_dataset, train_ratio=0.9)

    train_dataloader = DataLoader(convlstm_dataset, batch_size=batch_size, sampler=train_sampler,
                                  num_workers=4)

    # test set loaded without augmentation
    convlstm_dataset_wo_flip = convLSTM_Dataset_dxdy(dataset_dir=path,
                                        n_class=n_class,
                                        transform=transforms.Compose([
                                            ToTensor()])
                                        )

    print(len(convlstm_dataset))
    # IPython.embed()
    print(convlstm_dataset[1]['frames'].shape)
    _, test_sampler = random_split_customized(convlstm_dataset_wo_flip, train_ratio=0.9)
    test_dataloader = DataLoader(convlstm_dataset_wo_flip, batch_size=batch_size, sampler=test_sampler,
                                 num_workers=4)

    return train_sampler, test_sampler, train_dataloader, test_dataloader

def peek_data(dataloader):
    for step, data in enumerate(dataloader):
        print(step)
        sequence = data['frames'][1]
        fig, axes = plt.subplots(nrows=1, ncols=15, figsize=(10, 4),
                                 sharex=True, sharey=True)
        print(sequence.shape)
        for n in range(0, 15):
            # IPython.embed()
            
            img = sequence[n].cpu().detach().numpy()
            img = np.moveaxis(img, 0, 2)
            img_encoded = vec_color_encoding(img[:, :, 0], img[:, :, 1],encoding='rgb')

            axes[n].imshow(img_encoded)
            # axes[1, n].set_title('ground truth of frame {}'.format(n))
            axes[n].axis('off')
        break
        plt.tight_layout()
        plt.show()


from skimage import data, img_as_float
from skimage.measure import compare_ssim


def image_similarity_metrics(img1, img2):

    # images are with shape of (batch_size, channel, height, width)
    # ========MSE===================
    shape = img1.shape
    if len(shape) == 4:
        B = shape[0]  # batch_size
    numel = shape[-3] * shape[-2] * shape[-1]

    output_matrix = []
    for ind_B in range(0, B):
        im1 = img1[ind_B]
        im2 = img2[ind_B]
        im1 = np.moveaxis(im1, 0, -1)
        im2 = np.moveaxis(im2, 0, -1)

        # IPython.embed()
        l2 = np.linalg.norm((im1 - im2)) ** 2 / numel
        # ========L1====================
        l1 = np.sum(np.abs(im1 - im2)) / numel
        # =======SSIM===================
        ssim = compare_ssim(im1, im2, data_range=img2.max() - img2.min(), multichannel=True)

        output_matrix.append([l1, l2, ssim])

    return np.array(output_matrix)

def construct_metrics_table(values, metrics=['L1', 'L2', 'SSIM']):
    N = len(values)
    n_frames_ahead = range(1, N+1)
    index = list(map(str, n_frames_ahead))
    array1 = np.repeat(n_frames_ahead, 3)
    # array1 = np.concatenate((array1, np.repeat(['Ave'], 3)), axis=0)
    array2 = np.tile(metrics, N)
    # IPython.embed()

    arrays = np.stack((array1, array2))

    tuples = list(zip(*arrays))
    column = pd.MultiIndex.from_tuples(tuples, names=['Future Frame Number', 'Metrics'])

    df = pd.DataFrame(values, index=index, columns=column)
    df.to_csv('metric_results_10patience_l1loss.csv')



from pixel_motion_net_vid_pred import PixelMotionNet


def pixelMotionNetEval():

    # channels, height, width = 2, 30, 30
    # max_epoch = 1000
    


    n_frames = 10
    batch_size, channels, height, width = 16, 2, 30, 30
    
    conv_channels = [32, 64]
    convLSTM_channels = [32, 32]
    upsample_channels = [64, 32]
    n_future = 5

    lr = 0.0005 # if epoch < 75 else 0.0001
    nt = 10 # num of time steps

    dataset_path = '../dataset/resample_skipping_stride1_continuous_case0-4'
    train_sampler, test_sampler, train_dataloader, test_dataloader = generate_dataloader(dataset_path,
                                                                                         batch_size, 
                                                                                         n_class=3)
    
    
    n_metrics = 3
    # metric_table = np.zeros([n_future, max_frames_ahead*n_metrics]).astype(str)

    metric_tmp = np.zeros((len(test_sampler), n_future*n_metrics))


    print('Instantiate model.............')
    model = PixelMotionNet(2, conv_channels, convLSTM_channels, upsample_channels, n_future)
    print(repr(model))

    # model_path = './saved_model/convlstm_frame_predict_20190415_200epochs_4000data_flipped_{}f_ahead.pth'.format(n_frames_ahead)
    model_path = './saved_model/pixelmotionnet_20190706_100patience_1000epoch_8BS_case012_additive.pth'
    model.load_state_dict(torch.load(model_path))

    if torch.cuda.is_available():
        model = model.cuda()
    
    saving_count = 0 
    edgePadding = nn.ReplicationPad2d((1,1, 1,1, 0,0))

    for test_step, test_sample_batched in enumerate(test_dataloader):
        loss = 0.

        frames = test_sample_batched['frames']
        # y = test_sample_batched['target']
        frames = torch.transpose(frames, 0, 1)
        # x = x.type(torch.FloatTensor)
        x = frames[:n_frames]
        y = frames[n_frames:]
        

        # start = time.time()

        x = edgePadding(x)
        y = edgePadding(y)

        if torch.cuda.is_available():
            # print 'sending input and target to GPU'
            x = x.type(torch.cuda.FloatTensor)
            y = y.type(torch.cuda.FloatTensor)

        state_test = None
        out_test = None

        image_hat = []
        x = torch.transpose(x, 0, 1)
        frame_predictions = model(x)

        frame_predictions = torch.transpose(frame_predictions, 0, 1)

        # print(frame_predictions.shape)
        local_bs = frame_predictions.shape[1]

        for i in range(n_future):
            metric = image_similarity_metrics(frame_predictions[i].cpu().detach().numpy(), y[i].cpu().detach().numpy())
            metric_tmp[test_step*batch_size: test_step*batch_size + local_bs, 3*i:3*(i+1)] = metric
        
    mu = np.mean(metric_tmp, axis=0)
    sigma = np.var(metric_tmp, axis=0)
    print(mu)
    print(sigma)



def predNetEval():

    n_frames = 10
    batch_size, channels, height, width = 16, 2, 30, 30
    hidden_size = 32

    A_channels = (2, 48, 96)
    R_channels = (2, 48, 96)
    n_future = 5

    lr = 0.0005 # if epoch < 75 else 0.0001
    nt = 10 # num of time steps

    dataset_path = '../dataset/resample_skipping_stride1_continuous_case0-4'
    train_sampler, test_sampler, train_dataloader, test_dataloader = generate_dataloader(dataset_path,
                                                                                         batch_size, 
                                                                                         n_class=3)
    n_metrics = 3
    # metric_table = np.zeros([n_future, max_frames_ahead*n_metrics]).astype(str)

    metric_tmp = np.zeros((len(test_sampler), n_future*n_metrics))

    print('Instantiating model...')
    from pytorch_prednet.prednet import PredNetCirculating

    model = PredNetCirculating(R_channels, A_channels, 10, 5, output_mode='prediction')
    print(repr(model))

    # model_path = './saved_model/convlstm_frame_predict_20190415_200epochs_4000data_flipped_{}f_ahead.pth'.format(n_frames_ahead)
    model_path = './saved_model/prednet_20190626_10patience_1000epoch_8BS_circulating_L0_case012.pth'
    model.load_state_dict(torch.load(model_path))

    if torch.cuda.is_available():
        model = model.cuda()
    
    saving_count = 0 
    edgePadding = nn.ReplicationPad2d((1,1, 1,1, 0,0))
    for test_step, test_sample_batched in enumerate(test_dataloader):
        loss = 0.

        frames = test_sample_batched['frames']
        # y = test_sample_batched['target']
        frames = torch.transpose(frames, 0, 1)
        # x = x.type(torch.FloatTensor)
        x = frames[:n_frames]
        y = frames[n_frames:]

        # start = time.time()

        x = edgePadding(x)
        y = edgePadding(y)

        if torch.cuda.is_available():
            # print 'sending input and target to GPU'
            x = x.type(torch.cuda.FloatTensor)
            y = y.type(torch.cuda.FloatTensor)

        state_test = None
        out_test = None

        image_hat = []
        x = torch.transpose(x, 0, 1)
        frame_predictions = model(x)

        frame_predictions = torch.transpose(frame_predictions, 0, 1)

        # print(frame_predictions.shape)
        local_bs = frame_predictions.shape[1]

        for i in range(n_future):
            metric = image_similarity_metrics(frame_predictions[i].cpu().detach().numpy(), y[i].cpu().detach().numpy())
            metric_tmp[test_step*batch_size: test_step*batch_size + local_bs, 3*i:3*(i+1)] = metric
        
    mu = np.mean(metric_tmp, axis=0)
    sigma = np.var(metric_tmp, axis=0)
    print(mu)
    print(sigma)


def copyLastFrame():
    n_frames = 10
    n_future = 5
    batch_size, channels, height, width = 16, 2, 30, 30

    dataset_path = '../dataset/resample_skipping_stride1_continuous_case0-4'
    train_sampler, test_sampler, train_dataloader, test_dataloader = generate_dataloader(dataset_path,
                                                                                         batch_size, 
                                                                                         n_class=3)
    n_metrics = 3
    # metric_table = np.zeros([n_future, max_frames_ahead*n_metrics]).astype(str)

    metric_tmp = np.zeros((len(test_sampler), n_future*n_metrics))

    
    saving_count = 0 
    edgePadding = nn.ReplicationPad2d((1,1, 1,1, 0,0))
    for test_step, test_sample_batched in enumerate(test_dataloader):
        loss = 0.

        frames = test_sample_batched['frames']
        # y = test_sample_batched['target']
        frames = torch.transpose(frames, 0, 1)
        # x = x.type(torch.FloatTensor)
        x = frames[:n_frames]
        y = frames[n_frames:]

        # start = time.time()

        x = edgePadding(x)
        y = edgePadding(y)

        if torch.cuda.is_available():
            # print 'sending input and target to GPU'
            x = x.type(torch.cuda.FloatTensor)
            y = y.type(torch.cuda.FloatTensor)

        local_bs = y.shape[1]

        for i in range(n_future):
            metric = image_similarity_metrics(x[n_frames - 1].cpu().detach().numpy(), y[i].cpu().detach().numpy())
            metric_tmp[test_step*batch_size: test_step*batch_size + local_bs, 3*i:3*(i+1)] = metric
        
    mu = np.mean(metric_tmp, axis=0)
    sigma = np.var(metric_tmp, axis=0)
    print(mu)
    print(sigma)
    
        
if __name__ == '__main__':
    # pixelMotionNetEval()
    # predNetEval()
    copyLastFrame()