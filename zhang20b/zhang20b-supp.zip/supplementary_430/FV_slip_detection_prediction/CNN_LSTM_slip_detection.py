import torch
from torch import nn
import torch.nn.functional as f
from torch.autograd import Variable
import torch


# Define some constants
KERNEL_SIZE = 3
PADDING = KERNEL_SIZE // 2

import pytorch_modelsize.pytorch_modelsize as modelsize


from pytorchtools import EarlyStopping

class CNN(nn.Module):
    def __init__(self, channel, out_size):
        super(CNN, self).__init__()
        self.conv1 = nn.Conv2d(channel, 32, 5, padding=2)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(32, 128, 3, padding=1)
        self.fc1 = nn.Linear(128 * 15 * 15, 256)
        self.dp = nn.Dropout(0.5)
        self.fc2 = nn.Linear(256, out_size)


    def forward(self, x):
        x = self.pool(f.relu(self.conv1(x)))
        x = f.relu(self.conv2(x))
        # IPython.embed()
        x = x.view(x.shape[0], -1)
        x = self.dp(f.relu(self.fc1(x)))
        x = self.fc2(x)

        return x


class CNNLSTMCell(nn.Module):
    """
    Generate a convolutional LSTM cell
    """

    def __init__(self, channel, cnn_out_size, hidden_size, n_class):
        super(CNNLSTMCell, self).__init__()
        self.input_size = channel
        self.hidden_size = hidden_size
        self.CNN = CNN(channel, cnn_out_size)
        self.lstm = nn.LSTMCell(input_size=cnn_out_size, hidden_size=hidden_size)

        self.dp1 = nn.Dropout(0.5)
        self.linear1 = nn.Linear(self.hidden_size, 256)

        self.dp2 = nn.Dropout(0.5)
        self.linear2 = nn.Linear(256, n_class)

    def forward(self, input_, hc, out_bool):

        # get batch and spatial sizes
        batch_size = input_.data.size()[0]

        # generate empty prev_state, if None is provided
        if hc is None:
            state_size = [batch_size, self.hidden_size]  # (B,Hidden_size)
            hc = (
                Variable(torch.zeros(state_size)).type(torch.cuda.FloatTensor),
                Variable(torch.zeros(state_size)).type(torch.cuda.FloatTensor)
            )  # list of h[t-1] and C[t-1]: both of size [batch_size, hidden_size, D, D]

        x = self.CNN(input_)
        hc = self.lstm(x, hc)

        h, c = hc
        # print h.size
        # IPython.embed()
        out = None
        if out_bool:
            flat = h.view(-1, h.size()[-1])
            # print flat.size()
            out = self.linear1(self.dp1(flat))
            out = self.linear2(self.dp2(out))

        return out, hc


import time
from sklearn.metrics import precision_recall_fscore_support, accuracy_score, confusion_matrix
from sklearn.utils.multiclass import unique_labels
import matplotlib.pyplot as plt

import IPython

def plot_confusion_matrix(y_true, y_pred, classes,
                          normalize=False,
                          title=None,
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if not title:
        if normalize:
            title = 'Normalized confusion matrix'
        else:
            title = 'Confusion matrix, without normalization'

    # Compute confusion matrix
    cm = confusion_matrix(y_true, y_pred)
    # IPython.embed()
    # Only use the labels that appear in the data
    # classes = classes[unique_labels(y_true, y_pred)]
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    fig, ax = plt.subplots()
    im = ax.imshow(cm, interpolation='nearest', cmap=cmap)
    ax.figure.colorbar(im, ax=ax)
    # We want to show all ticks...
    ax.set(xticks=np.arange(cm.shape[1]),
           yticks=np.arange(cm.shape[0]),
           # ... and label them with the respective list entries
           xticklabels=classes, yticklabels=classes,
           title=title,
           ylabel='True label',
           xlabel='Predicted label')

    # Rotate the tick labels and set their alignment.
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
             rotation_mode="anchor")

    # Loop over data dimensions and create text annotations.
    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, format(cm[i, j], fmt),
                    ha="center", va="center",
                    color="white" if cm[i, j] > thresh else "black")
    fig.tight_layout()
    # plt.style.use('seaborn')
    return ax

def count_parameters(model):
    num = sum(p.numel() for p in model.parameters() if p.requires_grad)
    size_MB = num*32/(8*1024*1024)
    return num, '{0:.4f}MB'.format(size_MB)


from convLSTM_dataset import *
from torch.utils.data import DataLoader

from torch.utils.data.dataset import random_split

import pandas as pd
# from logger import Logger
# logger = Logger('./logs')
def _main():
    """
    Run some basic tests on the API
    """
    # define batch_size, channels, height, width
    batch_size, channels, height, width = 64, 2, 30, 30
    n_class = 7
    hidden_size = 256 # 64           # hidden state size
    lr = 1e-5     # learning rate
    n_frames = 15           # sequence length
    N_dataset_frames = 15
    max_epoch = 300  # number of epochs

    cnn_out_size = 256

    convlstm_dataset = convLSTM_Dataset_dxdy(dataset_dir='../dataset/resample_skipping_stride1',
                                        n_class=n_class,
                                        transform=transforms.Compose([
                                            RandomHorizontalFlip(),
                                            RandomVerticalFlip(),
                                            ToTensor(),
                                        ])
                                        )
    train_ratio = 0.9
    train_size = int(train_ratio*len(convlstm_dataset))
    test_size = len(convlstm_dataset) - train_size

    print('===> dataset size, train size, test size:')
    print('===> ', len(convlstm_dataset), train_size, test_size )

    train_dataset, test_dataset = random_split(convlstm_dataset, [train_size, test_size])


    train_dataloader = DataLoader(train_dataset, batch_size=batch_size,
                            shuffle=True, num_workers=4)

    test_dataloader = DataLoader(test_dataset, batch_size=batch_size,
                                  shuffle=True, num_workers=4)

    # set manual seed
    # torch.manual_seed(0)
    df = pd.DataFrame(columns=['n_frames', 'inf_time_avg', 'acc',
                                    'prec',
                                    'recall',
                                    'f1_score'
                                    ])

    for n_ in range(1, n_frames+1):
        print('^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^')
        print('Start to train model with input sequence length {}'.format(n_))
        print('===> Instantiate model................')
        model = CNNLSTMCell(channels, cnn_out_size, hidden_size, n_class)
        print(repr(model))
        print('model parameter number: ', count_parameters(model))

        # se = modelsize.SizeEstimator(model, input_size=(64, 2, 30, 30))
        # print(se.estimate_size())

        # IPython.embed()

        if torch.cuda.is_available():
            # print 'sending model to GPU'
            model = model.cuda()

        print('===> Create input and target Variables.')
        x = Variable(torch.rand(n_frames, batch_size, channels, height, width))
        # y = Variable(torch.randn(T, b, d, h, w))
        y = Variable(torch.rand(batch_size))

        print('===> Create a MSE Loss.')
        loss_fn = nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=0.01)

        # early stopping
        # to track the training loss as the model trains
        train_losses = []
        # to track the validation loss as the model trains
        valid_losses = []
        # to track the average training loss per epoch as the model trains
        avg_train_losses = []
        # to track the average validation loss per epoch as the model trains
        avg_valid_losses = [] 

        # IPython.embed()
        es = EarlyStopping(patience=5, verbose=True)

        
        print('---> Run for', max_epoch, 'iterations')
        for epoch in range(0, max_epoch):
            loss_train = 0
            n_right_train = 0

            model = model.train()
            for step, sample_batched in enumerate(train_dataloader):

                model = model.train()

                x = sample_batched['frames']
                y = sample_batched['target']
                x = torch.transpose(x, 0, 1)  # transpose time sequence and batch (N, batch, channel, height, width)
                # x = x.type(torch.FloatTensor)
                # print x.size()

                if torch.cuda.is_available():
                    # print 'sending input and target to GPU'
                    x = x.type(torch.cuda.FloatTensor)
                    y = y.type(torch.cuda.FloatTensor)

                state = None
                out = None


                for t in range(N_dataset_frames-n_, N_dataset_frames):
                    out_bool = True if t == N_dataset_frames - 1 else False
                    out, state = model(x[t], state, out_bool)
                    # loss += loss_fn(state[0], y[t])

                # out = out.long()
                y = y.long()

                # print out.size(), y.size()
                loss = loss_fn(out, y)
                train_losses.append(loss.item())
                # print(' > Epoch {:2d} loss: {:.7f}'.format((epoch+1), loss.data[0]))

                # zero grad parameters
                model.zero_grad()

                # compute new grad parameters through time!
                loss.backward()
                optimizer.step()
                # learning_rate step against the gradient
                # optimizer.step()
                #  for p in model.parameters():
                #     p.data.sub_(p.grad.data * lr)

                loss_train += loss.item()*batch_size
                # Compute accuracy

                _, argmax = torch.max(out, 1)
                # print y, argmax.squeeze()
                # accuracy = (y == argmax.squeeze()).float().mean() # accuracy in each batch
                n_right_train += sum(y == argmax.squeeze()).item()

                N_step_vis = 20
                if (step + 1) % N_step_vis == 0:
                    loss_train_reduced = loss_train / (N_step_vis*batch_size)
                    train_accuracy = float(n_right_train) / (N_step_vis*batch_size)
                    loss_train = 0
                    n_right_train = 0
                    print('==================================================================')
                    print ('[CNN+LSTM][TRAIN set] Epoch {}, Step {}, Loss: {:.6f}, Acc: {:.4f}'
                           .format(epoch, step + 1, loss_train_reduced, train_accuracy))



            # ================================================================== #
            #                        Validation                                  #
            # ================================================================== #

            model = model.eval()

            test_loss = 0
            n_right = 0
            for test_step, test_sample_batched in enumerate(test_dataloader):
                x = test_sample_batched['frames']
                y = test_sample_batched['target']
                x = torch.transpose(x, 0, 1)
                # x = x.type(torch.FloatTensor)

                if torch.cuda.is_available():
                    # print 'sending input and target to GPU'
                    x = x.type(torch.cuda.FloatTensor)
                    y = y.type(torch.cuda.FloatTensor)

                state_test = None
                out_test = None

                for t in range(N_dataset_frames-n_, N_dataset_frames):
                    out_bool = True if t == N_dataset_frames - 1 else False
                    out_test, state_test = model(x[t], state_test, out_bool)
                    # loss += loss_fn(state[0], y[t])

                # out = out.long()
                y = y.long()

                # print out.size(), y.size()
                loss_valid = loss_fn(out_test, y)
                test_loss += loss_valid.item() * batch_size
                valid_losses.append(loss_valid.item())


                # Compute accuracy
                _, argmax_test = torch.max(out_test, 1)
                # print argmax_test
                # print y
                n_right += sum(y == argmax_test.squeeze()).item()

            # print n_right
            test_loss_reduced = test_loss/test_size
            test_accuracy = float(n_right)/test_size

            # print test_accuracy
            print ('[VALID] Epoch {}, Loss: {:.6f}, Acc: {:.4f}'
                    .format(epoch, test_loss_reduced, test_accuracy))
            
            # early stopping
            train_loss = np.average(train_losses)
            valid_loss = np.average(valid_losses)
            avg_train_losses.append(train_loss)
            avg_valid_losses.append(valid_loss)
            # clear lists to track next epoch
            train_losses = []
            valid_losses = []

            model_path ='./saved_model/cnnlstm_model_1layer_{}frames_20190619.pth'.format(n_)
            es(valid_loss, model, model_path)
            if es.early_stop:
                print('early stopping')
                break

        ########################################################
        #           evaluation 
        #######################################################
        # load the best model parameters
        print('*********************************************')
        print('loading model weights from best checkpoint...')
        model_path = './saved_model/cnnlstm_model_1layer_{}frames_20190619.pth'.format(n_)
        model.load_state_dict(torch.load(model_path))

        
        y_true = []
        y_pred = []
        for test_step, test_sample_batched in enumerate(test_dataloader):
            x = test_sample_batched['frames']
            y = test_sample_batched['target']
            x = torch.transpose(x, 0, 1)
            # x = x.type(torch.FloatTensor)

            start = time.time()

            if torch.cuda.is_available():
                # print 'sending input and target to GPU'
                x = x.type(torch.cuda.FloatTensor)
                y = y.type(torch.cuda.FloatTensor)

            state_test = None
            out_test = None

            for t in range(N_dataset_frames-n_, N_dataset_frames):
                out_bool = True if t == N_dataset_frames - 1 else False
                out_test, state_test = model(x[t], state_test, out_bool)

            _, argmax_test = torch.max(out_test, 1)
            batch_time = time.time() - start    

            y_true.append(y.cpu().numpy().astype(int))
            y_pred.append(argmax_test.cpu().numpy())
        #     print 'show a batch in test set:'
        #     print y
        #     print argmax_test.squeeze()
        #     break
        inf_time_avg =  batch_time/batch_size
        print(inf_time_avg)
        # save the trained model parameters
        # print y_true
        # IPython.embed()
        y_true = np.concatenate((np.ravel(np.array(y_true[:-1])), np.array(y_true[-1])), axis=0)
        y_pred = np.concatenate((np.ravel(np.array(y_pred[:-1])), np.array(y_pred[-1])), axis=0)
        # IPython.embed()

        print(np.array(y_true))
        print(np.array(y_pred))

        # torch.save(model.state_dict(), './saved_model/cnnlstm_model_1layer_augmented_{}frames_200epochs_20190619.pth'.format()) # arbitrary file extension

        ## calculate metric scores
        precision, recall, f1_score, support = precision_recall_fscore_support(y_true, y_pred)
        accuracy = accuracy_score(y_true, y_pred)

        print('------------------------------------')
        print('accuracy: {}'.format(accuracy))
        print('precision: {}'.format(np.average(precision)))
        print('recall: {}'.format(np.average(recall)))
        print('f1_score: {}'.format(np.average(f1_score)))
        print('support: {}'.format(support))

        df1 = pd.DataFrame([[n_, inf_time_avg, accuracy,
                             np.average(precision),
                             np.average(recall),
                             np.average(f1_score)
                             ]],
                           columns=['n_frames', 'inf_time_avg', 'acc',
                                    'prec',
                                    'recall',
                                    'f1_score'
                                    ])
        # save metrics and inference time along with number of frames

        # # Plot normalized confusion matrix
        # class_names = ['Translational slip', 'Rotional slip', 'Rolling', 'Stable']
        # plot_confusion_matrix(y_true, y_pred, classes=class_names, normalize=True,
        #                       title='Normalized Confusion Matrix')
        # plt.show()
        df = df.append(df1)

    df.to_csv('./cnn_lstm_metric_vs_n_frames_0619.csv')



if __name__ == '__main__':
    _main()
