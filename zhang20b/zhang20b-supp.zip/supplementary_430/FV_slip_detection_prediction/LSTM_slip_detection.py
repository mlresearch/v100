import torch
from torch import nn
import torch.nn.functional as f
from torch.autograd import Variable
import torch



# Define some constants
KERNEL_SIZE = 3
PADDING = KERNEL_SIZE // 2


class LSTMCell(nn.Module):
    """
    Generate a convolutional LSTM cell
    """

    def __init__(self, input_size, hidden_size, n_class, n_frames=11):
        super(LSTMCell, self).__init__()
        self.input_size = input_size # here it refers to embedding_dim the size of
        self.hidden_size = hidden_size

        self.lstm = nn.LSTMCell(input_size=input_size, hidden_size=hidden_size)

        self.dp1 = nn.Dropout(0.5)
        self.linear1 = nn.Linear(self.hidden_size, 256)

        self.dp2 = nn.Dropout(0.5)
        self.linear2 = nn.Linear(256, n_class)

        self.n_frames = n_frames

    def forward(self, input_, hc, out_bool):

        # get batch and spatial sizes
        batch_size = input_.data.size()[0]

        # generate empty prev_state, if None is provided
        if hc is None:
            state_size = [batch_size, self.hidden_size]  # (B,Hidden_size)
            hc = (  # hidden and cell
                Variable(torch.zeros(state_size)).type(torch.cuda.FloatTensor),
                Variable(torch.zeros(state_size)).type(torch.cuda.FloatTensor)
            )  # list of h[t-1] and C[t-1]: both of size [batch_size, hidden_size, D, D]

        # data size is [batch, channel, height, width]

        hc = self.lstm(input_, hc)

        h, c = hc
        # print h.size
        # IPython.embed()
        out = None
        if out_bool:
            flat = h.view(-1, h.size()[-1])
            # print flat.size()
            out = self.linear1(self.dp1(flat))
            out = self.linear2(self.dp2(out))

        return out, hc


import time
from sklearn.metrics import precision_recall_fscore_support, accuracy_score, confusion_matrix
from sklearn.utils.multiclass import unique_labels
import matplotlib.pyplot as plt

import IPython

def plot_confusion_matrix(y_true, y_pred, classes,
                          normalize=False,
                          title=None,
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if not title:
        if normalize:
            title = 'Normalized confusion matrix'
        else:
            title = 'Confusion matrix, without normalization'

    # Compute confusion matrix
    cm = confusion_matrix(y_true, y_pred)
    # IPython.embed()
    # Only use the labels that appear in the data
    # classes = classes[unique_labels(y_true, y_pred)]
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    fig, ax = plt.subplots()
    im = ax.imshow(cm, interpolation='nearest', cmap=cmap)
    ax.figure.colorbar(im, ax=ax)
    # We want to show all ticks...
    ax.set(xticks=np.arange(cm.shape[1]),
           yticks=np.arange(cm.shape[0]),
           # ... and label them with the respective list entries
           xticklabels=classes, yticklabels=classes,
           title=title,
           ylabel='True label',
           xlabel='Predicted label')

    # Rotate the tick labels and set their alignment.
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
             rotation_mode="anchor")
             
    # Loop over data dimensions and create text annotations.
    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, format(cm[i, j], fmt),
                    ha="center", va="center",
                    color="white" if cm[i, j] > thresh else "black")
    fig.tight_layout()
    return ax

# def count_parameters(model):
    # return sum(p.numel() for p in model.parameters() if p.requires_grad)

from convLSTM_dataset import *
from torch.utils.data import DataLoader

from torch.utils.data.dataset import random_split

from func_utils import *
from pytorchtools import EarlyStopping
# from logger import Logger
# logger = Logger('./logs')
def count_parameters(model):
    num = sum(p.numel() for p in model.parameters() if p.requires_grad)
    size_MB = num*32/(8*1024*1024)
    return num, '{0:.4f}MB'.format(size_MB)

def lr_scheduler(optimizer, epoch, num_epochs):
    if epoch < num_epochs //2:
        return optimizer
    else:
        for param_group in optimizer.param_groups:
            param_group['lr'] = param_group['lr']/2.0
        return optimizer


from torch.utils.data.sampler import SubsetRandomSampler, SequentialSampler


def random_split_customized(dataset, train_ratio=0.9, shuffle_dataset=True):
    random_seed = 41
    # Creating data indices for training and validation splits:
    dataset_size = len(dataset)
    indices = list(range(dataset_size))
    # print indices
    split = int(np.floor(train_ratio * dataset_size))
    # print split
    if shuffle_dataset:
        np.random.seed(random_seed)
        np.random.shuffle(indices)
    # print indices[0:10]
    train_indices, test_indices = indices[:split], indices[split:]

    # Creating PT data samplers and loaders:
    train_sampler = SubsetRandomSampler(train_indices)
    # test_sampler = SubsetRandomSampler(test_indices)
    test_sampler = SubsetRandomSampler(test_indices)
    # print(test_indices)
    # IPython.embed()
    return train_sampler, test_sampler

def _main():

    # define batch_size, channels, height, width
    batch_size, feature_size = 16, 1800
    n_class = 7
    hidden_size = 512 # 64           # hidden state size
    lr = 4e-5     # learning rate
    n_frames = 15 # sequence length
    N_dataset_frames = 15
    max_epoch = 200 # number of epochs

    ################ dataset import and split #######################
    lstm_dataset = LSTM_Dataset(dataset_dir='../dataset/resample_skipping_stride1',
                                n_class=n_class,
                                transform=transforms.Compose([
                                                                ToTensor()])
                                )
    train_ratio = 0.9
    train_size = int(train_ratio*len(lstm_dataset))
    valid_size = len(lstm_dataset) - train_size

    print('=== dataset size, train size, validation size:===')
    print(len(lstm_dataset), train_size, valid_size)

    # train_dataset, valid_dataset = random_split(lstm_dataset, [train_size, valid_size])
    train_sampler, valid_sampler = random_split_customized(lstm_dataset, train_ratio=0.9)
    print('************length of the train dataset:)', len(train_sampler))

    train_dataloader = DataLoader(lstm_dataset, batch_size=batch_size, sampler=train_sampler, num_workers=1)

    valid_dataloader = DataLoader(lstm_dataset, batch_size=batch_size, sampler=valid_sampler, num_workers=1)
    # dataset_path = '../dataset/resample_skipping_stride1'
    # train_sampler, test_sampler, train_dataloader, test_dataloader = generate_dataloader(dataset_path,0.9, batch_size, n_class=7)

    # set manual seed
    # torch.manual_seed(0)
    # df = pd.DataFrame(columns=['n_frames', 'inf_time_avg', 'acc',
    #                            'prec0', 'prec1', 'prec2', 'prec3',
    #                            'recall0', 'recall1', 'recall2', 'recall3',
    #                            'f1_score0', 'f1_score1', 'f1_score2', 'f1_score3',
    #                            'support0', 'support1', 'support2', 'support3'])
    df = pd.DataFrame(columns=['n_frames', 'inf_time_avg', 'acc',
                               'prec',
                               'recall',
                               'f1_score',
                               ])

    
    for n_ in range(1, n_frames + 1):
        print('^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^')
        print('Start to train model with input sequence length {}'.format(n_))
        print('Instantiate model................')
        model = LSTMCell(feature_size, hidden_size, n_class=n_class, n_frames=11)
        print(repr(model))
        print('model parameter number: ', count_parameters(model))

        if torch.cuda.is_available():
            # print 'sending model to GPU'
            model = model.cuda()

        print('Create input and target Variables')
        x = Variable(torch.rand(n_frames, batch_size, feature_size))
        # y = Variable(torch.randn(T, b, d, h, w))
        y = Variable(torch.rand(batch_size))

        print('Create a MSE criterion')
        loss_fn = nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=0.01)

        # to track the training loss as the model trains
        train_losses = []
        # to track the validation loss as the model trains
        valid_losses = []
        # to track the average training loss per epoch as the model trains
        avg_train_losses = []
        # to track the average validation loss per epoch as the model trains
        avg_valid_losses = [] 


        # IPython.embed()
        es = EarlyStopping(patience=5, verbose=True)

        print('========= Run for ', max_epoch, 'iterations =================')
        
        for epoch in range(0, max_epoch):
            optimizer = lr_scheduler(optimizer, epoch, max_epoch) 

            loss_train = 0
            n_right_train = 0

            model = model.train()
            for step, sample_batched in enumerate(train_dataloader):

                

                x = sample_batched['frames']
                y = sample_batched['target']
                # print(y)
                x = torch.transpose(x, 0, 1)  # transpose time sequence and batch (N, batch, feature_size)
                # x = x.type(torch.FloatTensor)
                # print x.size()

                if torch.cuda.is_available():
                    # print 'sending input and target to GPU'
                    x = x.type(torch.cuda.FloatTensor)
                    y = y.type(torch.cuda.FloatTensor)

                state = None

                for t in range(N_dataset_frames-n_, N_dataset_frames): # feeding last n_ frames iteratively
                    # print x[t,0,0,:,:]
                    # print(x[t].shape)
                    out_bool = True if t == N_dataset_frames - 1 else False
                    out, state = model(x[t], state, out_bool)

                # out = out.long()
                y = y.long()


                # print out.size(), y.size()
                loss = loss_fn(out, y)
                # print(' > Epoch {:2d} loss: {:.7f}'.format((epoch+1), loss.data[0]))

                # zero grad parameters
                model.zero_grad()

                # compute new grad parameters through time!
                loss.backward()
                optimizer.step()

                loss_train += loss.item()*batch_size
                train_losses.append(loss.item())
                # Compute accuracy

                _, argmax = torch.max(out, 1)
                # print y, argmax.squeeze()
                # accuracy = (y == argmax.squeeze()).float().mean() # accuracy in each batch
                n_right_train += sum(y == argmax.squeeze()).item()

                N_step_vis = 20
                if (step + 1) % N_step_vis == 0:
                    loss_train_reduced = loss_train / (N_step_vis*batch_size)
                    train_accuracy = float(n_right_train) / (N_step_vis*batch_size)
                    loss_train = 0
                    n_right_train = 0
                    print('==================================================================')
                    print('[TRAIN] Epoch {}, Step {}, Loss: {:.6f}, Acc: {:.4f}'
                           .format(epoch, step + 1, loss_train_reduced, train_accuracy))


            # ================================================================== #
            #                        Validation                         #
            # ================================================================== #
            val_loss = 0
            n_right = 0
            model = model.eval()
            for valid_step, valid_sample_batched in enumerate(valid_dataloader):
                x = valid_sample_batched['frames']
                y = valid_sample_batched['target']
                print(y)
                x = torch.transpose(x, 0, 1)
                # x = x.type(torch.FloatTensor)

                if torch.cuda.is_available():
                    # print 'sending input and target to GPU'
                    x = x.type(torch.cuda.FloatTensor)
                    y = y.type(torch.cuda.FloatTensor)

                state_valid = None

                for t in range(N_dataset_frames - n_, N_dataset_frames):
                    # print x[t,0,0,:,:]
                    out_bool = True if t == N_dataset_frames - 1 else False
                    out_valid, state_valid = model(x[t], state_valid, out_bool)

                y = y.long()
                # print out.size(), y.size()
                loss_valid = loss_fn(out_valid, y)
                val_loss += loss_valid.item() * batch_size
                valid_losses.append(loss_valid.item())

                # Compute accuracy
                _, argmax_valid = torch.max(out_valid, 1)
                # print argmax_test
                # print y
                n_right += sum(y == argmax_valid.squeeze()).item()

            
            # print n_right
            valid_loss_reduced = val_loss/valid_size
            valid_accuracy = float(n_right)/valid_size

            # print test_accuracy
            print('[ VALID] Epoch {}, Loss: {:.6f}, Acc: {:.4f}'
                    .format(epoch, valid_loss_reduced, valid_accuracy))
            
            # early stopping
            train_loss = np.average(train_losses)
            valid_loss = np.average(valid_losses)
            avg_train_losses.append(train_loss)
            avg_valid_losses.append(valid_loss)
            # clear lists to track next epoch
            train_losses = []
            valid_losses = []

            model_path ='./saved_model/lstm_model_1layer_{}frames_20190701_8bs_1e-4lr.pth'.format(n_, epoch)
            es(valid_loss, model, model_path)
            if es.early_stop:
                print('early stopping')
                break


        ############################################
        #           evaluation 
        ###########################################
        # load the best model parameters
        print('*********************************************')
        print('loading model weights from best checkpoint...')
        model.load_state_dict(torch.load(model_path))

        start = time.time()
        y_true = []
        y_pred = []

        model.eval()
        for test_step, test_sample_batched in enumerate(valid_dataloader):
            x = test_sample_batched['frames']
            y = test_sample_batched['target']
            x = torch.transpose(x, 0, 1)
            # x = x.type(torch.FloatTensor)

            if torch.cuda.is_available():
                # print 'sending input and target to GPU'
                x = x.type(torch.cuda.FloatTensor)
                y = y.type(torch.cuda.FloatTensor)

            state_test = None
            out_test = None

            for t in range(N_dataset_frames - n_, N_dataset_frames):
                # print x[t,0,0,:,:]
                out_bool = True if t == N_dataset_frames - 1 else False
                out_test, state_test = model(x[t], state_test, out_bool)

            _, argmax_test = torch.max(out_test, 1)

            y_true.append(y.cpu().numpy().astype(int))
            y_pred.append(argmax_test.cpu().numpy())

        test_size = valid_size
        inf_time_avg = (time.time() - start) / test_size
        #     print 'show a batch in test set:'
        #     print y
        #     print argmax_test.squeeze()
        #     break
        # print 'one batch inference time:', (time.time() - start)/batch_size
        # save the trained model parameters
        # print y_true
        # IPython.embed()
        y_true = np.concatenate((np.ravel(np.array(y_true[:-1])), np.array(y_true[-1])), axis=0)
        y_pred = np.concatenate((np.ravel(np.array(y_pred[:-1])), np.array(y_pred[-1])), axis=0)
        # IPython.embed()

        print(np.array(y_true))
        print(np.array(y_pred))

        # torch.save(model.state_dict(), './saved_model/lstm_model_1layer_{}frames_50epochs_20190426.pth'.format(n_)) # arbitrary file extension

        ## calculate metric scores
        precision, recall, f1_score, support = precision_recall_fscore_support(y_true, y_pred)
        accuracy = accuracy_score(y_true, y_pred)

        print('------------------------------------')
        print('accuracy: {}'.format(accuracy))
        print('precision: {}'.format(np.average(precision)))
        print('recall: {}'.format(np.average(recall)))
        print('f1_score: {}'.format(np.average(f1_score)))
        print('support: {}'.format(support))

        # Plot normalized confusion matrix
        # class_names = ['Translational slip', 'Rotional slip', 'Rolling', 'Stable']
        # plot_confusion_matrix(y_true, y_pred, classes=class_names, normalize=True,
        #                       title='Normalized Confusion Matrix')
        # plt.show()
        df1 = pd.DataFrame([[n_, inf_time_avg, accuracy,
                             np.average(precision),
                             np.average(recall),
                             np.average(f1_score)
                            ]],
                           columns=['n_frames', 'inf_time_avg', 'acc',
                                    'prec',
                                    'recall',
                                    'f1_score'
                                    ])

        df = df.append(df1)

    df.to_csv('./lstm_metric_vs_n_frames_2019060701_8bs_1e-4lr.csv', float_format='%.4f')


def load_state_dict(model, path_list):

    model_dict = model.state_dict()
    # for key, value in model_dict.iteritems():
    #     print key

    for type_key, path in path_list.iteritems():
        # print '-----------------------------'
        pretrained_dict = torch.load(path)
        # for key, value in pretrained_dict.iteritems():
        #     print key

        # 1. filter out unnecessary keys
        pretrained_dict = {(type_key + '.' + k): v for k, v in pretrained_dict.items() if (type_key + '.' + k) in model_dict}
        # 2. overwrite entries in the existing state dict
        model_dict.update(pretrained_dict)
        # 3. load the new state dict
        model.load_state_dict(model_dict)


if __name__ == '__main__':
    _main()
