import torch
import torch.nn as nn
from torch.nn import functional as F

from torch.autograd import Variable



from pytorch_prednet.convlstmcell import ConvLSTMCell


class PixelMotionNet(nn.Module):
    def __init__(self, in_channels, conv_channels, convLSTM_channels, upsample_channels, num_future):
        super(PixelMotionNet,self).__init__()
        self.conv_channels = conv_channels
        self.convLSTM_channels = convLSTM_channels
        self.upsample_channels = upsample_channels

        self.num_future = num_future


        self.upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.maxpool = nn.MaxPool2d(kernel_size=2, stride=2)

        self.conv0 = nn.Sequential(nn.Conv2d(in_channels, self.conv_channels[0], 3, stride=1, padding=1),
                                    nn.BatchNorm2d(self.conv_channels[0]),
                                    nn.ReLU(),
                                    self.maxpool
                                    ) # 2x32x32 ==> self.conv_channels[0]x16x16

        self.conv1 = nn.Sequential(nn.Conv2d(self.conv_channels[0], self.conv_channels[1], 3, stride=1, padding=1),
                                    nn.BatchNorm2d(self.conv_channels[1]),
                                    nn.ReLU(),
                                    self.maxpool
                                    ) #  self.conv_channels[0]x16x16 ==> self.conv_channels[1]x8x8
        
        self.convLSTM0 = ConvLSTMCell(in_channels=self.conv_channels[1], # + self.convLSTM_channels[0], 
                                        out_channels=self.convLSTM_channels[0],
                                        kernel_size=(3,3))
                                        # nn.ReLU()
                                        # ) # self.conv_channels[1]x8x8 ==> self.convLSTM_channels[0]x8x8
        self.convLSTM1 = ConvLSTMCell(in_channels=self.convLSTM_channels[0],# + self.convLSTM_channels[0], 
                                        out_channels=self.convLSTM_channels[1],
                                        kernel_size=(3,3))
                                        # nn.ReLU()
                                        #) #  self.convLSTM_channels[0]x8x8 ==> self.conv_channels[1]x8x8

        self.up0 = self.upsample         # ==> self.upsample_channels[0]x16x16
        self.up_conv0 = nn.Sequential(nn.Conv2d(self.convLSTM_channels[1] + self.conv_channels[0], self.upsample_channels[0], 3, 1, padding=1),
                                        nn.BatchNorm2d(self.upsample_channels[0]),
                                        nn.ReLU())

        self.up1 = self.upsample # ==> self.upsample_channels[1]x32x32
        self.up_conv1 = nn.Sequential(nn.Conv2d(self.upsample_channels[0], self.upsample_channels[1], 3, 1, padding=1),
                                        nn.BatchNorm2d(self.upsample_channels[1]),
                                        nn.ReLU())

        self.out_conv = nn.Conv2d(self.upsample_channels[1], in_channels, kernel_size=1)

        self.reset_parameters()

    def reset_parameters(self):
        for l in range(2):
            cell = getattr(self, 'convLSTM{}'.format(l))
            cell.reset_parameters()

    
    def forward(self, input):
        # print('-------forwarding-------')
        time_steps = input.size(1)
        w, h = input.size(-2), input.size(-1)
        batch_size = input.size(0)

        convLSTM_hidden0 = Variable(torch.zeros(batch_size, self.convLSTM_channels[0], 8, 8)).cuda()
        convLSTM_hidden1 = Variable(torch.zeros(batch_size, self.convLSTM_channels[1], 8, 8)).cuda()

        # print(convLSTM_hidden0.shape)
        hx0 = (convLSTM_hidden0, convLSTM_hidden0)
        hx1 = (convLSTM_hidden1, convLSTM_hidden1)

        for t in range(1, time_steps):
            img = input[:, t] #- input[:, t-1]
            img = img.type(torch.cuda.FloatTensor)

            x1 = self.conv0(img)
            x2 = self.conv1(x1)
            # print(x2.shape) 

            x3, hx0 = self.convLSTM0(x2, hx0)
            x4, hx1 = self.convLSTM1(x3, hx1)


            x5 = self.up0(x4)
            # print(x1.shape, x5.shape)
            x5and1 = torch.cat([x5, x1], dim=1)
            x5 = self.up_conv0(x5and1)

            x6 = self.up1(x5)
            # x6and1 = torch.cat([x6, x1], dim=1)
            x6 = self.up_conv1(x6)

            pixelMotionPred = self.out_conv(x6)
            
            frame_prediction = torch.mul(1.0 + pixelMotionPred, img)

        # recirculating
        output_frames = frame_prediction
        output_frames = output_frames.unsqueeze(dim=1)
        # last_frame = input[:, t]


        for tt in range(self.num_future):
            # print('----------predicting--------')
            img = frame_prediction #- last_frame
            # last_frame = frame_prediction
            img = img.type(torch.cuda.FloatTensor)

            x1 = self.conv0(img)
            x2 = self.conv1(x1) 

            x3, hx0 = self.convLSTM0(x2, hx0)
            x4, hx1 = self.convLSTM1(x3, hx1)

            x5 = self.up0(x4)
            x5and1 = torch.cat([x5, x1], dim=1)
            x5 = self.up_conv0(x5and1)

            x6 = self.up1(x5)
            # x6and1 = torch.cat([x6, x1], dim=1)
            x6 = self.up_conv1(x6)

            pixelMotionPred = self.out_conv(x6)
            # print(pixelMotionPred.shape)
            
            frame_prediction = torch.mul(1.0 + pixelMotionPred, img)
            # print(frame_prediction.shape)

            output_frames = torch.cat((output_frames, frame_prediction.unsqueeze(dim=1)), dim=1)
        

        return output_frames


if __name__ == '__main__':
    model = PixelMotionNet(in_channels=2)
    model = model.cuda()

    import numpy as np

    x = Variable(torch.rand(4,10,2,32,32)).cuda()
    # if torch.cuda.is_available():
    #     # print 'sending input and target to GPU'
    #     x = x.type(torch.cuda.FloatTensor)
        # y = y.type(torch.cuda.FloatTensor)
    print(x)

    prediction = model(x)



        


        




