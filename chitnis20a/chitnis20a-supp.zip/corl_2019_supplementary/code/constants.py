"""Constants and such, used throughout the directory.
"""

import time

SEED = int(time.time())

# Main.py script runs the given agents in the given order, each on
# the given environment.
AGENTS_TO_RUN = [
    "RewardCorrelationGreedyMaskingAgent",
    # "NeverMaskingAgent",
    # "SubsetMaskingAgent",
    # "AverageGreedyMaskingAgent",
]
ENVIRONMENT_TO_RUN = "FactoryMDP"

### Environment parameters. ###
GAMMA = 0.99
# Reward parameters.
HIT_OBJ_REWARD = -500
GOAL_RAINING_NO_UMBRELLA_REWARD = -50
SUCCESS_REWARD = 300
FLAG_MISS_REWARD = 50
BAD_COMMIT_REWARD = -50
CRASH_HUMAN_REWARD = -100
# Model parameters.
ACTION_SUCC_PROB = 1
OBJS_MOVE_PROB = 0.5
WEATHER_SWITCH_PROB = 0.3
FLAG_CHANGE_PROB = 0.5
ORDER_CHANGE_PROB = 0.8
# Pybullet visualization parameters.
OBJ_RADIUS = 0.075
OBJ_HEIGHT = 0.075
TABLE_Z = 0.67
SPEED = 0.1
MOVE_GRIPPER_DIST_THRESH = 0.01
MOVE_GRIPPER_MAX_ITER = 10

### Agent parameters. ###
# Full or partial observability.
OBSERVABILITY = "full"
# Timeouts, in seconds.
PLAN_TIMEOUT = 60
RUN_TIMEOUT = 60
RUN_ONLINE_TIMEOUT = 60
# Projection parameters.
SIMULATION_NUM_TRAJ = {"SimpleMDP": 50,
                       "BigMDP": 200,
                       "FactoryMDP": 50}[ENVIRONMENT_TO_RUN]
SIMULATION_TRAJ_LEN = {"SimpleMDP": 50,
                       "BigMDP": 200,
                       "FactoryMDP": 50}[ENVIRONMENT_TO_RUN]
# SubsetMaskingAgent parameters.
SUBSET_NUM_TRIALS = 500
SUBSET_MAX_MASK_SIZE = float("inf")
SUBSET_MAX_MASK_VALUE = 3
PENALTY_TYPE = "size" # "size" or "time"
SCORE_LAMBDA = {"SimpleMDP": 25,
                "BigMDP": 0.5,
                "FactoryMDP": 0.5}[ENVIRONMENT_TO_RUN]
# AverageGreedyMaskingAgent parameters.
AVG_GREEDY_NUM_TRIALS = 10
# RewardCorrelationGreedyMaskingAgent parameters.
REWARD_ESTIMATION_NUM_STATES = 250
MUTUAL_INFO_THRESHOLD = 1e-5
# Testing parameters.
TEST_NUM_TRIALS = 1000
MAX_STEPS_PER_TRIAL = 200
DO_PRINT = False
RUN_PRECOMPUTED_POLICY = False
if RUN_PRECOMPUTED_POLICY:
    assert ENVIRONMENT_TO_RUN == "FactoryMDP" and OBSERVABILITY == "partial"
PYBULLET_VISUALIZE = False
if PYBULLET_VISUALIZE:
    assert ENVIRONMENT_TO_RUN == "FactoryMDP"
    RUN_TIMEOUT = 1000000
    RUN_ONLINE_TIMEOUT = 1000000


class PrintColors:
    """Macros for printing in color.
    """
    HEADER = "\033[95m"
    OKBLUE = "\033[94m"
    OKGREEN = "\033[92m"
    WARNING = "\033[93m"
    FAIL = "\033[91m"
    ENDC = "\033[0m"
    BOLD = "\033[1m"
    UNDERLINE = "\033[4m"


CYLINDER_URDF = """<robot name="cylinder">
<link name="base_link">
    <visual>
      <origin xyz="0 0 0"/>
      <geometry>
        <cylinder length="{1:.2f}" radius="{0:.2f}"/>
      </geometry>
      <material name="color">
        <color rgba="{2} {3} {4} {5}"/>
      </material>
    </visual>
    <collision>
      <origin xyz="0 0 0"/>
      <geometry>
        <cylinder length="{1:.2f}" radius="{0:.2f}"/>
      </geometry>
    </collision>
    <inertial>
      <mass value="10"/>
      <inertia ixx="0.4" ixy="0.0" ixz="0.0" iyy="0.4" iyz="0.0" izz="0.2"/>
    </inertial>
  </link>
  </robot>"""


CUBE_URDF = """<robot name="cube">
<link name="baseLink">
    <contact>
      <lateral_friction value="1.0"/>
      <rolling_friction value="0.0"/>
      <contact_cfm value="0.0"/>
      <contact_erp value="1.0"/>
    </contact>
    <inertial>
      <origin rpy="0 0 0" xyz="0 0 0"/>
       <mass value="1.0"/>
       <inertia ixx="1" ixy="0" ixz="0" iyy="1" iyz="0" izz="1"/>
    </inertial>
    <visual>
      <origin rpy="0 0 0" xyz="0 0 0"/>
      <geometry>
        <box size="{0} {1} {2}"/>
      </geometry>
       <material name="white">
        <color rgba="{3} {4} {5} {6}"/>
      </material>
    </visual>
    <collision>
      <origin rpy="0 0 0" xyz="0 0 0"/>
      <geometry>
        <box size="{0} {1} {2}"/>
      </geometry>
    </collision>
  </link>
</robot>"""


TABLE_URDF = """<robot name="table">
<link name="world"/>
  <joint name="fixed" type="fixed">
    <parent link="world"/>
    <child link="baseLink"/>
    <origin xyz="0 0 0"/>
  </joint>
  <link name="baseLink">
    <inertial>
      <origin rpy="0 0 0" xyz="0 0 0.6"/>
       <mass value="0"/>
       <inertia ixx="0.1" ixy="0" ixz="0" iyy="0.1" iyz="0" izz="0.1"/>
    </inertial>
    <visual>
      <origin rpy="0 0 0" xyz="0 0 0.6"/>
      <geometry>
          <mesh filename="table.obj" scale="{0} {1} 0.08"/>
      </geometry>
   <material name="framemat0">
      <color
         rgba="{5} {5} {5} {2}" />
      </material>
    </visual>
    <visual>
      <origin rpy="0 0 0" xyz="-{3} -{4} 0.28"/>
      <geometry>
        <box size="0.05 0.05 0.56"/>
      </geometry>
  <material name="framemat0"/>
    </visual>
    <visual>
      <origin rpy="0 0 0" xyz="-{3} {4} 0.28"/>
      <geometry>
        <box size="0.05 0.05 0.56"/>
      </geometry>
  <material name="framemat0"/>
  </visual>
    <visual>
      <origin rpy="0 0 0" xyz="{3} -{4} 0.28"/>
      <geometry>
        <box size="0.05 0.05 0.56"/>
      </geometry>
  <material name="framemat0"/>
  </visual>
    <visual>
      <origin rpy="0 0 0" xyz="{3} {4} 0.28"/>
      <geometry>
        <box size="0.05 0.05 0.56"/>
      </geometry>
    </visual>
    <collision>
      <origin rpy="0 0 0" xyz="0 0 0.6"/>
      <geometry>
      <box size="{0} {1} 0.08"/>
      </geometry>
    </collision>
  </link>
</robot>"""
