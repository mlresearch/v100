"""Plannability environments.
"""

import copy
import time
import os
import glob
from collections import defaultdict
import itertools
import numpy as np
import pybullet
from util import flatten, sample_from_dict
import constants


class SimpleMDP:
    """A simple MDP for testing plannability. The robot is navigating through
    a gridworld that has exogenous processes, which transition
    independently of the robot's states and actions. However, they can
    influence the robot's state transitions and rewards. The only
    endogenous process is the robot's position.
    """
    def __init__(self, sizex=9, sizey=2):
        self.sizex = sizex
        self.sizey = sizey
        self.goalx = sizex-1
        self.goaly = sizey-1
        # Number of exogenous variables in the system.
        self.num_exog_vars = 5
        # The domain of each exogenous variable.
        self.exog_domains = [[(3, 0), (3, 1)],
                             [(5, 0), (5, 1)],
                             [(7, 0), (7, 1)],
                             ["S", "R"],
                             [(0, 0)]]
        # Set of indices of unobserved exogenous variables.
        self.unobserved_exog = {1}
        # How the exogenous variable dynamics are factored.
        self.exog_factoring = [[0, 1, 2], [3], [4]]
        assert len(flatten(self.exog_factoring)) == self.num_exog_vars
        # Set up dynamics models for each factor in self._exog_factoring.
        mpr = constants.OBJS_MOVE_PROB
        ij_move_model = np.array([[1-mpr, 0, 0, mpr], [1-mpr, 0, 0, mpr],
                                  [mpr, 0, 0, 1-mpr], [mpr, 0, 0, 1-mpr]])
        k_move_model = np.array([[1-mpr, mpr], [mpr, 1-mpr]])
        indices = list(itertools.product(*[range(len(self.exog_domains[i]))
                                           for i in self.exog_factoring[0]]))
        move_mat = np.zeros((len(indices), len(indices)))
        for i, j, k in indices:
            for nexti, nextj, nextk in indices:
                ind = 4*i+2*j+k
                nind = 4*nexti+2*nextj+nextk
                move_mat[ind, nind] = (ij_move_model[2*i+j, 2*nexti+nextj]*
                                       k_move_model[k, nextk])
        wpr = constants.WEATHER_SWITCH_PROB
        self._exog_models = [np.array(move_mat),
                             np.array([[1-wpr, wpr], [wpr, 1-wpr]]),
                             np.array([[1]])]
        for factor, model in zip(self.exog_factoring, self._exog_models):
            assert model.shape[0] == model.shape[1] == np.prod(
                [len(self.exog_domains[var_ind]) for var_ind in factor])
            assert np.all(np.abs(model.sum(axis=1)-1) < 1e-5)
        # Other stuff.
        self._rand_state = np.random.RandomState(seed=constants.SEED)
        self.actions = list(range(4))
        self.action_names = {0: "UP", 1: "DOWN", 2: "LEFT", 3: "RIGHT"}
        self.gamma = constants.GAMMA
        self._init_st = ((1, 0, False), (tuple(None for _ in range(3))+
                                         ("S", (0, 0))))

    def step(self, state, action):
        """Sample a step in the world. As this function is a sampler
        rather than a complete model, it is visible to the reduced MDP.
        """
        endog_state, exog_state = state
        next_exog_state = [None for _ in range(self.num_exog_vars)]
        for factor_ind, factor in enumerate(self.exog_factoring):
            exog_vars = tuple(exog_state[var_ind] for var_ind in factor)
            for i, next_exog_var in enumerate(
                    self.exog_model_step(exog_vars, factor_ind)):
                next_exog_state[factor[i]] = next_exog_var
        assert None not in next_exog_state
        next_exog_state = tuple(next_exog_state)
        next_endog_state = sample_from_dict(self.endog_model(
            endog_state, action, exog_state), self._rand_state)
        return (next_endog_state, next_exog_state)

    def endog_model(self, endog_state, action, exog_state, mask=None,
                    action_succ_prob=constants.ACTION_SUCC_PROB):
        """Model for the endogenous aspects of the world. Visible to the
        reduced MDP, since our focus is on the exogenous aspects of the world.
        """
        if endog_state == "SINK":
            return {"SINK": 1.0}
        robot_x, robot_y, holding_umbrella = endog_state
        if mask is None:
            mask = list(range(self.num_exog_vars))
        if robot_x == self.goalx and robot_y == self.goaly:
            if holding_umbrella:
                return {"SINK": 1.0}
            # WARNING: assuming here that weather is index num_exog_vars-2.
            if not any(m_i == self.num_exog_vars-2 and exog_var == "R"
                       for m_i, exog_var in zip(mask, exog_state)):
                return {"SINK": 1.0}
        for m_i, exog_var in zip(mask, exog_state):
            # WARNING: assuming here that umbrella is index num_exog_vars-1.
            if m_i == self.num_exog_vars-1 and \
               robot_x == exog_var[0] and robot_y == exog_var[1]:
                holding_umbrella = True
        action_fail_prob = (1-action_succ_prob)/3
        result = defaultdict(float)
        result[(max(robot_x-1, 0), robot_y, holding_umbrella)] += (
            action_succ_prob if action == 0 else action_fail_prob)
        result[(min(robot_x+1, self.sizex-1), robot_y, holding_umbrella)] += (
            action_succ_prob if action == 1 else action_fail_prob)
        result[(robot_x, max(robot_y-1, 0), holding_umbrella)] += (
            action_succ_prob if action == 2 else action_fail_prob)
        result[(robot_x, min(robot_y+1, self.sizey-1), holding_umbrella)] += (
            action_succ_prob if action == 3 else action_fail_prob)
        return result

    def exog_model_step(self, exog_vars, factor_ind):
        """Step the exogenous aspects of the world corresponding to the factor
        and model indexed by the given factor_ind. As this function is a sampler
        rather than a complete model, it is visible to the reduced MDP.
        """
        factor = self.exog_factoring[factor_ind]
        domains = list(itertools.product(*[self.exog_domains[var_ind]
                                           for var_ind in factor]))
        model = self._exog_models[factor_ind]
        return sample_from_dict({domains[i]: prob for i, prob in
                                 enumerate(model[domains.index(exog_vars)])},
                                self._rand_state)

    def reward(self, state, mask=None):
        """Reward function, returns a number. Visible to the reduced MDP.
        """
        if state[0] == "SINK":
            return 0
        (robot_x, robot_y, holding_umbrella), exog_state = state
        if mask is None:
            mask = list(range(self.num_exog_vars))
        assert len(exog_state) == len(mask)
        for m_i, exog_var in zip(mask, exog_state):
            if m_i == 1 and \
               robot_x == exog_var[0] and robot_y == exog_var[1]:
                # Hitting object 1 is bad.
                return constants.HIT_OBJ_REWARD
            # WARNING: assuming here that weather is index num_exog_vars-2.
            if m_i == self.num_exog_vars-2 and robot_x == self.goalx and \
               robot_y == self.goaly and exog_var == "R" and \
               not holding_umbrella:
                # Reaching the goal when it's raining is very bad, unless
                # the robot is holding an umbrella.
                return constants.GOAL_RAINING_NO_UMBRELLA_REWARD
        if robot_x == self.goalx and robot_y == self.goaly:
            # Success!
            return constants.SUCCESS_REWARD
        return 0

    def print_state(self, state, mask):
        """Print the given state to the terminal, under the given mask.
        """
        world = [np.zeros((self.sizex, self.sizey), dtype=str),
                 "Weather: UNSEEN"]
        (robot_x, robot_y, holding_umbrella), exog_state = state
        assert len(exog_state) == len(mask)
        for m_i, exog_var in zip(mask, exog_state):
            if m_i in (0, 1, 2):
                world[0][exog_var] = "O"
            # WARNING: assuming here that weather is index num_exog_vars-2.
            if m_i == self.num_exog_vars-2:
                world[1] = "Weather: {}".format(exog_var)
            # WARNING: assuming here that umbrella is index num_exog_vars-1.
            if m_i == self.num_exog_vars-1:
                world[0][exog_var] = "U"
        world[0][self.goalx, self.goaly] = "G"
        world[0][robot_x, robot_y] = "R"
        world.append("Holding umbrella: {}".format(holding_umbrella))
        print(world)

    def get_initial_state(self, _):
        """Return the initial state.
        """
        exog_state = list(self._init_st[1])
        for i in range(3):
            domain = self.exog_domains[i]
            exog_state[i] = domain[self._rand_state.choice(len(domain))]
        return (self._init_st[0], tuple(exog_state))


class BigMDP(SimpleMDP):
    """A bigger version of the SimpleMDP, for scaling up experiments.
    Exhibits both correlation through time and partial observability.
    """
    def __init__(self, sizex=4, sizey=4): # pylint:disable=super-init-not-called
        self.sizex = sizex
        self.sizey = sizey
        self.goalx = sizex-1
        self.goaly = sizey-1
        self._rand_state = np.random.RandomState(seed=constants.SEED)
        # Number of exogenous variables in the system.
        self.num_exog_vars = 15
        self._num_objs = 10
        self._num_flags = 5
        self._num_indic_flags = 1
        assert self._num_objs+self._num_flags == self.num_exog_vars
        # The domain of each exogenous variable.
        self.exog_domains = (
            [[(i, min(sizey-2, obj_ind//2+1)) for i in range(sizex)]
             for obj_ind in range(self._num_objs)]+
            [["OFF", "ON"]
             for _ in range(self._num_indic_flags)]+
            [[5, 6, 7]
             for _ in range(self._num_flags-self._num_indic_flags)])
        # Set of indices of unobserved exogenous variables.
        self.unobserved_exog = {0}
        # How the exogenous variable dynamics are factored.
        self.exog_factoring = [[0, 1, 2], [3, 4], [5, 7, 8], [6, 9],
                               [10, 13, 14], [11, 12]]
        assert len(flatten(self.exog_factoring)) == self.num_exog_vars
        self._exog_models = []
        self._exog_models += self._define_object_dynamics(sizex)
        self._exog_models += self._define_flag_dynamics()
        for factor, model in zip(self.exog_factoring, self._exog_models):
            assert model.shape[0] == model.shape[1] == np.prod(
                [len(self.exog_domains[var_ind]) for var_ind in factor])
            assert np.all(np.abs(model.sum(axis=1)-1) < 1e-5)
        # Other stuff.
        self.actions = list(range(4))
        self.action_names = {0: "UP", 1: "DOWN", 2: "LEFT", 3: "RIGHT"}
        self.gamma = constants.GAMMA
        self._init_st = ((1, 0),
                         (tuple(None for _ in range(self.num_exog_vars))))

    def endog_model(self, endog_state, action, exog_state, mask=None,
                    action_succ_prob=constants.ACTION_SUCC_PROB):
        """Model for the endogenous aspects of the world. Visible to the
        reduced MDP, since our focus is on the exogenous aspects of the world.
        """
        if endog_state == "SINK":
            return {"SINK": 1.0}
        robot_x, robot_y = endog_state
        if mask is None:
            mask = list(range(self.num_exog_vars))
        if robot_x == self.goalx and robot_y == self.goaly:
            return {"SINK": 1.0}
        action_fail_prob = (1-action_succ_prob)/3
        result = defaultdict(float)
        result[(max(robot_x-1, 0), robot_y)] += (
            action_succ_prob if action == 0 else action_fail_prob)
        result[(min(robot_x+1, self.sizex-1), robot_y)] += (
            action_succ_prob if action == 1 else action_fail_prob)
        result[(robot_x, max(robot_y-1, 0))] += (
            action_succ_prob if action == 2 else action_fail_prob)
        result[(robot_x, min(robot_y+1, self.sizey-1))] += (
            action_succ_prob if action == 3 else action_fail_prob)
        return result

    def reward(self, state, mask=None):
        """Reward function, returns a number. Visible to the reduced MDP.
        """
        if state[0] == "SINK":
            return 0
        (robot_x, robot_y), exog_state = state
        if mask is None:
            mask = list(range(self.num_exog_vars))
        assert len(exog_state) == len(mask)
        flagon = False
        real_obstacles = (0,)
        for m_i, exog_var in zip(mask, exog_state):
            if m_i in real_obstacles and \
               robot_x == exog_var[0] and robot_y == exog_var[1]:
                # Hitting certain objects is bad.
                return constants.HIT_OBJ_REWARD
            if exog_var == "ON":
                assert not flagon # can only have one indicator flag
                flagon = True
        if robot_x == self.goalx and robot_y == self.goaly and flagon:
            # Success is to reach the goal when the flag is on.
            return constants.SUCCESS_REWARD
        if robot_x == self.goalx and robot_y == self.goaly:
            # Lower reward for reaching the goal when the flag is off.
            return constants.FLAG_MISS_REWARD
        return 0

    def print_state(self, state, mask):
        """Print the given state to the terminal, under the given mask.
        """
        world = ([np.zeros((self.sizex, self.sizey), dtype=str)]+
                 ["Flag {}: UNSEEN".format(self._num_objs+i)
                  for i in range(self._num_flags)])
        (robot_x, robot_y), exog_state = state
        assert len(exog_state) == len(mask)
        for m_i, exog_var in zip(mask, exog_state):
            if m_i < self._num_objs:
                world[0][exog_var] = "O"
            else:
                world[m_i-self._num_objs+1] = "Flag {}: {}".format(
                    m_i, exog_var)
        world[0][self.goalx, self.goaly] = "G"
        world[0][robot_x, robot_y] = "R"
        print(world)

    def get_initial_state(self, _):
        """Return the initial state. Randomized object positions.
        """
        exog_state = []
        for i in range(self.num_exog_vars):
            domain = self.exog_domains[i]
            exog_state.append(domain[self._rand_state.choice(len(domain))])
        return (self._init_st[0], tuple(exog_state))

    def _define_object_dynamics(self, sizex):
        """Set up dynamics models for objects, which move around in the world
        and serve as obstacles for the robot.
        """
        mpr = constants.OBJS_MOVE_PROB
        def _one_move(loc):
            result = defaultdict(int)
            result[(loc,)] += 1-mpr
            result[((max(loc[0]-1, 0), loc[1]),)] += mpr/2
            result[((min(loc[0]+1, sizex-1), loc[1]),)] += mpr/2
            return result
        def _two_move(loc1, loc2):
            result = defaultdict(int)
            if loc1 != loc2:
                # Get objects to same position.
                result[(loc2, loc2)] = 1
                return result
            result[(loc1, loc2)] += 1-mpr
            result[((max(loc1[0]-1, 0), loc1[1]),
                    (max(loc2[0]-1, 0), loc2[1]))] += mpr/2
            result[((min(loc1[0]+1, sizex-1), loc1[1]),
                    (min(loc2[0]+1, sizex-1), loc2[1]))] += mpr/2
            return result
        # First half of objects: structured transition matrices.
        factor1_mat, factor2_mat = self._build_structured_transitions(
            _one_move, _two_move)
        # Second half of objects: random transition matrices.
        indices = list(itertools.product(*[range(len(self.exog_domains[i]))
                                           for i in self.exog_factoring[2]]))
        factor3_mat = self._rand_state.rand(len(indices), len(indices))
        factor3_mat /= factor3_mat.sum(axis=1, keepdims=True)
        indices = list(itertools.product(*[range(len(self.exog_domains[i]))
                                           for i in self.exog_factoring[3]]))
        factor4_mat = self._rand_state.rand(len(indices), len(indices))
        factor4_mat /= factor4_mat.sum(axis=1, keepdims=True)
        return [factor1_mat, factor2_mat, factor3_mat, factor4_mat]

    def _build_structured_transitions(self, one_move, two_move):
        domains = list(itertools.product(*[self.exog_domains[i]
                                           for i in self.exog_factoring[0]]))
        indices = list(itertools.product(*[range(len(self.exog_domains[i]))
                                           for i in self.exog_factoring[0]]))
        inds_to_doms = dict(zip(indices, domains))
        doms_to_inds = dict(zip(domains, indices))
        factor1_mat = np.zeros((len(indices), len(indices)))
        _, numj, numk = (len(self.exog_domains[i])
                         for i in self.exog_factoring[0])
        for i, j, k in indices:
            loci, locj, lock = inds_to_doms[(i, j, k)]
            ind = numj*numk*i+numk*j+k
            for nextij, probij in two_move(loci, locj).items():
                for nextk, probk in one_move(lock).items():
                    nni, nnj, nnk = doms_to_inds[nextij+nextk]
                    nind = numj*numk*nni+numk*nnj+nnk
                    factor1_mat[ind, nind] = probij*probk
        domains = list(itertools.product(*[self.exog_domains[i]
                                           for i in self.exog_factoring[1]]))
        indices = list(itertools.product(*[range(len(self.exog_domains[i]))
                                           for i in self.exog_factoring[1]]))
        inds_to_doms = dict(zip(indices, domains))
        doms_to_inds = dict(zip(domains, indices))
        factor2_mat = np.zeros((len(indices), len(indices)))
        _, numj = (len(self.exog_domains[i]) for i in self.exog_factoring[1])
        for i, j in indices:
            loci, locj = inds_to_doms[(i, j)]
            ind = numj*i+j
            for nextij, probij in two_move(loci, locj).items():
                nni, nnj = doms_to_inds[nextij]
                nind = numj*nni+nnj
                factor2_mat[ind, nind] = probij
        return factor1_mat, factor2_mat

    def _define_flag_dynamics(self):
        """Set up dynamics models for flags, which allow experimenting
        with correlation through time.
        """
        mpr = constants.FLAG_CHANGE_PROB
        def _one_move(flag):
            result = defaultdict(int)
            result[(flag,)] += 1-mpr
            result[(max(flag-1, 5),)] += mpr/2
            result[(min(flag+1, 7),)] += mpr/2
            return result
        def _correl_through_time1(flagj, flagk):
            """Dynamics where both flagj and flagk should get added to mask.
            """
            resultk = _one_move(flagk)
            result = {}
            for nextk, probk in resultk.items():
                if flagk == 7:
                    if flagj == 7:
                        result[("ON", 7)+nextk] = probk
                    else:
                        result[("OFF", 7)+nextk] = probk
                else:
                    result[("ON", 5)+nextk] = probk*0.1
                    result[("OFF", 5)+nextk] = probk*0.9
            return result
        def _correl_through_time2(_, flagk):
            """Dynamics where only flagk should get added to mask, not flagj.
            """
            resultk = _one_move(flagk)
            result = {}
            for nextk, probk in resultk.items():
                if flagk == 7:
                    result[("ON", 7)+nextk] = probk*0.8
                    result[("ON", 5)+nextk] = probk*0.2
                else:
                    result[("OFF", 7)+nextk] = probk*0.8
                    result[("OFF", 5)+nextk] = probk*0.2
            return result
        domains = list(itertools.product(*[self.exog_domains[i]
                                           for i in self.exog_factoring[4]]))
        indices = list(itertools.product(*[range(len(self.exog_domains[i]))
                                           for i in self.exog_factoring[4]]))
        inds_to_doms = dict(zip(indices, domains))
        doms_to_inds = dict(zip(domains, indices))
        factor5_mat = np.zeros((len(indices), len(indices)))
        _, numj, numk = (len(self.exog_domains[i])
                         for i in self.exog_factoring[4])
        for i, j, k in indices:
            _, flagj, flagk = inds_to_doms[(i, j, k)]
            ind = numj*numk*i+numk*j+k
            for nextijk, probijk in _correl_through_time1(flagj, flagk).items():
                nni, nnj, nnk = doms_to_inds[nextijk]
                nind = numj*numk*nni+numk*nnj+nnk
                factor5_mat[ind, nind] = probijk
        indices = list(itertools.product(*[range(len(self.exog_domains[i]))
                                           for i in self.exog_factoring[5]]))
        factor6_mat = self._rand_state.rand(len(indices), len(indices))
        factor6_mat /= factor6_mat.sum(axis=1, keepdims=True)
        return [factor5_mat, factor6_mat]


class FactoryMDP(SimpleMDP):
    """More realistic pybullet environment, with objects on tables.
    """
    def __init__(self): # pylint:disable=super-init-not-called
        self._rand_state = np.random.RandomState(seed=constants.SEED)
        # Number of exogenous variables in the system.
        # 17 = 8 stacks of 2 objs each, 4 humans, current order, next order.
        self.num_exog_vars = 22
        # self._valid_orders = [7, 15] # NOTE: robot can't reach object 15
        self._valid_orders = [0, 7] # harder valid_orders than [7, 15]
        if constants.RUN_PRECOMPUTED_POLICY:
            self._valid_orders = [0, 7]
        # The domain of each exogenous variable.
        self.exog_domains = (
            [[(0, 0), (1, 0), (2, 0)] for _ in range(5)]+
            [[(0, 1), (1, 1), (2, 1)] for _ in range(5)]+
            [[(0, 2), (1, 2), (2, 2)] for _ in range(5)]+
            [[(0, 3), (1, 3), (2, 3)] for _ in range(5)]+
            [self._valid_orders for _ in range(2)])
        # Set of indices of unobserved exogenous variables.
        self.unobserved_exog = {0, 2, 5, 7, 10, 12, 15, 17}
        # How the exogenous variable dynamics are factored.
        self.exog_factoring = [[0, 1, 2, 3], [4],
                               [5, 6, 7, 8], [9],
                               [10, 11, 12, 13], [14],
                               [15, 16, 17, 18], [19],
                               [20, 21]]
        assert len(flatten(self.exog_factoring)) == self.num_exog_vars
        self._exog_models = []
        self._exog_models += self._define_object_dynamics()
        self._exog_models += self._define_order_dynamics()
        for factor, model in zip(self.exog_factoring, self._exog_models):
            assert model.shape[0] == model.shape[1] == np.prod(
                [len(self.exog_domains[var_ind]) for var_ind in factor])
            assert np.all(np.abs(model.sum(axis=1)-1) < 1e-5)
        # Other stuff.
        self.actions = list(range(5))
        self.action_names = {0: "UP", 1: "DOWN", 2: "LEFT", 3: "RIGHT",
                             4: "COMMIT"}
        self.gamma = constants.GAMMA
        self._init_st = ((0, 0, False),
                         (tuple(None for _ in range(self.num_exog_vars))))
        if constants.PYBULLET_VISUALIZE:
            self._initialize_pybullet()
            self._prev_exog_state = None
            self._held_obj_transforms = None

    def endog_model(self, endog_state, action, exog_state, mask=None,
                    action_succ_prob=constants.ACTION_SUCC_PROB):
        """Model for the endogenous aspects of the world. Visible to the
        reduced MDP, since our focus is on the exogenous aspects of the world.
        """
        if endog_state == "SINK":
            return {"SINK": 1.0}
        robot_x, robot_y, committed = endog_state
        if mask is None:
            mask = list(range(self.num_exog_vars))
        at_correct = False
        for m_i, exog_var in zip(mask, exog_state):
            if m_i == self.num_exog_vars-2 and \
               exog_var in mask and \
               (robot_x, robot_y) == exog_state[mask.index(exog_var)]:
                at_correct = True
        if committed and at_correct:
            return {"SINK": 1.0}
        if action == 4:
            return {(robot_x, robot_y, True): 1.0} # commit always succeeds
        action_fail_prob = (1-action_succ_prob)/3
        result = defaultdict(float)
        result[(max(robot_x-1, 0), robot_y, False)] += (
            action_succ_prob if action == 0 else action_fail_prob)
        result[(min(robot_x+1, 2), robot_y, False)] += (
            action_succ_prob if action == 1 else action_fail_prob)
        result[(robot_x, max(robot_y-1, 0), False)] += (
            action_succ_prob if action == 2 else action_fail_prob)
        result[(robot_x, min(robot_y+1, 2), False)] += (
            action_succ_prob if action == 3 else action_fail_prob)
        return result

    def reward(self, state, mask=None):
        """Reward function, returns a number. Visible to the reduced MDP.
        """
        if state[0] == "SINK":
            return 0
        (robot_x, robot_y, committed), exog_state = state
        if mask is None:
            mask = list(range(self.num_exog_vars))
        assert len(exog_state) == len(mask)
        at_correct = False
        for m_i, exog_var in zip(mask, exog_state):
            # if m_i in (4, 9, 14, 19) and \
            #    robot_x == exog_var[0] and robot_y == exog_var[1]:
            #     return constants.CRASH_HUMAN_REWARD
            if m_i == self.num_exog_vars-2 and \
               exog_var in mask and \
               (robot_x, robot_y) == exog_state[mask.index(exog_var)]:
                at_correct = True
        if committed and at_correct:
            # Committed the correct object.
            return constants.SUCCESS_REWARD
        if committed:
            # Committed the wrong object.
            return constants.BAD_COMMIT_REWARD
        return 0

    def print_state(self, state, mask):
        """Print the given state to the terminal, under the given mask.
        """
        (robot_x, robot_y, committed), exog_state = state
        world = ([np.zeros((3, 4), dtype="<U16")]+
                 ["Order:"]+
                 [[None, None]]+
                 ["Committed: {}".format(committed)])
        assert len(exog_state) == len(mask)
        for m_i, exog_var in zip(mask, exog_state):
            if m_i < self.num_exog_vars-2:
                if m_i in [4, 9, 14, 19]: # human
                    world[0][exog_var] += "H"
                else:
                    world[0][exog_var] += "O"
            else:
                world[2][m_i-(self.num_exog_vars-2)] = exog_var
        world[0][robot_x, robot_y] += "R"
        print(world)

    def get_initial_state(self, simulate):
        """Return the initial state. Randomized object positions (but cannot
        intersect). If simulate is True, it means that this method is being
        called for the purpose of simulating trajectories with which to build
        empirical models. Otherwise, it's being called as the start point
        during runtime.
        """
        exog_state = []
        placed = set()
        for i in range(4):
            for j in range(2):
                while True:
                    domain = self.exog_domains[5*i+2*j]
                    choice = domain[self._rand_state.choice(len(domain))]
                    if choice not in placed:
                        break
                exog_state.append(choice)
                placed.add(choice)
                if simulate: # don't need to have stacks
                    domain = self.exog_domains[5*i+2*j+1]
                    choice = domain[self._rand_state.choice(len(domain))]
                exog_state.append(choice) # stack 2 objects
            domain = self.exog_domains[5*i+4]
            choice = domain[self._rand_state.choice(len(domain))]
            exog_state.append(choice) # human
        exog_state.append(self._rand_state.choice(self._valid_orders))
        exog_state.append(self._rand_state.choice(self._valid_orders))
        return (self._init_st[0], tuple(exog_state))

    def update_pybullet(self, state, init):
        """Update pybullet visualization, given the current state and a flag
        indicating whether it's the initial state.
        """
        (robot_x, robot_y, committed), exog_state = state
        assert len(exog_state) == self.num_exog_vars
        # Show current and next order.
        for objind, pid in self._valid_cur_order_objs.items():
            pybullet.resetBasePositionAndOrientation(
                pid, [0, -1.35, (constants.TABLE_Z
                                 if objind == exog_state[-2]
                                 else 100)],
                [0, 0, 0, 1])
        for objind, pid in self._valid_next_order_objs.items():
            pybullet.resetBasePositionAndOrientation(
                pid, [0, -1.65, (constants.TABLE_Z
                                 if objind == exog_state[-1]
                                 else 100)],
                [0, 0, 0, 1])
        if init:
            # Put robot at starting place.
            assert not committed
            pybullet.resetBasePositionAndOrientation(
                self._robot, [(robot_y-1.5)*2+0.5, robot_x, 0],
                pybullet.getQuaternionFromEuler([0, 0, np.pi/2]))
            # Put objects at initial positions on table.
            for i in range(4):
                for j in range(2):
                    objind = 5*i+2*j
                    assert exog_state[objind] == exog_state[objind+1]
                    obj_x, obj_y = exog_state[objind]
                    pid = self._objind_to_pid[objind]
                    pid_top = self._objind_to_pid[objind+1]
                    pybullet.resetBasePositionAndOrientation(
                        pid, [(obj_y-1.5)*2, obj_x, constants.TABLE_Z],
                        [0, 0, 0, 1])
                    pybullet.resetBasePositionAndOrientation(
                        pid_top, [(obj_y-1.5)*2, obj_x,
                                  constants.TABLE_Z+constants.OBJ_HEIGHT],
                        [0, 0, 0, 1])
            self._prev_exog_state = copy.deepcopy(exog_state)
            self._held_obj_transforms = defaultdict(dict)
            # Pause for a second before starting.
            for _ in range(10):
                pybullet.setGravity(0, 0, -10)
                time.sleep(0.1)
        else:
            # Handle robot moving.
            robot_loc, robot_orn = pybullet.getBasePositionAndOrientation(
                self._robot)
            changing_rows = abs(robot_loc[0]-((robot_y-1.5)*2+0.5)) > 0.1
            if changing_rows:
                self._move_bases([self._robot],
                                 [[robot_loc[0], 3, 0]],
                                 [robot_orn])
                self._move_bases([self._robot],
                                 [[(robot_y-1.5)*2+0.5, 3, 0]],
                                 [robot_orn])
            self._move_bases([self._robot],
                             [[(robot_y-1.5)*2+0.5, robot_x, 0]],
                             [robot_orn])
            if self.reward(state) == constants.SUCCESS_REWARD:
                # Hacky way to check for being done...
                self._visualize_commit(state)
                self._prev_exog_state = None # ascertain that we are done
                return
            # Handle humans moving objects.
            obj_moves_to_make = {}
            for i in range(4):
                for j in range(2):
                    objind = 5*i+2*j
                    if exog_state[objind] != self._prev_exog_state[objind]:
                        obj_moves_to_make[i] = (self._objind_to_pid[objind],
                                                self._objind_to_pid[objind+1],
                                                exog_state[objind][0])
            assert len(obj_moves_to_make) <= 4
            self._pybullet_humans_move_objs(obj_moves_to_make)
            # Handle humans moving to new location.
            pids = []
            target_locs = []
            target_orns = []
            for i in range(4):
                pid = self._humans[i]
                pids.append(pid)
                human_loc, human_orn = pybullet.getBasePositionAndOrientation(
                    pid)
                target_locs.append((human_loc[0], exog_state[5*i+4][0], 0))
                target_orns.append(human_orn)
            self._move_bases(pids, target_locs, target_orns)
            self._prev_exog_state = copy.deepcopy(exog_state)

    def _define_object_dynamics(self):
        """Set up dynamics models for objects, which move around the tables.
        """
        mpr = constants.OBJS_MOVE_PROB
        def _stacks_move(loci, locj, lock, locl):
            if loci != locj or lock != locl:
                # Invalid state, objects not stacked. Fix it!
                return {(loci, loci, lock, lock): 1}
            locs = {loci, lock}
            empty = [{(0, 0), (1, 0), (2, 0)}-locs,
                     {(0, 1), (1, 1), (2, 1)}-locs,
                     {(0, 2), (1, 2), (2, 2)}-locs,
                     {(0, 3), (1, 3), (2, 3)}-locs]
            empty = [v for v in empty if len(v) == 1]
            if not empty:
                # Invalid state, objects were overlapping.
                return {(loci, locj, lock, locl): 1}
            assert len(empty) == 1
            empty = empty[0].pop()
            return {(loci, locj, lock, locl): 1-mpr,
                    (empty, empty, lock, locl): mpr/2,
                    (loci, locj, empty, empty): mpr/2}
        def _human_move(loc):
            empty = [{(0, 0), (1, 0), (2, 0)}-{loc},
                     {(0, 1), (1, 1), (2, 1)}-{loc},
                     {(0, 2), (1, 2), (2, 2)}-{loc},
                     {(0, 3), (1, 3), (2, 3)}-{loc}]
            empty = [v for v in empty if len(v) == 2]
            assert len(empty) == 1
            empty = empty[0]
            return {(loc,): 1-mpr, (empty.pop(),): mpr/2, (empty.pop(),): mpr/2}
        factor_mats = []
        for factor_ind, factor in enumerate(self.exog_factoring):
            if len(factor) != 4:
                continue
            domains = list(itertools.product(*[self.exog_domains[i]
                                               for i in factor]))
            indices = list(itertools.product(*[range(len(self.exog_domains[i]))
                                               for i in factor]))
            inds_to_doms = dict(zip(indices, domains))
            doms_to_inds = dict(zip(domains, indices))
            factor_mats.append(np.zeros((len(indices), len(indices))))
            _, numj, numk, numl = (len(self.exog_domains[i]) for i in factor)
            for i, j, k, l in indices:
                loci, locj, lock, locl = inds_to_doms[(i, j, k, l)]
                ind = numj*numk*numl*i+numk*numl*j+numl*k+l
                for nexts, prob in _stacks_move(loci, locj, lock, locl).items():
                    nni, nnj, nnk, nnl = doms_to_inds[nexts]
                    nind = numj*numk*numl*nni+numk*numl*nnj+numl*nnk+nnl
                    factor_mats[-1][ind, nind] = prob
            human_factor = self.exog_factoring[factor_ind+1]
            domains = list(itertools.product(*[self.exog_domains[i]
                                               for i in human_factor]))
            indices = list(itertools.product(*[range(len(self.exog_domains[i]))
                                               for i in human_factor]))
            inds_to_doms = dict(zip(indices, domains))
            doms_to_inds = dict(zip(domains, indices))
            factor_mats.append(np.zeros((len(indices), len(indices))))
            for ind in indices:
                loc_human = inds_to_doms[ind]
                for next_loc_human, prob in _human_move(*loc_human).items():
                    nind = doms_to_inds[next_loc_human]
                    factor_mats[-1][ind[0], nind[0]] = prob
        return factor_mats

    def _define_order_dynamics(self):
        """Set up dynamics models for order, which tell the robot what
        its task is.
        """
        mpr = constants.ORDER_CHANGE_PROB
        def _order_change(flagi, flagj):
            result = defaultdict(int)
            optionsj = set(self._valid_orders)-{flagj}
            assert len(optionsj) == len(self._valid_orders)-1
            if not optionsj:
                optionsj = set(self._valid_orders)
            result[(flagi, flagj)] += (1-mpr)*(1-mpr)
            result[(flagj, flagj)] += mpr*(1-mpr)
            for option in optionsj:
                result[(flagi, option)] += (1-mpr)*mpr/len(optionsj)
                result[(flagj, option)] += mpr*mpr/len(optionsj)
            return result
        domains = list(itertools.product(*[self.exog_domains[i]
                                           for i in self.exog_factoring[-1]]))
        indices = list(itertools.product(*[range(len(self.exog_domains[i]))
                                           for i in self.exog_factoring[-1]]))
        inds_to_doms = dict(zip(indices, domains))
        doms_to_inds = dict(zip(domains, indices))
        factor_mat = np.zeros((len(indices), len(indices)))
        _, numj = (len(self.exog_domains[i])
                   for i in self.exog_factoring[-1])
        for i, j in indices:
            flagi, flagj = inds_to_doms[(i, j)]
            ind = numj*i+j
            for nextflags, prob in _order_change(flagi, flagj).items():
                nni, nnj = doms_to_inds[nextflags]
                nind = numj*nni+nnj
                factor_mat[ind, nind] = prob
        return [factor_mat]

    def _initialize_pybullet(self):
        self._tables = []
        self._humans = []
        self._objind_to_pid = {}
        self._valid_cur_order_objs = {}
        self._valid_next_order_objs = {}
        valid_ord_colors = [[1, 0, 0], [0, 1, 0]]
        assert len(valid_ord_colors) >= len(self._valid_orders)
        other_ord_color = [0, 0, 1]
        pybullet.connect(pybullet.GUI)
        pybullet.setGravity(0, 0, -10)
        pybullet.setAdditionalSearchPath("assets/")
        pybullet.loadURDF("plane.urdf")
        self._robot, = pybullet.loadSDF("kuka_with_gripper_recolored.sdf")
        self._reset_joints(self._robot)
        with open("assets/table.urdf", "w") as fil:
            fil.write(constants.TABLE_URDF.format(0.6, 0.6, 1, 0.25, 0.25, 1))
        with open("assets/table_long.urdf", "w") as fil:
            fil.write(constants.TABLE_URDF.format(1.2, 0.6, 1, 0.5, 0.25, 1))
        with open("assets/cylinder_black.urdf", "w") as fil:
            fil.write(constants.CYLINDER_URDF.format(
                constants.OBJ_RADIUS, constants.OBJ_HEIGHT, 0, 0, 0, 1))
        for i in range(4):
            human, = pybullet.loadSDF("kuka_with_gripper2.sdf")
            self._humans.append(human)
            pybullet.resetBasePositionAndOrientation(
                human, [(i-1.5)*2-0.5, 1, 0],
                pybullet.getQuaternionFromEuler([0, 0, -np.pi/2]))
            self._reset_joints(human)
            for j in range(3):
                self._tables.append(
                    pybullet.loadURDF("table.urdf", [(i-1.5)*2, j, 0]))
            for j in range(2):
                objind = 5*i+2*j
                if objind in self._valid_orders:
                    color = valid_ord_colors[self._valid_orders.index(objind)]
                else:
                    color = other_ord_color
                with open("assets/cylinder_{}.urdf".format(objind), "w") as fil:
                    fil.write(constants.CYLINDER_URDF.format(
                        constants.OBJ_RADIUS, constants.OBJ_HEIGHT,
                        color[0], color[1], color[2], 1))
                self._objind_to_pid[objind] = pybullet.loadURDF(
                    "assets/cylinder_{}.urdf".format(objind))
                self._objind_to_pid[objind+1] = pybullet.loadURDF(
                    "assets/cylinder_black.urdf")
                if objind in self._valid_orders:
                    with open("assets/cylinder_{}_transp.urdf".format(objind),
                              "w") as fil:
                        fil.write(constants.CYLINDER_URDF.format(
                            constants.OBJ_RADIUS, constants.OBJ_HEIGHT,
                            color[0], color[1], color[2], 0.5))
                    self._valid_cur_order_objs[objind] = pybullet.loadURDF(
                        "assets/cylinder_{}_transp.urdf".format(objind))
                    self._valid_next_order_objs[objind] = pybullet.loadURDF(
                        "assets/cylinder_{}_transp.urdf".format(objind))
        self._goal_table = pybullet.loadURDF("table_long.urdf", [0, -1.5, 0])
        for fil in glob.glob("assets/cylinder*.urdf"):
            os.remove(fil)
        for fil in glob.glob("assets/table*.urdf"):
            os.remove(fil)

    def _pybullet_humans_move_objs(self, obj_moves_to_make):
        # Move to current object locations.
        pids = []
        base_target_locs = []
        base_target_orns = []
        for i, (opid, _, _) in obj_moves_to_make.items():
            pid = self._humans[i]
            pids.append(pid)
            obj_y = pybullet.getBasePositionAndOrientation(opid)[0][1]
            human_loc, human_orn = pybullet.getBasePositionAndOrientation(pid)
            base_target_locs.append((human_loc[0], obj_y, 0))
            base_target_orns.append(human_orn)
        self._move_bases(pids, base_target_locs, base_target_orns)
        pids = []
        grip_target_locs = []
        grip_target_orns = []
        new_ys = []
        # Go to pre-grasp poses.
        for i, (opid, _, new_y) in obj_moves_to_make.items():
            pid = self._humans[i]
            pids.append(pid)
            obj_loc = pybullet.getBasePositionAndOrientation(opid)[0]
            grip_target_locs.append((obj_loc[0]-0.4, obj_loc[1],
                                     constants.TABLE_Z+constants.OBJ_HEIGHT/2))
            grip_target_orns.append(pybullet.getQuaternionFromEuler(
                [np.pi/2, 0, np.pi/2]))
            new_ys.append(new_y)
        self._move_grippers(pids, grip_target_locs, grip_target_orns)
        self._move_grippers(pids, grip_target_locs, grip_target_orns,
                            open_amt=0.5)
        # Go to grasp poses.
        for i, grip_target_loc in enumerate(grip_target_locs):
            grip_target_locs[i] = (grip_target_loc[0]+0.15,
                                   grip_target_loc[1],
                                   grip_target_loc[2])
        self._move_grippers(pids, grip_target_locs, grip_target_orns)
        self._move_grippers(pids, grip_target_locs, grip_target_orns,
                            open_amt=0.35)
        # Grab objects and go to post-grasp poses.
        for i, (opid, opid_upper, _) in obj_moves_to_make.items():
            pid = self._humans[i]
            self._grab_object(pid, opid)
            self._grab_object(pid, opid_upper)
        for i, grip_target_loc in enumerate(grip_target_locs):
            grip_target_locs[i] = (grip_target_loc[0],
                                   grip_target_loc[1],
                                   grip_target_loc[2]+0.6)
        self._move_grippers(pids, grip_target_locs, grip_target_orns)
        # Move to new object locations.
        pids = []
        base_target_locs = []
        base_target_orns = []
        for i, (opid, _, new_y) in obj_moves_to_make.items():
            pid = self._humans[i]
            pids.append(pid)
            human_loc, human_orn = pybullet.getBasePositionAndOrientation(pid)
            base_target_locs.append((human_loc[0], new_y, 0))
            base_target_orns.append(human_orn)
        self._move_bases(pids, base_target_locs, base_target_orns)
        # Go to place poses and drop objects.
        for i, grip_target_loc in enumerate(grip_target_locs):
            grip_target_locs[i] = (grip_target_loc[0],
                                   new_ys[i],
                                   grip_target_loc[2]-0.6)
        self._move_grippers(pids, grip_target_locs, grip_target_orns)
        for i in obj_moves_to_make:
            pid = self._humans[i]
            self._held_obj_transforms[pid] = {}
        self._move_grippers(pids, grip_target_locs, grip_target_orns,
                            open_amt=0.5)
        # Go to post-place poses.
        for i, grip_target_loc in enumerate(grip_target_locs):
            grip_target_locs[i] = (grip_target_loc[0]-0.15,
                                   grip_target_loc[1],
                                   grip_target_loc[2]+0.6)
        self._move_grippers(pids, grip_target_locs, grip_target_orns)
        self._move_grippers(pids, grip_target_locs, grip_target_orns,
                            open_amt=0)

    def _visualize_commit(self, state):
        """The final thing we visualize: robot moving the ordered object
        to the goal table.
        """
        objind = self._find_objind_at_robot(state)
        assert objind is not None
        opid = self._objind_to_pid[objind]
        opid_upper = self._objind_to_pid[objind+1]
        zval = constants.TABLE_Z+constants.OBJ_HEIGHT/2
        obj_loc = pybullet.getBasePositionAndOrientation(opid)[0]
        grip_target_locs = [[obj_loc[0]+0.4, obj_loc[1], zval]]
        grip_target_orns = [pybullet.getQuaternionFromEuler(
            [np.pi/2, 0, -np.pi/2])]
        self._move_grippers([self._robot], grip_target_locs, grip_target_orns)
        self._move_grippers([self._robot], grip_target_locs, grip_target_orns,
                            open_amt=0.5)
        grip_target_locs[0] = (grip_target_locs[0][0]-0.15,
                               grip_target_locs[0][1],
                               grip_target_locs[0][2])
        self._move_grippers([self._robot], grip_target_locs, grip_target_orns)
        self._move_grippers([self._robot], grip_target_locs, grip_target_orns,
                            open_amt=0.35)
        self._grab_object(self._robot, opid)
        self._grab_object(self._robot, opid_upper)
        grip_target_locs[0] = (grip_target_locs[0][0],
                               grip_target_locs[0][1],
                               grip_target_locs[0][2]+0.6)
        self._move_grippers([self._robot], grip_target_locs, grip_target_orns)
        # Move to goal table and place.
        robot_x = pybullet.getBasePositionAndOrientation(self._robot)[0][0]
        self._move_bases([self._robot], [[robot_x, -1, 0]],
                         [pybullet.getQuaternionFromEuler([0, 0, np.pi])])
        self._move_bases([self._robot], [[0, -1, 0]],
                         [pybullet.getQuaternionFromEuler([0, 0, np.pi])])
        grip_target_orns = [pybullet.getQuaternionFromEuler(
            [np.pi/2, 0, 0])]
        self._move_grippers([self._robot], [[0, -1.1, zval]],
                            grip_target_orns)
        self._held_obj_transforms[self._robot] = {}
        self._move_grippers([self._robot], [[0, -1.1, zval]],
                            grip_target_orns, open_amt=0.5)
        self._move_grippers([self._robot], [[0, -1.1, zval+0.6]],
                            grip_target_orns)
        self._move_grippers([self._robot], [[0, -1.1, zval+0.6]],
                            grip_target_orns, open_amt=0)

    @staticmethod
    def _find_objind_at_robot(state):
        (robot_x, robot_y, _), exog_state = state
        for i in range(4):
            for j in range(2):
                objind = 5*i+2*j
                if exog_state[objind] == (robot_x, robot_y):
                    return objind
        return None

    def _move_bases(self, pids, target_locs, target_orns, speed=None):
        if not pids:
            return
        dist = float("-inf")
        origs = []
        targets = []
        for pid, targ_loc, targ_orn in zip(pids, target_locs, target_orns):
            orig = np.r_[pybullet.getBasePositionAndOrientation(pid)]
            target = np.r_[targ_loc, targ_orn]
            origs.append(orig)
            targets.append(target)
            dist = max(dist, np.linalg.norm(target-orig))
        if speed is None:
            speed = constants.SPEED
        num_steps = int(np.ceil(abs(dist)/speed))
        for i in range(1, num_steps+1):
            for pid, orig, target in zip(pids, origs, targets):
                interp = orig*(1-i/num_steps)+target*i/num_steps
                pybullet.resetBasePositionAndOrientation(
                    pid, interp[:3], interp[3:])
                base_link = np.r_[pybullet.getLinkState(pid, 9)[:2]]
                # Handle grabbed objects.
                for opid, transf in self._held_obj_transforms[pid].items():
                    obj_loc, obj_orn = pybullet.multiplyTransforms(
                        base_link[:3], base_link[3:], transf[0], transf[1])
                    pybullet.resetBasePositionAndOrientation(
                        opid, obj_loc, obj_orn)
            time.sleep(0.01)

    def _move_grippers(self, pids, target_locs, target_orns,
                       open_amt=None, speed=None):
        if not pids:
            return
        njo = min(pybullet.getNumJoints(pids[0]), 7)
        num_iter = 0
        while True:
            num_iter += 1
            dist = float("-inf")
            origs = []
            targets = []
            old_open_amts = []
            for pid, targ_loc, targ_orn in zip(pids, target_locs, target_orns):
                orig = np.array([pybullet.getJointState(pid, joint_idx)[0]
                                 for joint_idx in range(njo)])
                target = np.array(pybullet.calculateInverseKinematics(
                    pid, endEffectorLinkIndex=6,
                    targetPosition=targ_loc,
                    targetOrientation=targ_orn, solver=0))[:njo]
                dist = max(dist, np.linalg.norm(target-orig))
                old_open_amt = pybullet.getJointState(pid, 11)[0]
                if open_amt is not None:
                    dist = max(dist, abs(old_open_amt-open_amt))
                origs.append(orig)
                targets.append(target)
                old_open_amts.append(old_open_amt)
            if dist < constants.MOVE_GRIPPER_DIST_THRESH or \
               num_iter == constants.MOVE_GRIPPER_MAX_ITER:
                return
            if speed is None:
                speed = constants.SPEED
            num_steps = int(np.ceil(abs(dist)/speed))
            for i in range(1, num_steps+1):
                for pid, orig, target, old_open_amt in zip(
                        pids, origs, targets, old_open_amts):
                    interp = orig*(1-i/num_steps)+target*i/num_steps
                    self._update_joints(pid, njo, interp)
                    if open_amt is not None:
                        # Open/close gripper to open_amt.
                        open_interp = (old_open_amt*(1-i/num_steps)+
                                       open_amt*i/num_steps)
                        pybullet.resetJointState(pid, 8, -open_interp)
                        pybullet.resetJointState(pid, 11, open_interp)
                    else:
                        pybullet.resetJointState(pid, 8, -old_open_amt)
                        pybullet.resetJointState(pid, 11, old_open_amt)
                    base_link = np.r_[pybullet.getLinkState(pid, 9)[:2]]
                    # Handle grabbed objects.
                    for opid, transf in self._held_obj_transforms[pid].items():
                        obj_loc, obj_orn = pybullet.multiplyTransforms(
                            base_link[:3], base_link[3:], transf[0], transf[1])
                        pybullet.resetBasePositionAndOrientation(
                            opid, obj_loc, obj_orn)
                time.sleep(0.01)

    def _grab_object(self, pid, opid):
        """Grab object. Takes in pid of agent and opid of object.
        """
        base_link_to_world = np.r_[pybullet.invertTransform(
            *pybullet.getLinkState(pid, 9)[:2])]
        world_to_obj = np.r_[pybullet.getBasePositionAndOrientation(opid)]
        self._held_obj_transforms[pid][opid] = pybullet.multiplyTransforms(
            base_link_to_world[:3], base_link_to_world[3:],
            world_to_obj[:3], world_to_obj[3:])

    @staticmethod
    def _update_joints(agent, njo, targets):
        for joint_idx in range(njo):
            pybullet.resetJointState(
                agent, joint_idx, targets[joint_idx])

    @staticmethod
    def _reset_joints(agent):
        for joint_idx in range(pybullet.getNumJoints(agent)):
            pybullet.resetJointState(agent, joint_idx, 0)
        # Keep gripper jaws parallel.
        pybullet.resetJointState(agent, 7, np.pi)
        pybullet.resetJointState(agent, 10, -0.1)
        pybullet.resetJointState(agent, 13, 0.1)

    @staticmethod
    def _test_pybullet():
        while True:
            pybullet.setGravity(0, 0, -10)
            time.sleep(0.1)
