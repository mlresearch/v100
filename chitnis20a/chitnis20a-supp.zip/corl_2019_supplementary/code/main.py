"""Plannability main function.
"""

import time
import constants
import environments
import reduced_envs
import masking_agents


def main():
    """Entry point.
    """
    mdp = getattr(environments, constants.ENVIRONMENT_TO_RUN)()
    print("\n\n\nEnvironment: {}\nMode: {} OBSERVABILITY".format(
        constants.ENVIRONMENT_TO_RUN, constants.OBSERVABILITY.upper()))
    print("Seed: {}".format(constants.SEED))
    start = time.time()
    for agent_name in constants.AGENTS_TO_RUN:
        this_start = time.time()
        agent_cls = getattr(masking_agents, agent_name)
        print("\n\n\nRunning agent {}".format(agent_name))
        reduced_mdp_cls = getattr(
            reduced_envs, "Reduced"+constants.ENVIRONMENT_TO_RUN)
        masking_agent = agent_cls(mdp, reduced_mdp_cls)
        masking_agent.build_best_reduced_mdp()
        masking_agent.plan()
        masking_agent.run(num_trials=constants.TEST_NUM_TRIALS)
        print("\nAgent total time: {:.5f} seconds".format(
            time.time()-this_start))
    print("\n\nTotal time: {:.5f} seconds".format(time.time()-start))


if __name__ == "__main__":
    main()
