"""Definitions of various masking agents.
"""

import time
import numpy as np
from util import subsets, is_sorted
import constants


class MaskingAgent:
    """An agent that searches over masks and finds the best one to plan with.
    """
    def __init__(self, mdp, reduced_mdp_cls):
        self._mdp = mdp
        self._reduced_mdp_cls = reduced_mdp_cls
        self._reduced_mdp = None
        self._qvals = None
        self._alpha_vecs = None
        self._rand_state = np.random.RandomState(seed=constants.SEED+2)
        self._reduced_mdp_cache = {}

    def build_best_reduced_mdp(self):
        """Choose a mask and create the corresponding reduced MDP.
        """
        mask = self._choose_mask()
        assert is_sorted(mask)
        print("\nThis agent chose mask {}".format(mask))
        if tuple(mask) in self._reduced_mdp_cache:
            self._reduced_mdp = self._reduced_mdp_cache[tuple(mask)]
        else:
            self._reduced_mdp = self._reduced_mdp_cls(mask, self._mdp)

    def plan(self):
        """Plan with the reduced MDP.
        """
        assert self._reduced_mdp is not None
        if constants.ENVIRONMENT_TO_RUN == "KitchenMDP":
            return
        if constants.OBSERVABILITY == "full":
            self._qvals = self._reduced_mdp.plan_fully_observed()
        elif constants.OBSERVABILITY == "partial":
            self._alpha_vecs = self._reduced_mdp.plan_partially_observed()

    def run(self, num_trials):
        """Run num_trials simulations in the actual (non-reduced) world.
        """
        print("Running in actual world...")
        if constants.ENVIRONMENT_TO_RUN != "KitchenMDP":
            assert self._qvals is not None or self._alpha_vecs is not None
        start = time.time()
        rewards = []
        trial = None
        for trial in range(num_trials):
            if constants.OBSERVABILITY == "full":
                rewards.append(self._reduced_mdp.run_fully_observed(
                    self._qvals, trial))
            else:
                rewards.append(self._reduced_mdp.run_partially_observed(
                    self._alpha_vecs, trial))
            if not constants.DO_PRINT and \
               time.time()-start > constants.RUN_TIMEOUT:
                break
        print("Run() with {} trials took {:.5f} seconds, avg reward: "
              "{:.5f}".format(trial+1, time.time()-start, np.mean(rewards)))
        return np.mean(rewards)

    def _choose_mask(self):
        """Abstract method that chooses a mask.
        """
        raise NotImplementedError("Need to override choose_mask()")


class NeverMaskingAgent(MaskingAgent):
    """A MaskingAgent that never actually does any masking, i.e. a baseline.
    """
    def _choose_mask(self):
        return list(range(self._mdp.num_exog_vars))


class SubsetMaskingAgent(MaskingAgent):
    """An agent that exhaustively tries all possible masks (subsets of
    exogenous state variables) to find the best one, per a regularized cost.
    """
    def _choose_mask(self):
        best_mask = None
        best_score = float("-inf")
        for mask in subsets(range(self._mdp.num_exog_vars)):
            mask = list(mask)
            if len(mask) > constants.SUBSET_MAX_MASK_SIZE:
                continue
            if mask and max(mask) > constants.SUBSET_MAX_MASK_VALUE:
                continue
            score = self._score_mask(mask)
            if score is None:
                continue
            if score > best_score:
                best_mask = mask
                best_score = score
        return best_mask

    def _score_mask(self, mask):
        print("\nTrying mask {}".format(mask))
        try:
            self._reduced_mdp = self._reduced_mdp_cls(mask, self._mdp)
            self._reduced_mdp_cache[tuple(mask)] = self._reduced_mdp
            start = time.time()
            self.plan()
            plan_time = time.time()-start
        except InvalidMaskException:
            print("Invalid mask, skipping")
            return None
        avg_reward = self.run(num_trials=constants.SUBSET_NUM_TRIALS)
        if constants.ENVIRONMENT_TO_RUN == "KitchenMDP":
            plan_time = (time.time()-start)/constants.SUBSET_NUM_TRIALS
        score = self._compute_score(avg_reward, plan_time, mask)
        print("Score = {:.5f}".format(score))
        return score

    @staticmethod
    def _compute_score(avg_reward, plan_time, mask):
        if constants.PENALTY_TYPE == "size":
            return avg_reward-constants.SCORE_LAMBDA*len(mask)
        if constants.PENALTY_TYPE == "time":
            return avg_reward-constants.SCORE_LAMBDA*plan_time
        raise Exception("Invalid penalty_type: {}".format(
            constants.PENALTY_TYPE))


class GreedyMaskingAgent(SubsetMaskingAgent):
    """An agent that greedily builds out a mask starting from nothing.
    Stops when the score starts to decrease.
    """
    def _choose_mask(self):
        mask = []
        if constants.ENVIRONMENT_TO_RUN == "KitchenMDP":
            # Give greedy a fighting chance.
            mask = [self._mdp.num_exog_vars-4,
                    self._mdp.num_exog_vars-3,
                    self._mdp.num_exog_vars-2,
                    self._mdp.num_exog_vars-1]
        score = float("-inf")
        last_mask = []
        while True:
            if len(mask) == self._mdp.num_exog_vars:
                return mask
            cur_score = self._score_mask(mask)
            if cur_score is not None:
                if cur_score < score:
                    return last_mask
                score = cur_score
            while True:
                var_to_add = self._rand_state.choice(self._mdp.num_exog_vars)
                if var_to_add not in mask:
                    break
            last_mask = mask
            mask = sorted(mask+[var_to_add])


class AverageGreedyMaskingAgent(GreedyMaskingAgent):
    """An agent that averages over many GreedyMaskingAgents.
    """
    def _choose_mask(self):
        masks = []
        for _ in range(constants.AVG_GREEDY_NUM_TRIALS):
            masks.append(super()._choose_mask())
        print("\nGot masks: {}".format(masks))
        return max(masks, key=masks.count)  # pick the mode


class RewardCorrelationGreedyMaskingAgent(SubsetMaskingAgent):
    """An agent that greedily builds out a mask starting from the variables
    estimated to be part of the reward function, using correlation to decide
    which variable to add next. Stops when the score starts to decrease.
    """
    def _choose_mask(self):
        if constants.RUN_PRECOMPUTED_POLICY:
            # Just a hack to be able to experiment with simulator without
            # having to wait for planning.
            return [0, 1, 7, 8, 20, 21]
        # Construct a dummy reduced model for use in computing correlation.
        dummy_mdp = self._reduced_mdp_cls(list(range(self._mdp.num_exog_vars)),
                                          self._mdp, dummy=True)
        # Generate initial mask by estimating variables relevant to reward.
        mask = self._construct_initial_mask(dummy_mdp)
        score = float("-inf")
        last_mask = []
        while True:
            if len(mask) == self._mdp.num_exog_vars:
                print("Stopping. Reason: added all variables")
                return mask
            cur_score = self._score_mask(mask)
            if cur_score is not None:
                if cur_score < score:
                    print("Stopping. Reason: score decreased")
                    return last_mask
                score = cur_score
            # Add variable most correlated with current mask.
            print("Computing mutual infos...")
            mutual_infos = {var: dummy_mdp.compute_mutual_info(mask, var)
                            for var in range(self._mdp.num_exog_vars)
                            if var not in mask
                            and var not in self._mdp.unobserved_exog}
            print(mutual_infos)
            var_to_add = max(mutual_infos, key=lambda var: mutual_infos[var])
            if mutual_infos[var_to_add] < constants.MUTUAL_INFO_THRESHOLD:
                print("Stopping. Reason: all mutual infos are below threshold")
                return mask
            last_mask = mask
            mask = sorted(mask+[var_to_add])
            print("Added variable {} to mask".format(var_to_add))

    def _construct_initial_mask(self, dummy_mdp):
        """Estimate variables relevant to reward in a Monte Carlo manner.
        """
        mask = []
        for i in range(self._mdp.num_exog_vars):
            dom = self._mdp.exog_domains[i]
            relevance = []
            for _ in range(constants.REWARD_ESTIMATION_NUM_STATES):
                state = dummy_mdp.get_random_state()
                rewards = []
                for _ in range(5):
                    val = dom[self._rand_state.choice(len(dom))]
                    this_state = (state[0], state[1][:i]+(val,)+state[1][i+1:])
                    rewards.append(self._mdp.reward(this_state))
                relevance.append(np.std(rewards))
            if np.mean(relevance) > 0:
                mask.append(i)
        return mask


class InvalidMaskException(Exception):
    """Exception of a particular mask not being supported by the current
    infrastructure. Ideally, should be able to support all masks.
    """
    pass
