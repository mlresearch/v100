"""Defines reduced versions of the environments in environments.py.
"""

from collections import defaultdict
import os
import re
import time
import itertools
import subprocess
import numpy as np
from util import (value_iteration, is_sorted, flatten, sample_from_dict)
import constants
import environments


class ReducedMDP:
    """Abstract class for defining the reduced MDP corresponding to a
    given mask. We can plan with this by first constructing an empirical model.
    """
    def __init__(self, mask, mdp, dummy=False):
        self._mask = mask
        self._mdp = mdp
        self._rand_state = np.random.RandomState(seed=constants.SEED+1)
        self._empirical_exog_models = {}
        # Stuff used by kitchen environment.
        self._all_data = []
        self._factors_tried = set()
        if not dummy:
            # Build all empirical models.
            for factor_ind, factor in enumerate(self._mdp.exog_factoring):
                if all(var_ind not in self._mask for var_ind in factor):
                    continue
                cnt = 0
                while True:
                    model = self._construct_empirical_model(factor_ind, factor)
                    if np.all(np.abs(model.sum(axis=1)-1) < 0.01):
                        break
                    cnt += 1
                    if cnt > 5:
                        missing = len(np.where(
                            np.abs(model.sum(axis=1)-1) >= 0.01)[0])
                        print(constants.PrintColors.HEADER, end="")
                        print("WARNING: {} iters of trying to build model "
                              "for factor {}, missing {} rows of {}".format(
                                  cnt, factor, missing, model.shape[0]))
                        print(constants.PrintColors.ENDC)
                        break
                self._empirical_exog_models[factor_ind] = model
            self._factors_tried = set()
            if constants.ENVIRONMENT_TO_RUN != "KitchenMDP":
                # Compute states and empirical rewards of the reduced MDP,
                # based on the given mask.
                self.states, emp_rewards = self._construct_states_and_rewards()
                if constants.OBSERVABILITY == "partial":
                    # Compute observations and observation probabilities.
                    self.observations = set()
                    for state in self.states:
                        self.observations.add(
                            (state[0], tuple(
                                val for i, val in zip(self._mask, state[1])
                                if i not in self._mdp.unobserved_exog)))
                    self.observations = list(self.observations)
                    print("Mask {} gives {} states, {} observations".format(
                        self._mask, len(self.states), len(self.observations)))
                    self._obs_model = np.zeros((len(self.states),
                                                len(self.observations)))
                    for i, state in enumerate(self.states):
                        j = self.observations.index(
                            (state[0], tuple(
                                val for i, val in zip(self._mask, state[1])
                                if i not in self._mdp.unobserved_exog)))
                        self._obs_model[i][j] = 1
                print("Mask {} gives {} states".format(
                    self._mask, len(self.states)))
                self.reward = lambda s: emp_rewards[s]
            else:
                self.reward = lambda s: self._mdp.reward(s, self._mask)
        self.actions = self._mdp.actions
        self.gamma = self._mdp.gamma
        self._plan_result = None

    def plan_partially_observed(self):
        """Construct POMDP file and call an external POMDP solver.
        Returns alpha vectors.
        """
        if self._plan_result is not None:
            print("Using cached plan result")
            return self._plan_result
        if constants.RUN_PRECOMPUTED_POLICY:
            fname = "data/precomputed.policy"
        else:
            with open("data/dummy_{}.pomdp".format(constants.SEED), "w") as fil:
                fil.write("discount: {}\n".format(self.gamma))
                fil.write("values: reward\n")
                fil.write("states: {}\n".format(len(self.states)))
                fil.write("actions: {}\n".format(len(self.actions)))
                fil.write("observations: {}\n\n".format(len(self.observations)))
                for i, state in enumerate(self.states):
                    for j, action in enumerate(self.actions):
                        for nexts, prob in self.model(state, action).items():
                            k = self.states.index(nexts)
                            fil.write("T : {} : {} : {} {}\n".format(
                                j, i, k, prob))
                fil.write("\nO : *\n")
                for i in range(len(self.states)):
                    for j in range(len(self.observations)):
                        fil.write("{} ".format(self._obs_model[i][j]))
                    fil.write("\n")
                fil.write("\n")
                for i, state in enumerate(self.states):
                    fil.write("R : * : {} : * : * {}\n".format(
                        i, self.reward(state)))
            if os.name == "nt":
                cmd_str = ("start /b "" appl/src/pomdpsol data/dummy_{}.pomdp --timeout {} "
                           "-o data/out_{}.policy".format(
                               constants.SEED,
                               constants.PLAN_TIMEOUT,
                               constants.SEED))
            else:
                cmd_str = ("./appl/src/pomdpsol data/dummy_{}.pomdp --timeout {} "
                           "-o data/out_{}.policy".format(
                    constants.SEED,
                    constants.PLAN_TIMEOUT,
                    constants.SEED))
            print(cmd_str)
            print("Running SARSOP...", end="", flush=True)
            start = time.time()
            subprocess.getoutput(cmd_str)
            print("took {:.3f} seconds, timeout was {:.3f} seconds".format(
                time.time()-start, constants.PLAN_TIMEOUT))
            fname = "data/out_{}.policy".format(constants.SEED)
        alpha_vecs = []
        with open(fname, "r") as fil:
            for line in fil:
                match = re.match(r'.*?action="(\d)".*?>(.*?)<.*', line)
                if match:
                    alpha_vecs.append((
                        int(match.groups()[0]),
                        np.array(match.groups()[1].split(), dtype=float)))
        if not constants.RUN_PRECOMPUTED_POLICY:
            os.remove("data/dummy_{}.pomdp".format(constants.SEED))
            os.remove("data/out_{}.policy".format(constants.SEED))
        self._plan_result = alpha_vecs
        return alpha_vecs

    def plan_fully_observed(self):
        """Plan using value iteration. Returns Q-values.
        """
        if self._plan_result is None:
            self._plan_result = value_iteration(self)
        else:
            print("Using cached plan result")
        return self._plan_result

    def model(self, state, action):
        """Transition model, returns dict of {next state: prob}.
        """
        endog_state, exog_state = state
        # Exogenous state transitions do not depend on endogenous state.
        exog_result = self._exog_model(exog_state)
        if constants.ENVIRONMENT_TO_RUN != "KitchenMDP":
            # Endogenous state transitions depend on exogenous state and action.
            endog_result = self._mdp.endog_model(endog_state, action,
                                                 exog_state, mask=self._mask)
        result = {}
        for exog_ns, exog_ns_prob in exog_result.items():
            if constants.ENVIRONMENT_TO_RUN == "KitchenMDP":
                # Endogenous transitions are based on next exogenous state.
                endog_result = self._mdp.endog_model(endog_state, action,
                                                     exog_ns, mask=self._mask)
            for endog_ns, endog_ns_prob in endog_result.items():
                prob = endog_ns_prob*exog_ns_prob
                if prob > 0:
                    result[(endog_ns, exog_ns)] = prob
        # Verify that transition probabilities roughly sum to 1.
        if abs(sum(result.values())-1) > 0.01:
            print(constants.PrintColors.HEADER, end="")
            print("WARNING: transition probs summed to {:.5f}".format(
                sum(result.values())), end="")
            print(constants.PrintColors.ENDC)
        return result

    def step(self, state, action):
        """Transition model sampler, returns a next state.
        """
        endog_state, exog_state = state
        # Exogenous state transitions do not depend on endogenous state.
        exog_ns = self._exog_step(exog_state)
        if constants.ENVIRONMENT_TO_RUN != "KitchenMDP":
            # Endogenous state transitions depend on exogenous state and action.
            endog_result = self._mdp.endog_model(endog_state, action,
                                                 exog_state, mask=self._mask)
        else:
            # Endogenous transitions are based on next exogenous state.
            endog_result = self._mdp.endog_model(endog_state, action,
                                                 exog_ns, mask=self._mask)
        endog_ns = sample_from_dict(endog_result, self._rand_state)
        return endog_ns, exog_ns

    def run_fully_observed(self, qvals, trial):
        """Run an episode in the actual world, following the policy induced by
        the given qvals, which must have been generated by self._mask.
        """
        if trial == 0:
            values = []
            for _ in range(100):
                state = self._mdp.get_initial_state(False)
                state_proj = self.project_state(state)
                values.append(max(qvals[state_proj, act]
                                  for act in self._mdp.actions))
            print("Average value of an initial state under this mask: "
                  "{:.5f}".format(np.mean(values)))
        itr = 0
        reward = 0
        no_mask = list(range(self._mdp.num_exog_vars)) # real world (no mask)
        state = self._mdp.get_initial_state(False)
        state_proj = self.project_state(state)
        state_seq = []
        state_proj_seq = []
        while state[0] != "SINK":
            if constants.DO_PRINT:
                print("REAL WORLD:")
                self._mdp.print_state(state, no_mask)
                print("MASKED WORLD:")
                self._mdp.print_state(state_proj, self._mask)
                input("!!")
            if constants.PYBULLET_VISUALIZE:
                self._mdp.update_pybullet(state, init=(itr == 0))
            rew = self._mdp.reward(state)*(self.gamma**itr)
            action = max(self.actions,
                         key=lambda act: qvals[state_proj, act])
            value = qvals[state_proj, action]
            if constants.DO_PRINT:
                print("Took action {} with value {:.5f}, got "
                      "reward {:.5f}".format(
                          self._mdp.action_names[action], value, rew))
            reward += rew
            itr += 1
            if itr > constants.MAX_STEPS_PER_TRIAL: # give up
                return 0
            state = self._mdp.step(state, action)
            state_proj = self.project_state(state)
        if constants.DO_PRINT:
            print("Done, got reward {:.5f}\n".format(reward))
        return reward

    def run_partially_observed(self, alpha_vecs, trial):
        """Run an episode in the actual world, following the policy induced by
        the given alpha vectors, which must have been generated by self._mask.
        """
        itr = 0
        reward = 0
        no_mask = list(range(self._mdp.num_exog_vars)) # real world (no mask)
        true_state = self._mdp.get_initial_state(False)
        obs_lst = self._obs_model[self.states.index(
            self.project_state(true_state))]
        obs = self.observations[self._rand_state.choice(range(len(obs_lst)),
                                                        p=obs_lst)]
        belief = np.zeros(len(self.states))
        for i, state in enumerate(self.states):
            cand_obs = (state[0],
                        tuple(val for i, val in zip(self._mask, state[1])
                              if i not in self._mdp.unobserved_exog))
            if cand_obs == obs:
                belief[i] = 1
        belief /= belief.sum()
        if trial == 0:
            print("Value of initial belief under this mask: {:.5f}".format(
                max(belief.dot(vec) for _, vec in alpha_vecs)))
        while true_state[0] != "SINK":
            if constants.DO_PRINT:
                print("REAL WORLD:")
                self._mdp.print_state(true_state, no_mask)
                print("BELIEF (OVER MASKED WORLDS):")
                for i, prob in enumerate(belief):
                    if prob > 0:
                        self._mdp.print_state(self.states[i], self._mask)
                        print("Probability of ^ = {:.5f}".format(prob))
                input("!!")
            if constants.PYBULLET_VISUALIZE:
                self._mdp.update_pybullet(true_state, init=(itr == 0))
            action, vec = max(
                alpha_vecs, key=lambda alpha_vec: belief.dot(alpha_vec[1]))
            value = belief.dot(vec)
            rew = self._mdp.reward(true_state)*(self.gamma**itr)
            if constants.DO_PRINT:
                print("Took action {} with value {:.5f}, got "
                      "reward {:.5f}".format(
                          self._mdp.action_names[action], value, rew))
            reward += rew
            itr += 1
            if itr > constants.MAX_STEPS_PER_TRIAL: # give up
                return 0
            true_state = self._mdp.step(true_state, action)
            # Belief update.
            new_belief = np.zeros(len(self.states))
            # Step 1: transition.
            for i in np.where(belief > 0)[0]:
                state = self.states[i]
                for next_state, prob in self.model(state, action).items():
                    k = self.states.index(next_state)
                    new_belief[k] += prob*belief[i]
            # Step 2: observation.
            obs_lst = self._obs_model[self.states.index(
                self.project_state(true_state))]
            obs_ind = self._rand_state.choice(range(len(obs_lst)), p=obs_lst)
            for i, state in enumerate(self.states):
                new_belief[i] *= self._obs_model[i][obs_ind]
            belief = new_belief
            if belief.sum() > 0:
                belief /= belief.sum()
            else:
                # Hack in case belief collapses...
                belief[self.states.index(self.project_state(true_state))] = 1
        if constants.DO_PRINT:
            print("Done, got reward {:.5f}\n".format(reward))
        return reward

    def project_state(self, state):
        """Project the given full state to one used under self._mask.
        """
        raise NotImplementedError("Override this!")

    def compute_mutual_info(self, mask, var_to_add):
        """Compute the mutual information between var_to_add and the
        variables in the given mask. This is the KL divergence between
        the empirical joint and the empirical product of the marginals.
        """
        assert is_sorted(mask)
        assert isinstance(var_to_add, int)
        assert var_to_add not in mask
        orig_mask = self._mask
        factor_ind, factor = None, None
        for factor_ind, factor in enumerate(self._mdp.exog_factoring):
            if var_to_add in factor:
                break
        mask = [mask[i] for i in range(len(mask)) if mask[i] in factor]
        if not mask:
            return 0
        self._mask = mask
        empirical_marg1 = self._construct_empirical_model(factor_ind, factor)
        domains1 = list(itertools.product(
            *[self._mdp.exog_domains[var_ind] for var_ind in self._mask]))
        self._mask = [var_to_add]
        empirical_marg2 = self._construct_empirical_model(factor_ind, factor)
        domains2 = list(itertools.product(
            *[self._mdp.exog_domains[var_ind] for var_ind in self._mask]))
        self._mask = sorted(mask+[var_to_add])
        empirical_joint = self._construct_empirical_model(factor_ind, factor)
        domains = list(itertools.product(
            *[self._mdp.exog_domains[var_ind] for var_ind in self._mask]))
        to_add_ind = self._mask.index(var_to_add)
        mutual_info = 0
        for i, state in enumerate(domains):
            state1 = state[:to_add_ind]+state[to_add_ind+1:]
            nextd1 = empirical_marg1[domains1.index(state1)]
            state2 = state[to_add_ind:to_add_ind+1]
            nextd2 = empirical_marg2[domains2.index(state2)]
            nextdj = empirical_joint[i]
            for j, nextstate in enumerate(domains):
                nextstate1 = nextstate[:to_add_ind]+nextstate[to_add_ind+1:]
                nextprob1 = nextd1[domains1.index(nextstate1)]
                nextstate2 = nextstate[to_add_ind:to_add_ind+1]
                nextprob2 = nextd2[domains2.index(nextstate2)]
                nextprobmarg = nextprob1*nextprob2
                nextprobj = nextdj[j]
                if nextprobj > 0 and nextprobmarg > 0:
                    mutual_info += nextprobj*np.log(nextprobj/nextprobmarg)
        mutual_info /= len(domains)*len(domains)
        self._mask = orig_mask
        return mutual_info

    def get_random_state(self):
        """Get a random state. Useful for estimating contribution of state
        variables to reward in a Monte Carlo manner.
        """
        raise NotImplementedError("Override this!")

    def _construct_states_and_rewards(self):
        raise NotImplementedError("Override this!")

    def _construct_empirical_model(self, factor_ind, factor):
        """Construct the empirical model corresponding to the given factor,
        indexed by the given factor_ind.
        """
        empirical_model = []
        data = self._simulate_trajectories(factor_ind, factor)
        domains = [self._mdp.exog_domains[var_ind] for var_ind in factor
                   if var_ind in self._mask]
        assert domains
        single_data = defaultdict(int)
        double_data = defaultdict(int)
        for traj in data:
            for i, elem in enumerate(traj[:-1]):
                single_data[elem] += 1
                double_data[(elem, traj[i+1])] += 1
        for exog_states in itertools.product(*domains):
            denom = single_data[exog_states]
            empirical_model.append([])
            for exog_states_next in itertools.product(*domains):
                numer = double_data[(exog_states, exog_states_next)]
                empirical_model[-1].append(numer/denom if denom > 0 else 0)
        return np.array(empirical_model)

    def _simulate_trajectories(self, factor_ind, factor):
        """Simulate trajectories of the given factor, leveraging exogeneity so
        that we don't have to condition on a policy.
        """
        if constants.ENVIRONMENT_TO_RUN == "KitchenMDP":
            # Slightly different way of collecting data.
            return self._kitchen_simulate_trajectories(factor)
        trajs = []
        for _1 in range(constants.SIMULATION_NUM_TRAJ):
            init_exog_state = self._mdp.get_initial_state(True)[1]
            exog_vars = tuple(init_exog_state[var_ind] for var_ind in factor)
            traj = [tuple(var for i, var in enumerate(exog_vars)
                          if factor[i] in self._mask)]
            for _2 in range(constants.SIMULATION_TRAJ_LEN-1):
                exog_vars = self._mdp.exog_model_step(exog_vars, factor_ind)
                traj.append(tuple(var for i, var in enumerate(exog_vars)
                                  if factor[i] in self._mask))
            trajs.append(traj)
        return trajs

    def _kitchen_simulate_trajectories(self, factor):
        """Collect data in a slightly different way due to environment not
        defining a factor-specific step().
        """
        if not self._all_data or tuple(factor) in self._factors_tried:
            # Collect more data if we have none, or if we failed to build
            # this factor's model before.
            print("Collecting more data for kitchen environment...",
                  end="", flush=True)
            for _1 in range(constants.SIMULATION_NUM_TRAJ):
                exog_state = self._mdp.get_initial_state(True)[1]
                traj = [exog_state]
                for _2 in range(constants.SIMULATION_TRAJ_LEN-1):
                    exog_state = self._mdp.exog_model_step(exog_state)
                    traj.append(exog_state)
                self._all_data.append(traj)
            print("done")
        self._factors_tried.add(tuple(factor))
        result = []
        for traj in self._all_data:
            result.append([])
            for exog_state in traj:
                exog_vars = tuple(exog_state[var_ind] for var_ind in factor)
                result[-1].append(tuple(var for i, var in enumerate(exog_vars)
                                        if factor[i] in self._mask))
        return result

    def _exog_model(self, exog_state):
        exog_var_dict = dict(zip(self._mask, exog_state))
        factor_results = []
        for factor_ind, factor in enumerate(self._mdp.exog_factoring):
            if all(var_ind not in self._mask for var_ind in factor):
                continue
            exog_vars = tuple(exog_var_dict[var_ind] for var_ind in factor
                              if var_ind in self._mask)
            domains = list(itertools.product(
                *[self._mdp.exog_domains[var_ind] for var_ind in factor
                  if var_ind in self._mask]))
            model = self._empirical_exog_models[factor_ind]
            next_dist = model[domains.index(exog_vars)]
            factor_results.append({domains[i]: prob for i, prob
                                   in enumerate(next_dist)})
        result = {}
        for next_state in itertools.product(*factor_results):
            try:
                prob = np.prod([nexts[var] for nexts, var
                                in zip(factor_results, next_state)])
            except KeyError:
                continue
            if prob > 0:
                result[tuple(flatten(next_state))] = prob
        return result

    def _exog_step(self, exog_state):
        exog_var_dict = dict(zip(self._mask, exog_state))
        result = tuple()
        for factor_ind, factor in enumerate(self._mdp.exog_factoring):
            if all(var_ind not in self._mask for var_ind in factor):
                continue
            exog_vars = tuple(exog_var_dict[var_ind] for var_ind in factor
                              if var_ind in self._mask)
            domains = list(itertools.product(
                *[self._mdp.exog_domains[var_ind] for var_ind in factor
                  if var_ind in self._mask]))
            model = self._empirical_exog_models[factor_ind]
            next_dist = model[domains.index(exog_vars)]
            choice = sample_from_dict(
                {domains[i]: prob for i, prob in enumerate(next_dist)},
                self._rand_state)
            if len(choice) > 1:
                choice = (choice,)
            result += choice
        if not len(result) == len(self._mask):
            # Hack ordering to be correct for processing within this class.
            result = list(result)
            for poss in [-2, -3, -4]:
                if isinstance(result[poss][1], tuple):
                    result = [result[poss][1]]+result
                    result[poss] = result[poss][0]
            result = tuple(result)
        return result


class ReducedSimpleMDP(ReducedMDP):
    """ReducedMDP for the SimpleMDP environment.
    """
    def __init__(self, mask, mdp, dummy=False):
        assert isinstance(mdp, environments.SimpleMDP)
        super().__init__(mask, mdp, dummy)

    def project_state(self, state):
        """Project the given full state to one used under self._mask.
        """
        endog_state, exog_state = state
        # WARNING: assuming here that umbrella is index num_exog_vars-1.
        if endog_state != "SINK" and \
           self._mdp.num_exog_vars-1 not in self._mask:
            # Mask ignores umbrella, so should ignore holding_umbrella too.
            endog_state = (endog_state[0], endog_state[1], False)
        assert len(exog_state) == self._mdp.num_exog_vars # given state is full
        exog_state = tuple(exog_state[m_i] for m_i in self._mask)
        return (endog_state, exog_state)

    def get_random_state(self):
        """Get a random state. Useful for estimating contribution of state
        variables to reward in a Monte Carlo manner.
        """
        robot_x = self._rand_state.choice(self._mdp.sizex)
        robot_y = self._rand_state.choice(self._mdp.sizey)
        holding_umbrella = (self._rand_state.choice([False, True])
                            if self._mdp.num_exog_vars-1 in self._mask
                            else False)
        domains = [self._mdp.exog_domains[m_i] for m_i in self._mask]
        exog_states = []
        for domain in domains:
            exog_states.append(domain[self._rand_state.choice(len(domain))])
        return ((robot_x, robot_y, holding_umbrella), tuple(exog_states))

    def _construct_states_and_rewards(self):
        states = []
        emp_rewards = {}
        # WARNING: assuming here that umbrella is index num_exog_vars-1.
        holding_umbrella_domain = ([False, True] if self._mdp.num_exog_vars-1
                                   in self._mask else [False])
        domains = [self._mdp.exog_domains[m_i] for m_i in self._mask]
        for i in range(self._mdp.sizex):
            for j in range(self._mdp.sizey):
                for holding_umbrella in holding_umbrella_domain:
                    for exog_states in itertools.product(*domains):
                        state = ((i, j, holding_umbrella), exog_states)
                        states.append(state)
                        emp_rewards[state] = self._mdp.reward(state, self._mask)
        for exog_states in itertools.product(*domains):
            state = ("SINK", exog_states)
            states.append(state)
            emp_rewards[state] = self._mdp.reward(state, self._mask)
        return states, emp_rewards


class ReducedBigMDP(ReducedMDP):
    """ReducedMDP for the BigMDP environment.
    """
    def __init__(self, mask, mdp, dummy=False):
        assert isinstance(mdp, environments.BigMDP)
        super().__init__(mask, mdp, dummy)

    def project_state(self, state):
        """Project the given full state to one used under self._mask.
        """
        endog_state, exog_state = state
        assert len(exog_state) == self._mdp.num_exog_vars # given state is full
        exog_state = tuple(exog_state[m_i] for m_i in self._mask)
        return (endog_state, exog_state)

    def get_random_state(self):
        """Get a random state. Useful for estimating contribution of state
        variables to reward in a Monte Carlo manner.
        """
        robot_x = self._rand_state.choice(self._mdp.sizex)
        robot_y = self._rand_state.choice(self._mdp.sizey)
        domains = [self._mdp.exog_domains[m_i] for m_i in self._mask]
        exog_states = []
        for domain in domains:
            exog_states.append(domain[self._rand_state.choice(len(domain))])
        return ((robot_x, robot_y), tuple(exog_states))

    def _construct_states_and_rewards(self):
        states = []
        emp_rewards = {}
        domains = [self._mdp.exog_domains[m_i] for m_i in self._mask]
        for i in range(self._mdp.sizex):
            for j in range(self._mdp.sizey):
                for exog_states in itertools.product(*domains):
                    state = ((i, j), exog_states)
                    states.append(state)
                    emp_rewards[state] = self._mdp.reward(state, self._mask)
        for exog_states in itertools.product(*domains):
            state = ("SINK", exog_states)
            states.append(state)
            emp_rewards[state] = self._mdp.reward(state, self._mask)
        return states, emp_rewards


class ReducedFactoryMDP(ReducedMDP):
    """ReducedMDP for the FactoryMDP environment.
    """
    def __init__(self, mask, mdp, dummy=False):
        assert isinstance(mdp, environments.FactoryMDP)
        super().__init__(mask, mdp, dummy)

    def project_state(self, state):
        """Project the given full state to one used under self._mask.
        """
        endog_state, exog_state = state
        assert len(exog_state) == self._mdp.num_exog_vars # given state is full
        exog_state = tuple(exog_state[m_i] for m_i in self._mask)
        return (endog_state, exog_state)

    def get_random_state(self):
        """Get a random state. Useful for estimating contribution of state
        variables to reward in a Monte Carlo manner.
        """
        robot_x = self._rand_state.choice(3)
        robot_y = self._rand_state.choice(3)
        committed = self._rand_state.choice([False, True])
        domains = [self._mdp.exog_domains[m_i] for m_i in self._mask]
        exog_states = []
        for domain in domains:
            exog_states.append(domain[self._rand_state.choice(len(domain))])
        return ((robot_x, robot_y, committed), tuple(exog_states))

    def _construct_states_and_rewards(self):
        states = []
        emp_rewards = {}
        domains = [self._mdp.exog_domains[m_i] for m_i in self._mask]
        for i in range(3):
            for j in range(3):
                for committed in [False, True]:
                    for exog_states in itertools.product(*domains):
                        state = ((i, j, committed), exog_states)
                        states.append(state)
                        emp_rewards[state] = self._mdp.reward(state, self._mask)
        for exog_states in itertools.product(*domains):
            state = ("SINK", exog_states)
            states.append(state)
            emp_rewards[state] = self._mdp.reward(state, self._mask)
        return states, emp_rewards
