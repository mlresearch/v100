# Learning Compact Models for Planning with Exogenous Processes

Experiments with planning using only a subset of exogenous variables.

To download dependencies, from an environment with Python 3 simply run `pip install -r requirements.txt`.

Run `python main.py` to execute the algorithm on the Factory domain. Settings can be changed in the `constants.py` file as necessary.

Code acknowledgements:
* assets/ folder contains Pybullet assets.
* To run partial observability mode, download and compile the appl/ directory from [this website](http://bigbird.comp.nus.edu.sg/pmwiki/farm/appl/), in order to obtain the `appl/src/pomdpsol` binary.
