"""Utility methods.
"""

from collections import defaultdict
import time
import heapq
import re
import itertools
import numpy as np
import constants


class StateWrapper:
    """State wrapper for MCTS.
    """
    def __init__(self, mdp, state):
        self.mdp = mdp
        self.state = state

    def step(self, action):
        """Step function.
        """
        return StateWrapper(self.mdp, self.mdp.step(self.state, action))

    def reward(self):
        """Reward function.
        """
        return self.mdp.reward(self.state)

    def terminal(self):
        """Terminal checker function.
        """
        return self.state[0] == "SINK"

    def __repr__(self):
        return repr(self.state)

    def __str__(self):
        return str(self.state)

    def __hash__(self):
        return hash(self.state)

    def __eq__(self, other):
        return self.state == other.state


def lin_interp(in_low, in_high, out_low, out_high, in_val):
    """Returns an out_val.
    """
    slope = (out_high-out_low)/(in_high-in_low)
    return out_low+slope*(in_val-in_low)


def value_iteration(mdp, eps=0.01, max_iters=1000):
    """Value iteration. The given MDP is an object with:
    - attributes "states", "actions", "gamma"
    - function "reward(s)", returns a number
    - function "model(s, a)", returns a dict of {next state: prob}
    """
    print("Running VI...", end="", flush=True)
    start = time.time()
    qvals = {(s, a): 0 for s in mdp.states for a in mdp.actions}
    itr = 0
    while True:
        new_qvals = qvals.copy()
        delta = 0
        for state in mdp.states:
            rew = mdp.reward(state)
            for action in mdp.actions:
                expec = sum(ns_prob*max(qvals[ns, na] for na in mdp.actions)
                            for ns, ns_prob in mdp.model(state, action).items())
                new_qvals[state, action] = rew+mdp.gamma*expec
                delta = max(delta, abs(new_qvals[state, action]-
                                       qvals[state, action]))
        qvals = new_qvals
        if delta < eps or itr == max_iters or \
           time.time()-start > constants.PLAN_TIMEOUT:
            break
        itr += 1
    print("returned in {} iters, delta {:.5f}, took {:.3f} seconds, "
          "timeout was {:.3f} seconds".format(
              itr, delta, time.time()-start, constants.PLAN_TIMEOUT))
    return qvals


def prioritized_value_iteration(mdp, eps=0.01, max_iters=1000):
    """Prioritized sweeping value iteration. Same arguments as above.
    """
    print("Running prioritized sweeping VI...", end="", flush=True)
    start = time.time()
    vals = {s: 0 for s in mdp.states}
    itr = 0
    preds = defaultdict(set)
    pqueue = PriorityQueue()
    for state in mdp.states:
        if time.time()-start > constants.PLAN_TIMEOUT:
            break
        value = float("-inf")
        for action in mdp.actions:
            expec = 0
            for nextst, prob in mdp.model(state, action).items():
                if prob > 0:
                    preds[nextst].add(state)
                    expec += prob*vals[nextst]
            value = max(mdp.reward(state)+mdp.gamma*expec, value)
        diff = abs(value-vals[state])
        pqueue.update(state, -diff)
    while True:
        if pqueue.is_empty() or itr == max_iters or \
           time.time()-start > constants.PLAN_TIMEOUT:
            break
        state = pqueue.pop()
        vals[state] = max(mdp.reward(state)+
                          mdp.gamma*sum(prob*vals[nextst] for nextst, prob
                                        in mdp.model(state, action).items())
                          for action in mdp.actions)
        for prev in preds[state]:
            prev_value = max(mdp.reward(prev)+
                             mdp.gamma*sum(prob*vals[nextst] for nextst, prob
                                           in mdp.model(prev, action).items())
                             for action in mdp.actions)
            diff = abs(prev_value-vals[prev])
            if diff > eps:
                pqueue.update(prev, -diff)
        itr += 1
    qvals = {(s, a): 0 for s in mdp.states for a in mdp.actions}
    for state in mdp.states:
        if time.time()-start > constants.PLAN_TIMEOUT:
            break
        for action in mdp.actions:
            qvals[state, action] = mdp.reward(state)+mdp.gamma*sum(
                prob*vals[nextst] for nextst, prob
                in mdp.model(state, action).items())
    print("returned in {} iters, final pqueue size {}, took {:.3f} seconds, "
          "timeout was {:.3f} seconds".format(
              itr, len(pqueue.heap), time.time()-start,
              constants.PLAN_TIMEOUT))
    return qvals


def expectimax(mdp, state, action, horizon):
    """Expectimax to a given horizon. MDP is same as for value_iteration above.
    """
    if horizon == 0:
        return 0
    rew = mdp.reward(state)
    recurval = sum(ns_prob*max(expectimax(mdp, ns, na, horizon-1)
                               for na in mdp.actions)
                   for ns, ns_prob in mdp.model(state, action).items())
    return rew+mdp.gamma*recurval


def subsets(iterable):
    """Return an iterator over subsets of the given iterable.
    """
    lst = list(iterable)
    return itertools.chain.from_iterable(
        itertools.combinations(lst, r) for r in range(len(lst)+1))


def flatten(iterable):
    """Return a flattened version of the given iterable.
    """
    return [y for x in iterable for y in x]


def is_sorted(iterable):
    """Return whether the given iterable is sorted.
    """
    return all(iterable[i] <= iterable[i+1] for i in range(len(iterable)-1))


def count_subseq(iterable, seq):
    """Return number of occurrences of subsequence seq within iterable.
    """
    return sum(iterable[i:i+len(seq)] == seq
               for i in range(len(iterable)-len(seq)+1))


def sample_from_dict(dic, rand_state):
    """Sample a key from a dictionary according to probabilities given
    by the values.
    """
    nexts, probs = list(zip(*dic.items()))
    probs = np.array(probs)
    probs = probs / probs.sum()
    return nexts[rand_state.choice(len(nexts), p=probs)]


def astar_search(init_state, successor, goal_test, heuristic):
    """Run A* search to get a cost-optimal plan.

    init_state is the initial state.
    successor(state) returns a sequence of (action, cost, next_state).
    goal_test(state) checks whether the state satisfies the goal criteria.
    heuristic(state) returns the heuristic cost to the goal from that state.

    Returns a tuple of (plan, plan_cost, state_sequence). If the
    plan has length n, the state sequence has length n+1. state_sequence[i]
    is the state before running the action given by plan[i].
    """
    pqueue = PriorityQueue()
    visited = set()
    root = SearchTreeEntry(init_state,
                           state_sequence=[],
                           action_sequence=[],
                           cost=0,
                           cost_sequence=[0])
    pqueue.push(root, heuristic(init_state))
    nodes_expanded = 0
    while not pqueue.is_empty():
        entry = pqueue.pop()
        if goal_test(entry.state):
            entry.state_sequence.append(entry.state)
            # print("expanded {} nodes".format(nodes_expanded))
            cost_to_go = entry.cost_sequence[-1]-np.array(entry.cost_sequence)
            cost_to_go_pred = [heuristic(s) for s in entry.state_sequence]
            assert all(cost_to_go_pred <= cost_to_go), \
                "Heuristic is not admissible"
            return entry.action_sequence, entry.cost, entry.state_sequence
        if entry.state not in visited:
            visited.add(entry.state)
            nodes_expanded += 1
            for action, cost, next_state in successor(entry.state):
                new_entry = SearchTreeEntry(
                    next_state,
                    entry.state_sequence+[entry.state],
                    entry.action_sequence+[action],
                    entry.cost+cost,
                    entry.cost_sequence+[entry.cost+cost])
                pqueue.push(new_entry, entry.cost+cost+heuristic(next_state))
    raise Exception("No plan found!")


def obj_to_obj_type(obj):
    """Convert object to object type.
    """
    return re.match(r"([A-Za-z]+)\d+", obj).groups()[0]


def distance_euc(pos1, pos2):
    """Euclidean distance between two 2D points.
    """
    xv1, yv1 = pos1
    xv2, yv2 = pos2
    return np.sqrt((xv1-xv2)**2+(yv1-yv2)**2)


def distance_man(pos1, pos2):
    """Manhattan distance between two 2D points.
    """
    xv1, yv1 = pos1
    xv2, yv2 = pos2
    return np.abs(xv1-xv2)+np.abs(yv1-yv2)


def powerset(num):
    """Return the powerset of range(num).
    """
    vals = list(range(num))
    return itertools.chain.from_iterable(itertools.combinations(vals, r)
                                         for r in range(len(vals)+1))


def csp_solver(solution, assignments, valid, solver, forward_check,
               to_hashable):
    """Arguments:
      solution: map to modify
      assignments: dict mapping each solution key to distribution
        over possible values
      valid: function mapping solution to whether it satisfies all constraints
      solver: "backtracking" or "randomized"
      forward_check: takes in used set and an assignment, returns True if okay
      map from each solution value to a hashable object
    """
    if solver == "backtracking":
        _run_backtracking(solution, assignments, valid)
    elif solver == "randomized":
        _run_randomized(solution, assignments, valid, forward_check,
                        to_hashable)
    else:
        raise Exception("Unrecognized solver: {}".format(solver))


def _run_backtracking(solution, assignments, valid):
    generators = {}
    # Assign fully constrained values first.
    for sol_key in assignments:
        poss_vals = assignments[sol_key].get_sorted_vals()
        if len(poss_vals) == 1:
            solution[sol_key] = poss_vals[0]
        else:
            generators[sol_key] = poss_vals
    if not generators:
        if not valid(solution):
            raise CSPSolverFailed("Only possible instantiation was invalid")
        return
    bt_ind = 0
    generators_pos = {sol_key: 0 for sol_key in generators}
    sol_keys = list(generators)
    # Solve the CSP in a random order.
    inds = np.random.permutation(len(sol_keys))
    sol_keys = [sol_keys[i] for i in inds]
    while True:
        sol_key = sol_keys[bt_ind]
        if generators_pos[sol_key] == len(generators[sol_key]):
            # Replenish generator and backtrack.
            if bt_ind == 0:
                raise CSPSolverFailed("No valid instantiation found")
            generators_pos[sol_key] = 0
            solution[sol_key] = None
            bt_ind -= 1
            continue
        sol_value = generators[sol_key][generators_pos[sol_key]]
        generators_pos[sol_key] += 1
        solution[sol_key] = sol_value
        if bt_ind == len(sol_keys)-1:
            if valid(solution):
                return
            continue
        bt_ind += 1


def _run_randomized(solution, assignments, valid, forward_check, to_hashable):
    while True:
        success = _randomized_helper(solution, assignments, forward_check,
                                     to_hashable)
        if success and valid(solution):
            return

def _randomized_helper(solution, assignments, forward_check, to_hashable,
                       iter_limit=10000):
    used = set()
    for sol_key in assignments:
        for _ in range(iter_limit):
            solution[sol_key] = assignments[sol_key].sample()
            if forward_check(used, solution[sol_key]):
                break
        else:
            return False
        used.add(to_hashable(solution[sol_key]))
    return True


class PriorityQueue:
    """Priority queue utility class.
    """
    def  __init__(self):
        self.heap = []
        self.count = 0

    def push(self, item, priority):
        """Push item to the queue with given priority.
        """
        entry = (priority, self.count, item)
        heapq.heappush(self.heap, entry)
        self.count += 1

    def pop(self):
        """Remove and return lowest priority item from queue.
        """
        (_, _, item) = heapq.heappop(self.heap)
        return item

    def is_empty(self):
        """Return whether the queue is empty.
        """
        return len(self.heap) == 0

    def update(self, item, priority):
        """If item already in priority queue with higher priority, update
        its priority and rebuild the heap. If item already in priority queue
        with equal or lower priority, do nothing. If item not in priority
        queue, do the same thing as self.push.
        """
        for index, (prio, cnt, i) in enumerate(self.heap):
            if i == item:
                if prio <= priority:
                    break
                del self.heap[index]
                self.heap.append((priority, cnt, item))
                heapq.heapify(self.heap)
                break
        else:
            self.push(item, priority)


class SearchTreeEntry:
    """An entry in the search tree.
    """
    def __init__(self, state, state_sequence, action_sequence,
                 cost, cost_sequence):
        self.state = state
        self.state_sequence = state_sequence
        self.action_sequence = action_sequence
        self.cost = cost
        self.cost_sequence = cost_sequence


class CSPSolverFailed(Exception):
    """Exception raised when a CSP solver fails.
    """
    pass


class MCTS:
    """MCTS implementation for stochastic domains.
    """
    def __init__(self, actions, time_limit, epsilon, pi_rollout,
                 rand_state, gamma):
        self._actions = actions
        self._time_limit = time_limit
        self._eps = epsilon
        self._pi_rollout = pi_rollout
        self._rand_state = rand_state
        self._gamma = gamma

    def search(self, state):
        """Search from the given initial state, which must define the
        following methods:
        - step(action) -> state
        - reward() -> float
        - terminal() -> boolean
        Returns (action, value).
        """
        root = MCTSTreeNode(state, parent=None)
        for axn in self._actions:
            root.children[axn] = {}
        start = time.time()
        while time.time()-start < self._time_limit:
            node, rewards = self._tree_policy(root)
            rewards = self._default_policy(node.state, rewards)
            for i in range(len(rewards)-2, -1, -1):  # do discounting
                rewards[i] = rewards[i]+self._gamma*rewards[i+1]
            self._backpropagate(node, rewards)
        return self._best_action(root)

    def _tree_policy(self, node):
        rewards = []
        while not node.state.terminal():
            rewards.append(node.state.reward())
            action, _ = self._select_action(node)
            next_state = node.state.step(action)
            if next_state not in node.children[action]:
                child = MCTSTreeNode(next_state, parent=node)
                for axn in self._actions:
                    child.children[axn] = {}
                node.children[action][next_state] = child
                return child, rewards
            node = node.children[action][next_state]
        return node, rewards

    def _default_policy(self, state, rewards):
        while not state.terminal():
            rewards.append(state.reward())
            action = self._pi_rollout(state)
            state = state.step(action)
        rewards.append(state.reward())
        return rewards

    def _backpropagate(self, node, rewards):
        if node is None:
            return
        self._backpropagate(node.parent, rewards)
        node.count += 1
        node.reward += rewards.pop(0)

    def _select_action(self, node):
        best_value = float("-inf")
        best_actions = []
        for action in node.children:
            total_count = sum(node.children[action][child].count
                              for child in node.children[action])
            if total_count == 0:
                value = float("inf")
            else:
                total_reward = sum(node.children[action][child].reward
                                   for child in node.children[action])
                value = (total_reward/total_count+
                         self._eps*np.sqrt(2*np.log(node.count)/total_count))
            if value > best_value:
                best_value = value
                best_actions = [action]
            elif value == best_value:
                best_actions.append(action)
        return self._rand_state.choice(best_actions), best_value

    def _best_action(self, node):
        best_value = float("-inf")
        best_actions = []
        for action in node.children:
            total_count = sum(node.children[action][child].count
                              for child in node.children[action])
            if total_count == 0:
                continue
            total_reward = sum(node.children[action][child].reward
                               for child in node.children[action])
            value = total_reward/total_count
            if value > best_value:
                best_value = value
                best_actions = [action]
            elif value == best_value:
                best_actions.append(action)
        return self._rand_state.choice(best_actions), best_value


class MCTSTreeNode:
    """Node of a tree in the MCTS.
    """
    def __init__(self, state, parent):
        self.state = state
        self.parent = parent
        self.children = {}
        self.count = 0
        self.reward = 0
