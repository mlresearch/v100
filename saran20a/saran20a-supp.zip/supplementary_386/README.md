# Code for CoRL'19 submission "Understanding Teacher Gaze Patterns for Robot Learning"
The data for the user study associated with this paper is not permissible for release under IRB constraints. We include dummy data with our code wherever possible.

This folder contains code for the following experimental sections of the paper:

-  Code for Statistical Analysis of Gaze Patterns (CoRL_2019_code/1.Stat_Analysis/)<br />
   (a) Pouring Task <br />
   		* pouring/exp1.py: Percentage of time during entire demo spent fixating on objects, gripper or other parts of workspace 
   		* pouring/exp2.py: Perecentage accuarcy to predict reference frame per keyframe
   		* pouring/exp3.py: Gaze Patterns between Novice and Expert Users
   		* pouring/exp4.py: Gaze-patterns around step KF and non-step KF (KT demos only)
   		* pouring/gaze_filtering_demo.py: A demo file with dummy data for gaze fixation filtering (Run ```python gaze_filtering_demo.py```)

   (b) Placement Task <br />
   		* placement/exp1.py: Percentage of time during entire demo spent fixating on objects, gripper or other parts of workspace 
   		* placement/exp2.py: Gaze fixations on bowl and plate for different relative placement strategy

-  Code for SubTask Classification (CoRL_2019_code/2.SubTask_Detection)<br />
   1. Non-local neural network
   2. Compact Generalized Non-local neural network <br /><br />
   * Training data for these networks cannot be made available due to IRB restrictions, however we do link trained models and some dummy data for validation.
   * Detailed instructions to run the code are available in CoRL_2019_code/2.SubTask_Detection/README.md.
   * The files which have been modified to add gaze data into the training framework are train_val.py and models/resnet.py.

-  Code for Reward Learning with Gaze-augmented BIRL (CoRL_2019_code/3.BIRL+Gaze)
	* To run Gaze-augmented BIRL for KT demos:
		* instruction relative to plate   ```./test_gaze_birl.py --demo_type 'KT' --exp 'plate' --use_gaze ```
		* instruction relative to bowl	```./test_gaze_birl.py --demo_type 'KT' --exp 'bowl' --use_gaze ```

	* To run Gaze-augmented BIRL for video demos:
		* instruction relative to plate   ```./test_gaze_birl.py --demo_type 'video' --exp 'plate' --use_gaze ```
		* instruction relative to bowl	```./test_gaze_birl.py --demo_type 'video' --exp 'bowl' --use_gaze ```

	* To run standard BIRL for KT demos:
		* instruction relative to plate   ```./test_gaze_birl.py --demo_type 'KT' --exp 'plate'  ```
		* instruction relative to bowl	```./test_gaze_birl.py --demo_type 'KT' --exp 'bowl'  ```

	* To run standard BIRL for video demos:
		* instruction relative to plate   ```./test_gaze_birl.py --demo_type 'video' --exp 'plate'  ```
		* instruction relative to bowl	```./test_gaze_birl.py --demo_type 'video' --exp 'bowl'  ```


<br /><br /><br />
If you find our work to be useful in your research, please cite:
```
@article{saran2019understanding,
  title={Understanding Teacher Gaze Patterns for Robot Learning},
  author={Saran, Akanksha and Short, Elaine Schaertl and Thomaz, Andrea and Niekum, Scott},
  journal={Conference on Robot Learning},
  year={2019}
}```