function [traj_val, obj_val, out] = generate_demo_U(T, s, g)

N = 2;
A1 = [eye(N); -eye(N)]; A2 = A1; A3 = A1;
b1 = [   -0.5000; 0.9948; 1.5000; 1.0000];
b2 = [1.5000; 0; 1.5000; 1.0000];
b3 = [1.5000; 0.9948; -0.5000; 1.0000];

U_MAX = 0.5^2;
traj = sdpvar(2, T);

constraints_1 = [];
for i = 1:T-1
  constraints_1 = [constraints_1, sum(( traj(:, 2:end) - traj(:, 1:end-1) ).^2, 1) <= U_MAX]; % Known control constraint
end
constraints_1 = [constraints_1, traj(:, 1) == s, traj(:, T) == g]; % Known start/goal constraint

% Obstacle avoidance
for i = 1:T
  constraints_1 = [constraints_1, A1(1,:)*traj(:, i) >= b1(1) | A1(2,:)*traj(:, i) >= b1(2) | A1(3,:)*traj(:, i) >= b1(3) | A1(4,:)*traj(:, i) >= b1(4)];
  constraints_1 = [constraints_1, A2(1,:)*traj(:, i) >= b2(1) | A2(2,:)*traj(:, i) >= b2(2) | A2(3,:)*traj(:, i) >= b2(3) | A2(4,:)*traj(:, i) >= b2(4)];
  constraints_1 = [constraints_1, A3(1,:)*traj(:, i) >= b3(1) | A3(2,:)*traj(:, i) >= b3(2) | A3(3,:)*traj(:, i) >= b3(3) | A3(4,:)*traj(:, i) >= b3(4) ];
end

% Bounding search space for the demonstration
constraints_1 = [constraints_1, -3 <= traj <= 3];

% Cost function
objective = sum(sum( (traj(:, 2:end) - traj(:, 1:end-1)).^2 ));

ops = sdpsettings('solver', 'gurobi', 'verbose', 2);
ops.gurobi.TimeLimit = 20;
out = optimize(constraints_1, objective, ops);

traj_val = value(traj);
obj_val = value(objective);

end