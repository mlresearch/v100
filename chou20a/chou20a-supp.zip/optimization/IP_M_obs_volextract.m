function [learned, eps_val] = IP_M_obs_volextract(N, M, samples, safe_x, x_center)

% ---------------------------  Outputs: ----------------------------------
% learned: a concatenation of the parameters for each of the M simple
%   unsafe sets.
% eps_val: value of epsilon (output of problem 4 in the paper)
% ---------------------------- Inputs: -----------------------------------
% N: number of dimensions of the constraint space (for U-shape, N = 2)
% M: number of dimensions of simple unsafe sets used in parameterization
% samples: sampled unsafe trajectories; should be a cell array; each cell
%     entry contains an array of dimension N*T x S, where T is the number
%     of timesteps in the trajectory and S is the number of trajectories.
% safe_x: an N x N_s array containing all N_s safe states lying on the
%   demonstrations.
% x_center: a N x 1 vector containing k_query in the paper (i.e. the center
%   of the hypercube.

THETA_LB = [-5; -5; -3; -3]; % Initial parameter search space
THETA_UB = [8; 8; 3; 3];
bigM = 20; % Big-M value
EPS_MAX = 10; % Bound on the maximum epsilon (can get this from state space)

thetas = cell(1, M);
A_cell = cell(1, M);
A2_cell = cell(1, M);
b_cell = cell(1, M);
constraints = [];
for i = 1:M
  thetas{i} = sdpvar(4, 1);
  A_cell{i} = [eye(N); -eye(N)];
  A2_cell{i} = [-eye(N); eye(N)];
  b_cell{i} = [thetas{i}(2); thetas{i}(4); -thetas{i}(1); -thetas{i}(3)];
  constraints = [constraints, THETA_LB <= thetas{i} <= THETA_UB ];
end

% Processing unsafe trajectories
samples_trunc = cell(size(samples));
for i = 1:length(samples)
  samples_trunc{i} = double(samples{i}(N+1:end-N, :));
end

z = cell(1, length(samples_trunc));

% Safe states: enforce that each safe x satisfies Ax >= b_i, i = 1...M.
z_safe = cell(1, M);
for j = 1:M
  z_curr = binvar(4, size(safe_x, 2));
  for i = 1:size(safe_x, 2)
    constraints = [constraints, A2_cell{j}*safe_x + b_cell{j}*ones(1, size(safe_x, 2)) <= bigM*z_curr, sum(z_curr, 1) <= 3];
  end
  z_safe{j} = z_curr;
end

% Unsafe states: enforce that there exists an x on each unsafe trajectory
%     such that Ax <= b_1 or Ax <= b_2 or .... or Ax <= b_M.
for i = 1:length(samples_trunc)
  T = size(samples_trunc{i}, 1);
  NUM_TRAJS = size(samples_trunc{i}, 2);
  
  inds = 1:N:size(samples_trunc{i}, 1); % To index into a particular trajectory
  
  z_tot_cell = cell(1, M);
  for k = 1:M
    z_tot_cell{k} = binvar(T/N, NUM_TRAJS, 'full');
    z{i} = [z{i}; z_tot_cell{k}];
  end
  
  curr_cstr = [];
  for j = 1:length(inds)
    curr_state = samples_trunc{i}(inds(j):inds(j)+N-1, :);
    for k = 1:M
      curr_cstr = [curr_cstr, A_cell{k}*curr_state - b_cell{k}*ones(1, NUM_TRAJS) ...
        <= bigM*ones(size(A_cell{k}, 1), 1)*(1 - z_tot_cell{k}(j, :))];
    end
  end
  constraints = [constraints, curr_cstr, sum(z{i}, 1) >= 1];
end

% Carving unsafe volume
x_vol = sdpvar(N, 1);
x_vol_bounds = [5; 5]; % Setting bounds on where x_vol can be

eps_test = sdpvar(1);
constraints = [constraints, [eye(2); -eye(2)]*(x_vol - x_center) <= sum(eps_test), ...
  0 <= eps_test <= EPS_MAX, -x_vol_bounds <= x_vol <= x_vol_bounds];
for i = 1:M
  constraints = [constraints, A_cell{i}(1,:)*x_vol >= b_cell{i}(1) ...
    | A_cell{i}(2,:)*x_vol >= b_cell{i}(2) ...
    | A_cell{i}(3,:)*x_vol >= b_cell{i}(3) | A_cell{i}(4,:)*x_vol >= b_cell{i}(4)];
end

% Solve multi-box variant of Problem 4 in the paper.
ops = sdpsettings('solver', 'gurobi', 'verbose', 2);
optimize(constraints, sum(eps_test), ops);

% Extracting learned parameters
learned = [];
for k = 1:M
  learned = [learned; value(b_cell{k})];
end

% Extracting epsilon
eps_val = value(eps_test);

end