% Unsafe set setup
N = 2;
A1 = [eye(N); -eye(N)]; A2 = A1; A3 = A1;
b1 = [   -0.5000; 0.9948; 1.5000; 1.0000];
b2 = [1.5000; 0; 1.5000; 1.0000];
b3 = [1.5000; 0.9948; -0.5000; 1.0000];
H1 = Polyhedron('A', A1, 'b', b1);
H2 = Polyhedron('A', A2, 'b', b2);
H3 = Polyhedron('A', A3, 'b', b3);

% Generating start/goal states
samples = [4*rand(1, 10000)-2; 4*rand(1, 10000)-2];
samples = samples(:, ~H1.contains(samples) & ~H2.contains(samples) & ~H3.contains(samples));

N_DEMO = 100; % Number of demonstrations to generate

% Generate demonstrations
trajs_tot = cell(1, N_DEMO); obj_tot = cell(1, N_DEMO); out_tot = cell(1, N_DEMO);
for i = 1:N_DEMO
  T = 2;
  s = samples(:, randsample(1:size(samples, 2), 1));
  g = samples(:, randsample(1:size(samples, 2), 1));
  while 1
    [traj_val, obj_val, out] = generate_demo_U(T, s, g);
    if out.problem ~= 0
      T = T + 1;
    else
      trajs_tot{i} = traj_val; obj_tot{i} = obj_val; out_tot{i} = out;
      break;
    end
  end
end