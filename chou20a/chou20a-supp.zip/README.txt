README:

Dependencies:
-------------
- Gurobi 7.52
- YALMIP
- MPT3

Sampling code:
--------------
- Hit-and-run sampling code for kinematic systems is provided in /sampling/kinematic/extract_lower_cost_trajectories.m
- Hit-and-run sampling code for nonlinear systems (a quadrotor example is provided) is provided in /sampling/nonlinear/extract_lower_cost_states_quad.m

Optimization code:
------------------
- An implementation of Problem 1 for the 2D U-shape example is in /optimization/generate_demo_U.m
- An implementation of the multi-box variant of Problem 3 is in /optimization/IP_M_obs.m
- An implementation of Problem 4 is in /optimization/IP_M_obs_volextract.m

Figure replication code:
------------------------
- Run run_random_u.m to recover the \mathcal{A}(\theta) presented in Figure D.1 of the paper.