function samples = extract_lower_cost_trajectories(N_SAMPLES, traj)

% Output: samples: cell array of unsafe trajectories
% Input: N_SAMPLES: number of desired samples for each sub-trajectory
%        traj: a demonstration

N = size(traj, 2);

% Generating sub-trajectory indices
inds = cell(1, N-1);
for i = 2:N-1
  inds_curr = zeros(2, i);
  for j = 1:N-i
    inds_curr(:, j) = [j; j+i];
  end
  inds{i} = inds_curr;
end

inds_tot = cell2mat(inds);
inds_tot = inds_tot(:, ~all(inds_tot == 0, 1));

% For each sub-trajectory, sample lower-cost trajectories.
samples = cell(1, size(inds_tot, 2));
for i = 1:size(inds_tot, 2)
  samples{i} = hnr_kinematic( N_SAMPLES, traj(:, inds_tot(1,i):inds_tot(2,i)) );
  samples{i} = single(samples{i});
end

end