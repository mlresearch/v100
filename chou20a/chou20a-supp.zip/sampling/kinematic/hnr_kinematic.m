function samples = hnr_kinematic(NUM_SAMPLES, traj)

rng(1234);
STDEV = 0.02; % Noise used to perturb the demonstration
MAX_ITER = 50; % Number of re-tries before giving up
COST_BUFFER = 1e-6; % To ensure the sampled trajectories are strictly lower cost

% Known control constraint
UMAX = 0.5^2;

% Calculate cost of demonstration
x_norm_init = sum(sum((traj(:, 2:end) - traj(:, 1:end-1)).^2, 1));
N = size(traj, 1);

samples = zeros(length(traj(:)), NUM_SAMPLES);
x_prop = traj(:);
samples(:, 1) = x_prop;

for i = 2:size(samples, 2)
  STDEV_CURR = STDEV;
  tot_tries = 0;
  failed = 0;
  while 1
    % Generate a proposed sample
    x_prop = samples(:, i-1) + STDEV_CURR*[zeros(N, 1); randn(size(samples, 1) - 2*N, 1); zeros(N, 1)];
    x_resh = reshape(x_prop, N, length(x_prop)/N);
    x_resh_vec = sum((x_resh(:, 2:end) - x_resh(:, 1:end-1)).^2, 1);
    % Calculate the cost
    x_resh_norm = sum(x_resh_vec);
    % Check containment in \mathcal{T}_\mathcal{A}^{\xi_{xu}^*}
    if x_resh_norm <= x_norm_init-COST_BUFFER && all(x_resh_vec <= UMAX)
      break;
    end
    if tot_tries >= MAX_ITER
      failed = 1; % No lower-cost trajectories can be sampled (probably a straight line segment in demo).
      break;
    end
    % If current sample does not satisfy known constraints, reduce
    %   perturbation in sample
    STDEV_CURR = STDEV_CURR / 2;
    tot_tries = tot_tries + 1;
  end
  if failed
    samples = NaN;
    break;
  end
  accept = 1;
  if rand < accept
    samples(:, i) = x_prop;
  else
    samples(:, i) = samples(:, i-1);
  end
end

end