function [samples, samples_traj, give_up, costs, lambdas, ct_coll, dists] = ...
  sampling_cost_nonconvex_quad(x0, xg, u_dt_init, traj_init, NUM_SAMPLES)

MIN_L_DIST = 1e-10;
rng('shuffle')

%% Initialization
u = u_dt_init;
c_best = sum(sqrt(sum( (traj_init([1:3,10:12], 2:end) - traj_init([1:3,10:12], 1:end-1)).^2, 1)));
i = 1;
samples = zeros(length(u_dt_init(:)), NUM_SAMPLES);
costs = zeros(1, NUM_SAMPLES);
dists = zeros(1, NUM_SAMPLES);
lambdas = zeros(1, NUM_SAMPLES);
samples_traj = zeros(length(traj_init(:)), NUM_SAMPLES);

ct = 0;
ct_coll = zeros(1, NUM_SAMPLES);
give_up = 0;

%% Loop
while i <= NUM_SAMPLES
  % Random perturbation in control sequence space
  d = 2*rand(size(u))-1;
  l_min = -0.3;
  l_max = 0.3;
  succeed = 0;
  while abs(l_max - l_min) > MIN_L_DIST
    %% Obtaining new trajectory
    lambda = (l_max - l_min)*rand + l_min;
    next_u = u + lambda*d;
    next_u(1:4,:) = min(max(next_u(1:4,:), -10), 10);
    %% Evaluate cost of sampled trajectory
    [cost, u_dt_new, traj, dist] = evaluate_quad_cost(x0, xg, next_u);
    if cost > c_best
      ct = ct + 1;
      if lambda > 0
        l_max = lambda;
      else
        l_min = lambda;
      end
      continue;
    else
      ct_coll(i) = ct;
      ct = 0;
      succeed = 1;
      break;
    end
  end
  if succeed
    samples(:, i) = u_dt_new(:);
    costs(i) = cost;
    dists(i) = dist;
    samples_traj(:, i) = traj(:);
    
    lambdas(i) = lambda;
    i = i + 1;
    u = next_u;
  end
  if ct > 5000
    give_up = 1;
    disp('Gave up.')
    samples = {};
    samples_traj = [];
    break
  end
end
if ~give_up
  disp('Succeeded.')
end

end