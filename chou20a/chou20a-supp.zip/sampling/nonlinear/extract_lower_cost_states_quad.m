function [samples, dists] = extract_lower_cost_states_quad(N_SAMPLES, traj, u_traj)

N = size(traj, 2);
inds = cell(1, N-1);
for i = 2:N-1
  inds_curr = zeros(2, i);
  for j = 1:N-i
    inds_curr(:, j) = [j; j+i];
  end
  inds{i} = inds_curr;
end

inds_tot = cell2mat(inds);
inds_tot = inds_tot(:, ~all(inds_tot == 0, 1));
keep = find(inds_tot(2,:) - inds_tot(1,:) <= 3);
inds_tot = inds_tot(:, keep);

samples = cell(1, size(inds_tot, 2));
dists = cell(1, size(inds_tot, 2));
for i = 1:size(inds_tot, 2)
  [~, samples{i}, ~, ~, ~, ~, dists{i}] = ...
    sampling_cost_nonconvex_quad(traj(:, inds_tot(1,i)), traj(:, inds_tot(2,i)), ...
    u_traj(:, inds_tot(1,i):inds_tot(2,i)-1), traj(:, inds_tot(1,i):inds_tot(2,i)), N_SAMPLES);
  samples{i} = single(samples{i});
end

end