function [cost, u_dt_new, traj, dist] = evaluate_quad_cost(x0, xg, u_dt)


out = quad_forward_propagate_udt(x0, xg, u_dt);
cost = out{2};
if ~isempty(out{1})
  dist = out{3};
  u_dt_new = u_dt;
  traj = out{1};
else
  u_dt_new = [];
  traj = [];
  dist = inf;
end

end