function out = quad_forward_propagate_udt(x0, xg, u_pert)

% Dynamics parameters
DT = 0.4;
g = -9.81; m = 1; Ix = 0.5; Iy = 0.1; Iz = 0.3;

dyn_f = @(x) [x(7); x(8); x(9); ...
              x(11)*sin(x(6))/cos(x(5)) + x(12)*cos(x(6))/cos(x(5)); ...
              x(11)*cos(x(6)) - x(12)*sin(x(6)); ...
              x(10) + x(11)*sin(x(6))*tan(x(5)) + x(12)*cos(x(6))*tan(x(5)); ...
              0; 0; g; ...
              ((Iy - Iz)/Iz)*x(11)*x(12); ...
              ((Iz - Ix)/Iy)*x(10)*x(12); ...
              ((Ix - Iy)/Iz)*x(10)*x(11)];
dyn_g = @(x) [0 0 0 0 0 0 -(1/m)*(sin(x(4))*sin(x(6)) + cos(x(4))*cos(x(6))*sin(x(5))) ...
                -(1/m)*(sin(x(4))*cos(x(6)) + cos(x(4))*sin(x(6))*sin(x(5))) ...
                -(1/m)*(cos(x(4))*cos(x(5))) 0 0 0;
              0 0 0 0 0 0 0 0 0 1/Ix 0 0;
              0 0 0 0 0 0 0 0 0 0 1/Iy 0;
              0 0 0 0 0 0 0 0 0 0 0 1/Iz]';

% Rollout
traj = zeros(12, size(u_pert, 2) + 1);
traj(:, 1) = x0;
for i = 2:size(traj, 2)
  traj(:, i) = traj(:, i-1) + DT*(dyn_f(traj(:, i-1)) + dyn_g(traj(:, i-1))*u_pert(:, i-1));
end

% Check satisfaction of known constraints
dist = sum((traj(:, end) - xg).^2, 1);
THRESH = 0.0002;

if dist < THRESH
  cost = sum(sum((traj([1:3,10:12], 2:end) - traj([1:3,10:12], 1:end-1)).^2, 1));
  out = {traj, cost, dist};
else
  out = {[], inf, inf};
end

end