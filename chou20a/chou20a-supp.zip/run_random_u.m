% Script to reproduce Figure D.1

% Randomly sampled demonstrations (you can generate your own in generate_random_U_demos.m)
load('ushape_rand_demos', 'trajs_tot');

% Sampling unsafe trajectories
tic;
N_DEMO = 35;
samples = cell(1, N_DEMO);
for i = 1:length(trajs_tot)
  samples{i} = extract_lower_cost_trajectories(10000, trajs_tot{i});
end
toc

% Processing sampled trajectories
samples_proc = {};
for i = 1:N_DEMO
  for j = 1:size(samples{i}, 2)
    if ~isnan(samples{i}{j})
      samples_proc = [samples_proc, samples{i}{j}];
    end
  end
end

% Downsampling the data (for speed in the IP).
N_DOWNSAMPLE = 25;
rng(1234);
samples_proc_trunc = cell(1, length(samples_proc));
for i = 1:length(samples_proc)
  samples_proc_trunc{i} = samples_proc{i}(:, randsample(1:size(samples_proc{i}, 2), N_DOWNSAMPLE));
end

N_DIM = 2;
N_BOXES = 3;

%% Find a FEASIBLE theta.

learned = IP_M_obs(N_DIM, N_BOXES, samples_proc_trunc, cell2mat(trajs_tot(1:N_DEMO)));

% Plot recovered A(theta).
learned_resh = reshape(learned, length(learned)/N_BOXES, N_BOXES);
figure;
for i = 1:size(learned_resh, 2)
  H_curr = Polyhedron('A', [eye(N_DIM); -eye(N_DIM)], 'b', learned_resh(:, i));
  hold on; H_curr.plot();
end
xlabel('$x$', 'Interpreter', 'Latex', 'Fontsize', 25);
ylabel('$y$', 'Interpreter', 'Latex', 'Fontsize', 25);
title('$\textrm{Recovered } \mathcal{A}(\theta)$', 'Interpreter', 'Latex', 'Fontsize', 25);

%% Extracting \mathcal{G}_{\neg s}.

% Let's calculate \mathcal{G}_{\neg s} for 15 demonstrations (faster).
N_DEMO_15 = 15;
trajs_15 = 1:78;

% Query a fixed state for unsafeness
load('grid.mat');
guar_unsafe = zeros(1, size(grid, 2));
for i = 1:size(grid, 2)
  [~, guar_unsafe(i)] = IP_M_obs(N_DIM, N_BOXES, samples_proc_trunc(trajs_15), [cell2mat(trajs_tot(1:N_DEMO_15)), grid(:, i)]);
end

% Or query a volume of unsafeness around that state
guar_unsafe = zeros(1, size(grid, 2));
for i = 1:size(grid, 2)
  [~, guar_unsafe(i)] = IP_M_obs_volextract(N_DIM, N_BOXES, samples_proc_trunc(trajs_15), cell2mat(trajs_tot(1:N_DEMO_15)), grid(:, i));
end